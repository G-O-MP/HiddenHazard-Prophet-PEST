# -*- coding: utf-8 -*-
"""
通用分割基线训练脚本
支持: DeepLabv3+, U-Net, U-Net++
"""
import os
import random
import warnings
warnings.filterwarnings('ignore')

import numpy as np
from PIL import Image
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
import torch.optim as optim
from torchvision.transforms import functional as TF
from torch.optim.lr_scheduler import StepLR
import segmentation_models_pytorch as smp  # type: ignore
from metrics_cod import compute_all_metrics, MetricAccumulator

# =========================
# 配置
# =========================
DATA_ROOT = "/root/FSL-COD数据集"
SPLITS_DIR = os.path.join(DATA_ROOT, "splits")

NUM_CLASSES = 1  # 二值分割：前景(伪装目标)
IMG_SIZE = 352
BATCH_SIZE = 4
NUM_EPOCHS = 100
PATIENCE = 15  # 早停耐心值
NUM_WORKERS = 0  # Windows兼容性：设为0避免多进程导入问题
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
SEED = 42
SAVE_DIR = "./checkpoints"
os.makedirs(SAVE_DIR, exist_ok=True)

# 7个场景类别
CATEGORIES = [
    "animal-artificial",
    "animal-natural-land",
    "animal-natural-snowfield",
    "animal-natural-underwater",
    "art",
    "insect",
    "military"
]

# =========================
# 固定随机种子
# =========================
def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

set_seed(SEED)

# =========================
# 数据集定义
# =========================
class CODSegDataset(Dataset):
    def __init__(self, data_root, split_file, img_size=512, is_train=True):
        self.data_root = data_root
        self.img_size = img_size
        self.is_train = is_train
        
        # 读取样本列表
        with open(split_file, 'r', encoding='utf-8') as f:
            self.samples = [x.strip() for x in f.readlines() if x.strip()]
    
    def __len__(self):
        return len(self.samples)
    
    def __getitem__(self, idx):
        sample_id = self.samples[idx]
        
        # 解析路径: category/filename.jpg
        parts = sample_id.split('/')
        category = parts[0]
        filename = parts[1]
        
        # 构建图像和mask路径
        img_dir = 'images' if os.path.exists(os.path.join(self.data_root, category, 'images')) else 'image'
        label_dir = 'labels' if os.path.exists(os.path.join(self.data_root, category, 'labels')) else 'label'
        
        img_path = os.path.join(self.data_root, category, img_dir, filename)
        mask_path = os.path.join(self.data_root, category, label_dir, filename.replace('.jpg', '.png'))
        
        # 加载图像和mask
        img = Image.open(img_path).convert("RGB")
        mask = Image.open(mask_path).convert("L")
        
        # Resize
        img = img.resize((self.img_size, self.img_size), Image.BILINEAR)
        mask = mask.resize((self.img_size, self.img_size), Image.NEAREST)
        
        # 数据增强（已禁用，控制基线性能）
        # if self.is_train:
        #     if random.random() < 0.5:
        #         img = img.transpose(Image.FLIP_LEFT_RIGHT)
        #         mask = mask.transpose(Image.FLIP_LEFT_RIGHT)
        #     if random.random() < 0.3:
        #         brightness = random.uniform(0.8, 1.2)
        #         contrast = random.uniform(0.8, 1.2)
        #         img = TF.adjust_brightness(img, brightness)
        #         img = TF.adjust_contrast(img, contrast)
        
        # 转换为Tensor并归一化
        img = TF.to_tensor(img)
        img = TF.normalize(img, mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        
        # Mask二值化: >127为前景(1), 否则背景(0)
        mask = np.array(mask, dtype=np.float32)
        mask = (mask > 127).astype(np.float32)
        mask = torch.from_numpy(mask).unsqueeze(0)  # [1, H, W]
        
        return img, mask

# =========================
# 损失函数: BCE + Dice
# =========================
class BCEDiceLoss(nn.Module):
    def __init__(self, bce_weight=0.5, dice_weight=0.5):
        super().__init__()
        self.bce_weight = bce_weight
        self.dice_weight = dice_weight
        self.bce = nn.BCEWithLogitsLoss()
    
    def forward(self, logits, targets):
        # BCE Loss
        bce_loss = self.bce(logits, targets)
        
        # Dice Loss
        probs = torch.sigmoid(logits)
        smooth = 1.0
        num = (probs * targets).sum(dim=(2, 3)) * 2 + smooth
        den = probs.sum(dim=(2, 3)) + targets.sum(dim=(2, 3)) + smooth
        dice_loss = 1 - (num / den).mean()
        
        return self.bce_weight * bce_loss + self.dice_weight * dice_loss

# =========================
# 评价指标 (使用 metrics_cod.py)
# =========================

# =========================
# 训练和验证
# =========================
def train_one_epoch(model, loader, criterion, optimizer, device):
    model.train()
    running_loss = 0.0
    
    for imgs, masks in loader:
        imgs = imgs.to(device)
        masks = masks.to(device)
        
        optimizer.zero_grad()
        outputs = model(imgs)
        loss = criterion(outputs, masks)
        loss.backward()
        optimizer.step()
        
        running_loss += loss.item() * imgs.size(0)
    
    return running_loss / len(loader.dataset)

def validate(model, loader, criterion, device):
    model.eval()
    running_loss = 0.0
    metric_acc = MetricAccumulator()
    
    with torch.no_grad():
        for imgs, masks in loader:
            imgs = imgs.to(device)
            masks = masks.to(device)
            
            outputs = model(imgs)
            loss = criterion(outputs, masks)
            running_loss += loss.item() * imgs.size(0)
            
            # 累积预测结果
            probs = torch.sigmoid(outputs)
            metric_acc.update(probs, masks)
    
    # 计算所有指标
    metrics = metric_acc.compute()
    avg_loss = running_loss / len(loader.dataset)
    
    return avg_loss, metrics

def train_model(model, model_name, train_loader, val_loader, num_epochs, device):
    criterion = BCEDiceLoss(bce_weight=0.5, dice_weight=0.5)
    
    # 学习率
    if model_name == "deeplabv3plus":
        optimizer = optim.AdamW(model.parameters(), lr=1e-4, weight_decay=1e-4)
    else:
        optimizer = optim.Adam(model.parameters(), lr=1e-4, weight_decay=1e-4)
    
    scheduler = StepLR(optimizer, step_size=20, gamma=0.5)
    
    best_dice = 0.0
    best_metrics = {}
    best_path = os.path.join(SAVE_DIR, f"{model_name}_best.pth")
    no_improve = 0  # 早停计数器
    
    print(f"\n{'='*60}")
    print(f"开始训练: {model_name.upper()} (patience={PATIENCE})")
    print(f"{'='*60}")
    
    for epoch in range(num_epochs):
        train_loss = train_one_epoch(model, train_loader, criterion, optimizer, device)
        val_loss, metrics = validate(model, val_loader, criterion, device)
        scheduler.step()
        
        # 打印主指标
        print(f"Epoch [{epoch+1:3d}/{num_epochs}] "
              f"Loss: {train_loss:.4f}/{val_loss:.4f} | "
              f"mIoU: {metrics['mIoU']:.4f} | "
              f"Dice: {metrics['Dice']:.4f} | "
              f"S: {metrics['S_measure']:.4f} | "
              f"maxF: {metrics['maxF']:.4f}")
        
        # 使用 Dice 作为保存最佳模型的标准
        if metrics['Dice'] > best_dice:
            best_dice = metrics['Dice']
            best_metrics = metrics.copy()
            no_improve = 0
            torch.save(model.state_dict(), best_path)
            print(f"  -> 新最佳! Dice={best_dice:.4f}, mIoU={metrics['mIoU']:.4f}, S={metrics['S_measure']:.4f}")
        else:
            no_improve += 1
            if no_improve >= PATIENCE:
                print(f"\n  早停触发! 连续{PATIENCE}轮无改进")
                break
    
    print(f"\n[{model_name}] 最佳结果:")
    print(f"  主指标: mIoU={best_metrics['mIoU']:.4f}, Dice={best_metrics['Dice']:.4f}, S={best_metrics['S_measure']:.4f}")
    print(f"  辅指标: maxF={best_metrics['maxF']:.4f}, MAE={best_metrics['MAE']:.4f}, PixelAcc={best_metrics['PixelAcc']:.4f}")
    return best_dice, best_path, best_metrics

# =========================
# 构建模型
# =========================
def build_models():
    models = {}
    
    # 1) DeepLabv3+ (ResNet-50) - 使用ImageNet预训练权重
    models["deeplabv3plus"] = smp.DeepLabV3Plus(
        encoder_name="resnet50",
        encoder_weights="imagenet",  # 与 train_ablation.py 保持一致
        in_channels=3,
        classes=NUM_CLASSES,
    )
    
    # 2) U-Net (ResNet-34) - 使用ImageNet预训练权重
    models["unet"] = smp.Unet(
        encoder_name="resnet34",
        encoder_weights="imagenet",
        in_channels=3,
        classes=NUM_CLASSES,
    )
    
    # 3) U-Net++ (ResNet-34) - 使用ImageNet预训练权重
    models["unetplusplus"] = smp.UnetPlusPlus(
        encoder_name="resnet34",
        encoder_weights="imagenet",
        in_channels=3,
        classes=NUM_CLASSES,
    )
    
    return models

# =========================
# 主函数
# =========================
def main():
    print("="*60)
    print("通用分割基线训练")
    print("="*60)
    print(f"设备: {DEVICE}")
    print(f"图像尺寸: {IMG_SIZE}x{IMG_SIZE}")
    print(f"Batch Size: {BATCH_SIZE}")
    print(f"训练轮数: {NUM_EPOCHS}")
    print("="*60)
    
    # 加载数据集
    train_dataset = CODSegDataset(
        DATA_ROOT, 
        os.path.join(SPLITS_DIR, "train.txt"),
        img_size=IMG_SIZE,
        is_train=True
    )
    val_dataset = CODSegDataset(
        DATA_ROOT,
        os.path.join(SPLITS_DIR, "val.txt"),
        img_size=IMG_SIZE,
        is_train=False
    )
    
    train_loader = DataLoader(
        train_dataset, batch_size=BATCH_SIZE, shuffle=True,
        num_workers=NUM_WORKERS, pin_memory=True
    )
    val_loader = DataLoader(
        val_dataset, batch_size=BATCH_SIZE, shuffle=False,
        num_workers=NUM_WORKERS, pin_memory=True
    )
    
    print(f"训练集: {len(train_dataset)} 样本")
    print(f"验证集: {len(val_dataset)} 样本")
    
    # 构建模型
    models = build_models()
    
    # 训练每个模型
    results = {}
    for name, model in models.items():
        model = model.to(DEVICE)
        best_dice, best_path, best_metrics = train_model(
            model, name, train_loader, val_loader, NUM_EPOCHS, DEVICE
        )
        results[name] = (best_dice, best_path, best_metrics)
    
    # 输出最终结果
    print("\n" + "="*80)
    print("最终结果汇总")
    print("="*80)
    print(f"{'模型':<15} {'mIoU':>8} {'Dice':>8} {'S-measure':>10} {'maxF':>8} {'MAE':>8} {'PixelAcc':>10}")
    print("-"*80)
    for name, (dice, path, m) in results.items():
        print(f"{name:<15} {m['mIoU']:>8.4f} {m['Dice']:>8.4f} {m['S_measure']:>10.4f} "
              f"{m['maxF']:>8.4f} {m['MAE']:>8.4f} {m['PixelAcc']:>10.4f}")
    print("="*80)

if __name__ == "__main__":
    main()
