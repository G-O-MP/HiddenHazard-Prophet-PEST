# -*- coding: utf-8 -*-
"""
C2FNet-like (Few-shot Camouflaged Object Detection)
适配方案B:
- Base supervised training on base scenes
- Novel 5-shot finetune
- Novel evaluation on novel query

保留 C2FNet 核心思想：
- 深层 coarse prediction (C)
- 逐级上采样 + 与浅层特征融合进行 fine refinement (2F)
- 最终得到高分辨率伪装目标预测

去掉原版中复杂的多分支、多损失结构，做成 few-shot 友好版。
"""

import os
import random
import warnings
warnings.filterwarnings("ignore")

import numpy as np
from PIL import Image

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from torchvision import models, transforms

from metrics_cod import compute_all_metrics  # type: ignore


# ======================
# 配置
# ======================
DATA_ROOT = r"D:\University\Homework\机器学习\机器学习课程设计\FSL-COD数据集"
SPLIT_DIR = os.path.join(DATA_ROOT, "splits")

BASE_TRAIN_LIST = os.path.join(SPLIT_DIR, "base_train.txt")
BASE_VAL_LIST = os.path.join(SPLIT_DIR, "base_val.txt")
NOVEL_SUPPORT_LIST = os.path.join(SPLIT_DIR, "novel_support.txt")
NOVEL_QUERY_LIST = os.path.join(SPLIT_DIR, "novel_query.txt")

IMG_SIZE = 352
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
SEED = 42

BATCH_SIZE = 8
BASE_EPOCHS = 50
FINETUNE_EPOCHS = 30
BASE_LR = 5e-5  # 降低学习率
FT_LR = 5e-6   # 降低学习率
PATIENCE = 10


def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


set_seed(SEED)


# ======================
# 通用工具 & Dataset
# ======================
def load_split_list(txt_path):
    items = []
    with open(txt_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split()
            if len(parts) >= 3:
                img, mask, scene = parts[0], parts[1], parts[2]
            else:
                img, mask, scene = parts[0], parts[1], "unknown"
            items.append((img, mask, scene))
    return items


class SimpleTransform:
    def __init__(self, img_size=352, is_train=True):
        self.img_size = img_size
        self.is_train = is_train
        self.to_tensor = transforms.ToTensor()
        self.normalize = transforms.Normalize(
            mean=[0.485, 0.456, 0.406],
            std=[0.229, 0.224, 0.225]
        )

    def __call__(self, img, mask):
        img = img.resize((self.img_size, self.img_size), Image.BILINEAR)
        mask = mask.resize((self.img_size, self.img_size), Image.NEAREST)

        # 数据增强已禁用
        # if self.is_train and random.random() < 0.5:
        #     img = img.transpose(Image.FLIP_LEFT_RIGHT)
        #     mask = mask.transpose(Image.FLIP_LEFT_RIGHT)

        img = self.to_tensor(img)
        img = self.normalize(img)

        mask = np.array(mask, dtype=np.float32)
        if mask.max() > 1:
            mask = (mask > 127.5).astype(np.float32)
        else:
            mask = (mask > 0.5).astype(np.float32)
        mask = torch.from_numpy(mask)

        return img, mask


class ImageMaskDataset(Dataset):
    def __init__(self, items, img_size=352, is_train=True):
        self.items = items
        self.transform = SimpleTransform(img_size, is_train)

    def __len__(self):
        return len(self.items)

    def __getitem__(self, idx):
        img_path, mask_path, scene = self.items[idx]
        img = Image.open(img_path).convert("RGB")
        mask = Image.open(mask_path).convert("L")
        img, mask = self.transform(img, mask)
        return img, mask, scene


# ======================
# C2FNet-like Model
# ======================
class ConvBNReLU(nn.Module):
    def __init__(self, in_c, out_c):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(in_c, out_c, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_c),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        return self.block(x)


class CoarseRefineBlock(nn.Module):
    """
    粗到细细化模块：
    - 输入: 上一层 coarse prediction 对应的特征 + 当前层特征
    - 做法: concat -> Conv -> 输出 refined logits
    """
    def __init__(self, in_c, mid_c=256):
        super().__init__()
        self.conv = nn.Sequential(
            ConvBNReLU(in_c, mid_c),
            ConvBNReLU(mid_c, mid_c),
        )
        self.pred = nn.Conv2d(mid_c, 1, 3, padding=1)

    def forward(self, feat_cat):
        x = self.conv(feat_cat)
        logit = self.pred(x)
        return logit


class C2FNetLike(nn.Module):
    """
    C2FNet-like:
    - ResNet50 backbone
    - 最深层产生 coarse prediction
    - 上采样 + 与浅层特征拼接，逐级细化
    - 输出最终高分辨率预测
    """
    def __init__(self):
        super().__init__()

        resnet = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V1)

        self.layer0 = nn.Sequential(
            resnet.conv1, resnet.bn1, resnet.relu, resnet.maxpool
        )   # /4
        self.layer1 = resnet.layer1           # /4, 256
        self.layer2 = resnet.layer2           # /8, 512
        self.layer3 = resnet.layer3           # /16,1024
        self.layer4 = resnet.layer4           # /32,2048

        # 通道统一
        self.c2 = ConvBNReLU(512, 256)
        self.c3 = ConvBNReLU(1024, 256)
        self.c4 = ConvBNReLU(2048, 256)

        # 最深层 coarse prediction 分支
        self.coarse_conv = ConvBNReLU(256, 256)
        self.coarse_pred = nn.Conv2d(256, 1, 3, padding=1)

        # 逐级细化模块: layer3 -> layer2 (两级细化)
        # coarse logits + f3 -> refine3
        self.refine3 = CoarseRefineBlock(256 + 1, 256)
        # refine3 logits + f2 -> refine2 (最终)
        self.refine2 = CoarseRefineBlock(256 + 1, 256)

    def forward(self, x):
        H, W = x.size(2), x.size(3)

        x0 = self.layer0(x)
        x1 = self.layer1(x0)
        x2 = self.layer2(x1)   # /8
        x3 = self.layer3(x2)   # /16
        x4 = self.layer4(x3)   # /32

        f2 = self.c2(x2)       # (B,256,H/8,W/8)
        f3 = self.c3(x3)       # (B,256,H/16,W/16)
        f4 = self.c4(x4)       # (B,256,H/32,W/32)

        # ------- Coarse stage (最深层粗预测) -------
        c4 = self.coarse_conv(f4)
        logit4 = self.coarse_pred(c4)   # (B,1,H/32,W/32)

        # ------- Fine stage 1: H/16 -------
        logit4_up = F.interpolate(logit4, size=f3.shape[2:], mode="bilinear", align_corners=True)
        feat3_cat = torch.cat([f3, logit4_up], dim=1)   # (B,256+1,H/16,W/16)
        logit3 = self.refine3(feat3_cat)                # (B,1,H/16,W/16)

        # ------- Fine stage 2: H/8 (最终) -------
        logit3_up = F.interpolate(logit3, size=f2.shape[2:], mode="bilinear", align_corners=True)
        feat2_cat = torch.cat([f2, logit3_up], dim=1)   # (B,256+1,H/8,W/8)
        logit2 = self.refine2(feat2_cat)                # (B,1,H/8,W/8)

        # 上采样到原图分辨率
        out = F.interpolate(logit2, size=(H, W), mode="bilinear", align_corners=True)

        return out  # logits (B,1,H,W)


# ======================
# 损失函数 (BCE + Dice)
# ======================
def dice_loss(pred_logits, target):
    prob = torch.sigmoid(pred_logits)[:, 0]
    target = target.float()

    inter = (prob * target).sum(dim=(1, 2))
    union = prob.sum(dim=(1, 2)) + target.sum(dim=(1, 2))
    dice = (2 * inter + 1e-5) / (union + 1e-5)
    return 1 - dice.mean()


def total_loss(logits, masks):
    bce = F.binary_cross_entropy_with_logits(logits[:, 0], masks.float())
    dsc = dice_loss(logits, masks)
    return 0.5 * bce + 0.5 * dsc


# ======================
# 评估函数
# ======================
@torch.no_grad()
def evaluate_dataset(model, items, device, desc="Eval"):
    model.eval()
    transform = SimpleTransform(IMG_SIZE, is_train=False)

    preds, gts = [], []

    for img_path, mask_path, scene in items:
        img = Image.open(img_path).convert("RGB")
        mask = Image.open(mask_path).convert("L")

        img_t, mask_t = transform(img, mask)
        img_t = img_t.unsqueeze(0).to(device)

        logits = model(img_t)
        prob = torch.sigmoid(logits)[0, 0].cpu().numpy()

        preds.append(prob)
        gts.append(mask_t.numpy())

    preds = np.stack(preds)
    gts = np.stack(gts)

    metrics = compute_all_metrics(preds, gts)

    print(f"[{desc}] mIoU={metrics['mIoU']:.4f}, Dice={metrics['Dice']:.4f}, "
          f"S={metrics['S_measure']:.4f}, maxF={metrics['maxF']:.4f}, "
          f"MAE={metrics['MAE']:.4f}, PixelAcc={metrics['PixelAcc']:.4f}")

    return metrics


# ======================
# Base Training
# ======================
def train_base_c2fnet():
    print("=" * 60)
    print("C2FNet-like Base Training")
    print("=" * 60)

    train_items = load_split_list(BASE_TRAIN_LIST)
    val_items = load_split_list(BASE_VAL_LIST)

    train_data = ImageMaskDataset(train_items, IMG_SIZE, True)

    train_loader = DataLoader(train_data, batch_size=BATCH_SIZE, shuffle=True, num_workers=4, pin_memory=True)

    model = C2FNetLike().to(DEVICE)
    opt = torch.optim.Adam(model.parameters(), lr=BASE_LR)

    best_dice = 0.0
    no_improve = 0
    os.makedirs("checkpoints", exist_ok=True)
    ckpt_path = "checkpoints/c2fnet_base.pth"

    for epoch in range(BASE_EPOCHS):
        model.train()
        total = 0.0

        for imgs, masks, scenes in train_loader:
            imgs, masks = imgs.to(DEVICE), masks.to(DEVICE)

            opt.zero_grad()
            logits = model(imgs)
            loss = total_loss(logits, masks)
            loss.backward()
            opt.step()

            total += loss.item() * imgs.size(0)

        avg = total / len(train_data)

        # 在 base_val 上评估
        val_metrics = evaluate_dataset(model, val_items, DEVICE, desc=f"Val E{epoch+1}")
        val_dice = val_metrics["Dice"]

        print(f"Epoch {epoch+1}/{BASE_EPOCHS}  Loss={avg:.4f} | Val Dice={val_dice:.4f}")

        if val_dice > best_dice:
            best_dice = val_dice
            no_improve = 0
            torch.save(model.state_dict(), ckpt_path)
            print(f" -> New best! saved to {ckpt_path}")
        else:
            no_improve += 1
            if no_improve >= PATIENCE:
                print(f"Early stopping at epoch {epoch+1}")
                break

    print(f"\n[C2FNet Base] Training done. Best Dice={best_dice:.4f}")
    return ckpt_path


# ======================
# Novel 5-shot Finetune + Eval
# ======================
def finetune_and_eval_novel():
    print("\n" + "=" * 60)
    print("C2FNet-like Novel 5-shot Fine-tuning")
    print("=" * 60)

    support_items = load_split_list(NOVEL_SUPPORT_LIST)
    query_items = load_split_list(NOVEL_QUERY_LIST)

    print(f"Novel Support = {len(support_items)}")
    print(f"Novel Query   = {len(query_items)}")

    model = C2FNetLike().to(DEVICE)
    ckpt = "checkpoints/c2fnet_base.pth"
    model.load_state_dict(torch.load(ckpt, map_location=DEVICE))
    print(f"Loaded base weights: {ckpt}")

    support_loader = DataLoader(
        ImageMaskDataset(support_items, IMG_SIZE, True),
        batch_size=2, shuffle=True
    )

    opt = torch.optim.Adam(model.parameters(), lr=FT_LR)

    print("\nStart 5-shot Finetuning...")
    for epoch in range(FINETUNE_EPOCHS):
        model.train()
        total = 0.0
        for imgs, masks, scenes in support_loader:
            imgs, masks = imgs.to(DEVICE), masks.to(DEVICE)

            opt.zero_grad()
            logits = model(imgs)
            loss = total_loss(logits, masks)
            loss.backward()
            opt.step()

            total += loss.item() * imgs.size(0)

        print(f"[FT Ep {epoch+1}] Loss={total/len(support_loader.dataset):.4f}")

    # 保存微调后的权重
    os.makedirs("checkpoints", exist_ok=True)
    ft_path = "checkpoints/c2fnet_novel_5shot.pth"
    torch.save(model.state_dict(), ft_path)
    print(f"Saved finetuned weights to {ft_path}")

    # 在 novel_query 上评估
    metrics = evaluate_dataset(model, query_items, DEVICE, desc="Novel 5-shot")

    print("\nFinal Novel Results:")
    for k, v in metrics.items():
        print(f"  {k}: {v:.4f}")

    return metrics


# ======================
# Main
# ======================
def main():
    print("C2FNet-like Few-shot COD (Scheme B)")
    print(f"Using device: {DEVICE}\n")

    # Step 1: Base 训练
    train_base_c2fnet()

    # Step 2: Novel 5-shot 微调 + 评估
    finetune_and_eval_novel()


if __name__ == "__main__":
    main()
