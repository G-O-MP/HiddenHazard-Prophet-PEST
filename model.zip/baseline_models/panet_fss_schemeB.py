# -*- coding: utf-8 -*-
"""
PANet 简化版 Few-shot Segmentation 实现
适配方案B: base/novel 场景划分
"""
import os
import random
from collections import defaultdict
import warnings
warnings.filterwarnings('ignore')

import numpy as np
from PIL import Image

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

from torchvision import models, transforms
from metrics_cod import compute_all_metrics  # type: ignore


# =======================
# 配置
# =======================
DATA_ROOT = r"D:\University\Homework\机器学习\机器学习课程设计\FSL-COD数据集"
SPLIT_DIR = os.path.join(DATA_ROOT, "splits")

BASE_TRAIN_LIST = os.path.join(SPLIT_DIR, "base_train.txt")
BASE_VAL_LIST = os.path.join(SPLIT_DIR, "base_val.txt")
NOVEL_SUPPORT_LIST = os.path.join(SPLIT_DIR, "novel_support.txt")
NOVEL_QUERY_LIST = os.path.join(SPLIT_DIR, "novel_query.txt")

IMG_SIZE = 352
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
SEED = 42

N_WAY = 1
K_SHOT = 5       # 可以改成 1 或 5
N_QUERY = 1      # 每个 episode 的 query 数
PATIENCE = 10    # 早停耐心值


def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


set_seed(SEED)


# =======================
# 通用工具
# =======================
def load_split_list(txt_path):
    """读取 txt 文件，返回 list[(img, mask, scene)]"""
    items = []
    with open(txt_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split()
            if len(parts) >= 3:
                img, mask, scene = parts[0], parts[1], parts[2]
            else:
                img, mask, scene = parts[0], parts[1], "unknown"
            items.append((img, mask, scene))
    return items


class SimpleTransform:
    def __init__(self, img_size=512, is_train=True):
        self.img_size = img_size
        self.is_train = is_train
        self.to_tensor = transforms.ToTensor()
        self.normalize = transforms.Normalize(
            mean=[0.485, 0.456, 0.406],
            std=[0.229, 0.224, 0.225],
        )

    def __call__(self, img, mask):
        img = img.resize((self.img_size, self.img_size), Image.BILINEAR)
        mask = mask.resize((self.img_size, self.img_size), Image.NEAREST)

        # 数据增强已禁用
        # if self.is_train:
        #     if random.random() < 0.5:
        #         img = img.transpose(Image.FLIP_LEFT_RIGHT)
        #         mask = mask.transpose(Image.FLIP_LEFT_RIGHT)

        img = self.to_tensor(img)
        img = self.normalize(img)

        mask = np.array(mask, dtype=np.float32)
        if mask.max() > 1:
            mask = (mask > 127.5).astype(np.float32)
        else:
            mask = (mask > 0.5).astype(np.float32)

        mask = torch.from_numpy(mask)
        return img, mask


# =======================
# Episode 数据集（base train）
# =======================
class FewShotEpisodeDataset(Dataset):
    def __init__(self, split_list, img_size=512, k_shot=5, n_query=1):
        super().__init__()
        self.k_shot = k_shot
        self.n_query = n_query
        self.transform = SimpleTransform(img_size=img_size, is_train=True)

        self.by_scene = defaultdict(list)
        for img, mask, scene in split_list:
            self.by_scene[scene].append((img, mask))

        self.scenes = list(self.by_scene.keys())

    def __len__(self):
        return 100000

    def _load_img_mask(self, img_path, mask_path):
        img = Image.open(img_path).convert("RGB")
        mask = Image.open(mask_path).convert("L")
        return self.transform(img, mask)

    def __getitem__(self, idx):
        scene = random.choice(self.scenes)
        pairs = self.by_scene[scene]

        min_required = self.k_shot + self.n_query
        if len(pairs) < min_required:
            # 如果样本不够，重复采样
            pairs = pairs * (min_required // len(pairs) + 1)

        idxs = list(range(len(pairs)))
        random.shuffle(idxs)
        support_idx = idxs[:self.k_shot]
        query_idx = idxs[self.k_shot:self.k_shot + self.n_query]

        support_imgs, support_masks = [], []
        query_imgs, query_masks = [], []

        for i in support_idx:
            img_path, mask_path = pairs[i]
            img, mask = self._load_img_mask(img_path, mask_path)
            support_imgs.append(img)
            support_masks.append(mask)

        for i in query_idx:
            img_path, mask_path = pairs[i]
            img, mask = self._load_img_mask(img_path, mask_path)
            query_imgs.append(img)
            query_masks.append(mask)

        support_imgs = torch.stack(support_imgs, dim=0)
        support_masks = torch.stack(support_masks, dim=0)
        query_imgs = torch.stack(query_imgs, dim=0)
        query_masks = torch.stack(query_masks, dim=0)

        return support_imgs, support_masks, query_imgs, query_masks, scene


# =======================
# 普通 Dataset
# =======================
class ImageMaskDataset(Dataset):
    def __init__(self, split_list, img_size=512, is_train=False):
        super().__init__()
        self.items = split_list
        self.transform = SimpleTransform(img_size=img_size, is_train=is_train)

    def __len__(self):
        return len(self.items)

    def __getitem__(self, idx):
        img_path, mask_path, scene = self.items[idx]
        img = Image.open(img_path).convert("RGB")
        mask = Image.open(mask_path).convert("L")
        img, mask = self.transform(img, mask)
        return img, mask, scene


# =======================
# PANet 风格模型
# =======================
class PANetLike(nn.Module):
    def __init__(self, backbone='resnet50'):
        super().__init__()
        if backbone == 'resnet50':
            resnet = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V1)
            feat_dim = 2048
        else:
            raise NotImplementedError

        self.encoder = nn.Sequential(
            resnet.conv1,
            resnet.bn1,
            resnet.relu,
            resnet.maxpool,
            resnet.layer1,
            resnet.layer2,
            resnet.layer3,
            resnet.layer4,
        )
        self.feat_dim = feat_dim
        self.proj = nn.Conv2d(feat_dim, feat_dim, kernel_size=1)

    def extract_feat(self, x):
        feat = self.encoder(x)
        feat = self.proj(feat)
        return feat

    def get_prototype(self, supp_feat, supp_mask):
        K, C, Hf, Wf = supp_feat.shape

        supp_mask = supp_mask.unsqueeze(1).float()
        supp_mask = F.interpolate(supp_mask, size=(Hf, Wf), mode='nearest')

        fg_mask = supp_mask
        bg_mask = 1.0 - fg_mask

        fg_feat = supp_feat * fg_mask
        fg_proto = fg_feat.sum(dim=(0, 2, 3)) / (fg_mask.sum(dim=(0, 2, 3)) + 1e-5)

        bg_feat = supp_feat * bg_mask
        bg_proto = bg_feat.sum(dim=(0, 2, 3)) / (bg_mask.sum(dim=(0, 2, 3)) + 1e-5)

        prototypes = torch.stack([bg_proto, fg_proto], dim=0)
        return prototypes

    def forward(self, supp_imgs, supp_masks, qry_imgs):
        supp_feats = self.extract_feat(supp_imgs)
        qry_feats = self.extract_feat(qry_imgs)

        prototypes = self.get_prototype(supp_feats, supp_masks)

        Qf, C, Hf, Wf = qry_feats.shape
        qry_flat = qry_feats.view(Qf, C, -1)
        proto = prototypes.unsqueeze(0)
        proto = proto.repeat(Qf, 1, 1)

        qry_norm = F.normalize(qry_flat, dim=1)
        proto_norm = F.normalize(proto, dim=2)

        logits = torch.bmm(proto_norm, qry_norm)
        logits = logits.view(Qf, 2, Hf, Wf)

        logits = F.interpolate(logits, size=(supp_masks.size(-2), supp_masks.size(-1)), 
                               mode='bilinear', align_corners=False)

        return logits


# =======================
# 损失函数
# =======================
def dice_loss(pred, target):
    pred_fg = torch.softmax(pred, dim=1)[:, 1]
    target = target.float()

    inter = (pred_fg * target).sum(dim=(1, 2))
    union = pred_fg.sum(dim=(1, 2)) + target.sum(dim=(1, 2))
    dice = (2 * inter + 1e-5) / (union + 1e-5)
    return 1 - dice.mean()


def bce_dice_loss(logits, masks):
    ce = F.cross_entropy(logits, masks.long())
    dl = dice_loss(logits, masks)
    return ce + dl


# =======================
# 评估函数
# =======================
@torch.no_grad()
def evaluate_on_val(model, val_items, support_items, device):
    """
    在验证集上评估：用 support_items 作为 support set
    """
    model.eval()
    
    # 按场景分组 support
    support_by_scene = defaultdict(list)
    for img, mask, scene in support_items:
        support_by_scene[scene].append((img, mask))
    
    transform = SimpleTransform(img_size=IMG_SIZE, is_train=False)
    
    all_preds = []
    all_gts = []
    
    for img_path, mask_path, scene in val_items:
        # 加载 query
        qry_img = Image.open(img_path).convert("RGB")
        qry_mask = Image.open(mask_path).convert("L")
        qry_img, qry_mask = transform(qry_img, qry_mask)
        qry_img = qry_img.unsqueeze(0).to(device)
        qry_mask_np = qry_mask.numpy()
        
        # 找到同场景的 support（如果没有，用随机场景）
        if scene in support_by_scene:
            supp_pairs = support_by_scene[scene][:K_SHOT]
        else:
            # 随机选一个场景
            rand_scene = random.choice(list(support_by_scene.keys()))
            supp_pairs = support_by_scene[rand_scene][:K_SHOT]
        
        # 加载 support
        supp_imgs, supp_masks = [], []
        for sp_img, sp_mask in supp_pairs:
            s_img = Image.open(sp_img).convert("RGB")
            s_mask = Image.open(sp_mask).convert("L")
            s_img, s_mask = transform(s_img, s_mask)
            supp_imgs.append(s_img)
            supp_masks.append(s_mask)
        
        if len(supp_imgs) < K_SHOT:
            # 重复填充
            while len(supp_imgs) < K_SHOT:
                supp_imgs.append(supp_imgs[0])
                supp_masks.append(supp_masks[0])
        
        supp_imgs = torch.stack(supp_imgs).to(device)
        supp_masks = torch.stack(supp_masks).to(device)
        
        # 推理
        logits = model(supp_imgs, supp_masks, qry_img)
        pred_prob = torch.softmax(logits, dim=1)[:, 1]  # 前景概率
        
        all_preds.append(pred_prob.cpu().numpy()[0])  # (H,W)
        all_gts.append(qry_mask_np)
    
    # 拼接成 (N, H, W)
    all_preds = np.stack(all_preds, axis=0)
    all_gts = np.stack(all_gts, axis=0)
    
    metrics = compute_all_metrics(all_preds, all_gts)
    return metrics


# =======================
# 训练 Base
# =======================
def train_base_panet():
    print("="*60)
    print("PANet Base 训练")
    print("="*60)
    
    base_train_items = load_split_list(BASE_TRAIN_LIST)
    base_val_items = load_split_list(BASE_VAL_LIST)

    train_dataset = FewShotEpisodeDataset(
        base_train_items, img_size=IMG_SIZE, k_shot=K_SHOT, n_query=N_QUERY
    )
    train_loader = DataLoader(train_dataset, batch_size=1, shuffle=False)

    model = PANetLike(backbone='resnet50').to(DEVICE)
    optimizer = torch.optim.Adam(model.parameters(), lr=5e-5)  # 降低学习率

    num_epochs = 30
    steps_per_epoch = 200
    best_val_dice = 0.0
    no_improve = 0
    
    save_path = os.path.join("checkpoints", "panet_base.pth")
    os.makedirs("checkpoints", exist_ok=True)

    print(f"设备: {DEVICE}")
    print(f"K-shot: {K_SHOT}")
    print(f"训练集场景数: {len(set(x[2] for x in base_train_items))}")
    print(f"验证集样本数: {len(base_val_items)}")
    print(f"早停 patience: {PATIENCE}")
    print("="*60)

    for epoch in range(num_epochs):
        model.train()
        running_loss = 0.0

        for step, batch in enumerate(train_loader):
            if step >= steps_per_epoch:
                break
            supp_imgs, supp_masks, qry_imgs, qry_masks, scene = batch
            supp_imgs = supp_imgs.squeeze(0).to(DEVICE)
            supp_masks = supp_masks.squeeze(0).to(DEVICE)
            qry_imgs = qry_imgs.squeeze(0).to(DEVICE)
            qry_masks = qry_masks.squeeze(0).to(DEVICE)

            optimizer.zero_grad()
            logits = model(supp_imgs, supp_masks, qry_imgs)
            loss = bce_dice_loss(logits, qry_masks)
            loss.backward()
            optimizer.step()

            running_loss += loss.item()

        avg_loss = running_loss / steps_per_epoch

        # 验证
        metrics = evaluate_on_val(model, base_val_items, base_train_items, DEVICE)
        val_dice = metrics['Dice']

        print(f"Epoch [{epoch+1:2d}/{num_epochs}] "
              f"Loss: {avg_loss:.4f} | "
              f"Val Dice: {val_dice:.4f} | "
              f"S: {metrics['S_measure']:.4f}")

        if val_dice > best_val_dice:
            best_val_dice = val_dice
            no_improve = 0
            torch.save(model.state_dict(), save_path)
            print(f"  -> 新最佳! Dice={best_val_dice:.4f}")
        else:
            no_improve += 1
            if no_improve >= PATIENCE:
                print(f"\n早停触发! 连续{PATIENCE}轮无改进")
                break

    print(f"\n[PANet Base] 训练完成, 最佳Dice: {best_val_dice:.4f}")
    return save_path


# =======================
# Novel 评估
# =======================
@torch.no_grad()
def evaluate_novel():
    print("\n" + "="*60)
    print("PANet Novel 评估 (5-shot)")
    print("="*60)
    
    novel_support_items = load_split_list(NOVEL_SUPPORT_LIST)
    novel_query_items = load_split_list(NOVEL_QUERY_LIST)
    
    model = PANetLike(backbone='resnet50').to(DEVICE)
    ckpt_path = os.path.join("checkpoints", "panet_base.pth")
    
    if os.path.exists(ckpt_path):
        model.load_state_dict(torch.load(ckpt_path, map_location=DEVICE))
        print(f"已加载模型: {ckpt_path}")
    else:
        print(f"警告: 找不到模型 {ckpt_path}")
        return
    
    print(f"Novel Support: {len(novel_support_items)} 样本")
    print(f"Novel Query: {len(novel_query_items)} 样本")
    
    metrics = evaluate_on_val(model, novel_query_items, novel_support_items, DEVICE)
    
    print("\n" + "="*60)
    print("Novel 测试结果:")
    print("="*60)
    print("主指标:")
    print(f"  mIoU:      {metrics['mIoU']:.4f}")
    print(f"  Dice:      {metrics['Dice']:.4f}")
    print(f"  S-measure: {metrics['S_measure']:.4f}")
    print("辅指标:")
    print(f"  maxF:      {metrics['maxF']:.4f}")
    print(f"  MAE:       {metrics['MAE']:.4f}")
    print(f"  PixelAcc:  {metrics['PixelAcc']:.4f}")
    print("="*60)
    
    return metrics


# =======================
# 主函数
# =======================
def main():
    print("="*60)
    print("PANet Few-shot Segmentation (方案B)")
    print("="*60)
    
    # 1. Base 训练
    train_base_panet()
    
    # 2. Novel 评估
    evaluate_novel()


if __name__ == "__main__":
    main()
