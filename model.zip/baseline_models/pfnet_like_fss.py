# -*- coding: utf-8 -*-
"""
PFNet-like (Few-shot Camouflaged Object Detection)
适配你的方案B:
- Base supervised training
- Novel 5-shot finetune
- Novel evaluation

保留 PFNet 核心机制：
- Camouflage branch (隐性增强)
- Boundary/detail branch (显性增强)
- Multi-scale fusion

简化 heavy 组件，适配 few-shot，小数据下更稳定。
"""

import os
import random
from collections import defaultdict
import warnings
warnings.filterwarnings("ignore")

import numpy as np
from PIL import Image

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from torchvision import models, transforms

from metrics_cod import compute_all_metrics  # type: ignore


# ======================
# 配置
# ======================
DATA_ROOT = r"D:\University\Homework\机器学习\机器学习课程设计\FSL-COD数据集"
SPLIT_DIR = os.path.join(DATA_ROOT, "splits")

BASE_TRAIN_LIST = os.path.join(SPLIT_DIR, "base_train.txt")
BASE_VAL_LIST = os.path.join(SPLIT_DIR, "base_val.txt")
NOVEL_SUPPORT_LIST = os.path.join(SPLIT_DIR, "novel_support.txt")
NOVEL_QUERY_LIST = os.path.join(SPLIT_DIR, "novel_query.txt")

IMG_SIZE = 352
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
SEED = 42

BATCH_SIZE = 8
BASE_EPOCHS = 50
FINETUNE_EPOCHS = 30
BASE_LR = 5e-5  # 降低学习率
FT_LR = 5e-6   # 降低学习率
PATIENCE = 10


def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


set_seed(SEED)


# ======================
# 工具与 Dataset
# ======================
def load_split_list(txt_path):
    items = []
    with open(txt_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split()
            if len(parts) >= 3:
                img, mask, scene = parts[0], parts[1], parts[2]
            else:
                img, mask, scene = parts[0], parts[1], "unknown"
            items.append((img, mask, scene))
    return items


class SimpleTransform:
    def __init__(self, img_size=352, is_train=True):
        self.img_size = img_size
        self.is_train = is_train
        self.to_tensor = transforms.ToTensor()
        self.normalize = transforms.Normalize(
            mean=[0.485, 0.456, 0.406],
            std=[0.229, 0.224, 0.225]
        )

    def __call__(self, img, mask):
        img = img.resize((self.img_size, self.img_size), Image.BILINEAR)
        mask = mask.resize((self.img_size, self.img_size), Image.NEAREST)

        # 数据增强已禁用
        # if self.is_train and random.random() < 0.5:
        #     img = img.transpose(Image.FLIP_LEFT_RIGHT)
        #     mask = mask.transpose(Image.FLIP_LEFT_RIGHT)

        img = self.to_tensor(img)
        img = self.normalize(img)

        mask = np.array(mask, dtype=np.float32)
        if mask.max() > 1:
            mask = (mask > 127.5).astype(np.float32)
        else:
            mask = (mask > 0.5).astype(np.float32)
        mask = torch.from_numpy(mask)

        return img, mask


class ImageMaskDataset(Dataset):
    def __init__(self, items, img_size=352, is_train=True):
        self.items = items
        self.transform = SimpleTransform(img_size, is_train)

    def __len__(self):
        return len(self.items)

    def __getitem__(self, idx):
        img_path, mask_path, scene = self.items[idx]
        img = Image.open(img_path).convert("RGB")
        mask = Image.open(mask_path).convert("L")
        img, mask = self.transform(img, mask)
        return img, mask, scene


# ======================
# PFNet-like Model
# ======================
class ConvBNReLU(nn.Module):
    def __init__(self, in_c, out_c):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(in_c, out_c, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_c),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        return self.block(x)


class AttentionEnhancer(nn.Module):
    """
    隐性特征增强模块（PFNet思想）
    强调"伪装区域"特征
    """
    def __init__(self, in_c):
        super().__init__()
        self.conv1 = ConvBNReLU(in_c, in_c)
        self.conv2 = nn.Conv2d(in_c, 1, 1)

    def forward(self, feat):
        x = self.conv1(feat)
        att = torch.sigmoid(self.conv2(x))   # (B,1,H,W)
        return feat * (1 + att)              # 加权增强


class BoundaryEnhancer(nn.Module):
    """
    显性边界增强模块（PFNet思想）
    """
    def __init__(self, in_c):
        super().__init__()
        self.sobel_x = nn.Conv2d(in_c, in_c, kernel_size=3, padding=1, bias=False)
        self.sobel_y = nn.Conv2d(in_c, in_c, kernel_size=3, padding=1, bias=False)

        sobel_x = torch.tensor([[[-1, 0, 1],
                                 [-2, 0, 2],
                                 [-1, 0, 1]]], dtype=torch.float32)
        sobel_y = sobel_x.transpose(-1, -2)

        self.sobel_x.weight.data = sobel_x.repeat(in_c, 1, 1, 1)
        self.sobel_y.weight.data = sobel_y.repeat(in_c, 1, 1, 1)

        for p in self.sobel_x.parameters():
            p.requires_grad = False
        for p in self.sobel_y.parameters():
            p.requires_grad = False

        self.conv = ConvBNReLU(in_c, in_c)

    def forward(self, feat):
        gx = self.sobel_x(feat)
        gy = self.sobel_y(feat)
        edges = torch.abs(gx) + torch.abs(gy)
        return self.conv(edges)


class PFNetLike(nn.Module):
    """
    PFNet-like:
    - ResNet50 backbone
    - 隐性增强分支（camouflage）
    - 显性边界分支（detail）
    - 多尺度融合
    """
    def __init__(self):
        super().__init__()

        resnet = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V1)

        self.layer0 = nn.Sequential(
            resnet.conv1, resnet.bn1, resnet.relu, resnet.maxpool
        )
        self.layer1 = resnet.layer1    # /4
        self.layer2 = resnet.layer2    # /8
        self.layer3 = resnet.layer3    # /16
        self.layer4 = resnet.layer4    # /32

        # 通道统一
        self.c2 = ConvBNReLU(512, 256)
        self.c3 = ConvBNReLU(1024, 256)
        self.c4 = ConvBNReLU(2048, 256)

        # PFNet 核心：隐性增强 + 边界增强
        self.cam_enhance = AttentionEnhancer(256)
        self.bdry_enhance = BoundaryEnhancer(256)

        # 融合
        self.fuse = nn.Sequential(
            ConvBNReLU(256 * 3, 256),
            ConvBNReLU(256, 64),
        )

        self.predict = nn.Conv2d(64, 1, 3, padding=1)

    def forward(self, x):
        H, W = x.size(2), x.size(3)

        x0 = self.layer0(x)
        x1 = self.layer1(x0)
        x2 = self.layer2(x1)   # /8
        x3 = self.layer3(x2)   # /16
        x4 = self.layer4(x3)   # /32

        f2 = self.c2(x2)
        f3 = self.c3(x3)
        f4 = self.c4(x4)

        # 隐性增强
        c2 = self.cam_enhance(f2)
        c3 = self.cam_enhance(f3)
        c4 = self.cam_enhance(f4)

        # 边界显性增强
        e2 = self.bdry_enhance(f2)
        e3 = self.bdry_enhance(f3)
        e4 = self.bdry_enhance(f4)

        # 多尺度上采样
        c3_up = F.interpolate(c3, size=f2.shape[2:], mode="bilinear", align_corners=True)
        c4_up = F.interpolate(c4, size=f2.shape[2:], mode="bilinear", align_corners=True)
        e3_up = F.interpolate(e3, size=f2.shape[2:], mode="bilinear", align_corners=True)
        e4_up = F.interpolate(e4, size=f2.shape[2:], mode="bilinear", align_corners=True)

        fuse_feat = torch.cat([
            c2 + e2,
            c3_up + e3_up,
            c4_up + e4_up
        ], dim=1)  # B,256*3,H,W

        f = self.fuse(fuse_feat)
        out = self.predict(f)

        out = F.interpolate(out, size=(H, W), mode="bilinear", align_corners=True)
        return out  # logits (B,1,H,W)


# ======================
# 损失 (BCE + Dice)
# ======================
def dice_loss(pred_logits, target):
    prob = torch.sigmoid(pred_logits)[:, 0]
    target = target.float()

    inter = (prob * target).sum(dim=(1, 2))
    union = prob.sum(dim=(1, 2)) + target.sum(dim=(1, 2))
    dice = (2 * inter + 1e-5) / (union + 1e-5)
    return 1 - dice.mean()


def total_loss(logits, masks):
    bce = F.binary_cross_entropy_with_logits(logits[:, 0], masks.float())
    dsc = dice_loss(logits, masks)
    return 0.5 * bce + 0.5 * dsc


# ======================
# 评估函数
# ======================
@torch.no_grad()
def evaluate_dataset(model, items, device, desc="Eval"):
    model.eval()
    transform = SimpleTransform(IMG_SIZE, is_train=False)

    preds, gts = [], []

    for img_path, mask_path, scene in items:
        img = Image.open(img_path).convert("RGB")
        mask = Image.open(mask_path).convert("L")

        img_t, mask_t = transform(img, mask)
        img_t = img_t.unsqueeze(0).to(device)

        logits = model(img_t)
        prob = torch.sigmoid(logits)[0, 0].cpu().numpy()

        preds.append(prob)
        gts.append(mask_t.numpy())

    preds = np.stack(preds)
    gts = np.stack(gts)

    metrics = compute_all_metrics(preds, gts)

    print(f"[{desc}] mIoU={metrics['mIoU']:.4f}, Dice={metrics['Dice']:.4f}, "
          f"S={metrics['S_measure']:.4f}, maxF={metrics['maxF']:.4f}, "
          f"MAE={metrics['MAE']:.4f}, PixelAcc={metrics['PixelAcc']:.4f}")

    return metrics


# ======================
# Base Training
# ======================
def train_base_pfnet():
    print("=" * 60)
    print("PFNet-like Base Training")
    print("=" * 60)

    train_items = load_split_list(BASE_TRAIN_LIST)
    val_items = load_split_list(BASE_VAL_LIST)

    train_data = ImageMaskDataset(train_items, IMG_SIZE, True)
    val_data = ImageMaskDataset(val_items, IMG_SIZE, False)

    train_loader = DataLoader(train_data, batch_size=BATCH_SIZE, shuffle=True, num_workers=4, pin_memory=True)

    model = PFNetLike().to(DEVICE)
    opt = torch.optim.Adam(model.parameters(), lr=BASE_LR)

    best_dice = 0.0
    no_improve = 0
    os.makedirs("checkpoints", exist_ok=True)
    ckpt_path = "checkpoints/pfnet_base.pth"

    for epoch in range(BASE_EPOCHS):
        model.train()
        total = 0

        for imgs, masks, scenes in train_loader:
            imgs, masks = imgs.to(DEVICE), masks.to(DEVICE)

            opt.zero_grad()
            logits = model(imgs)
            loss = total_loss(logits, masks)
            loss.backward()
            opt.step()

            total += loss.item() * imgs.size(0)

        avg = total / len(train_data)

        # eval
        val_metrics = evaluate_dataset(model, val_items, DEVICE, desc=f"Val E{epoch+1}")
        val_dice = val_metrics["Dice"]

        print(f"Epoch {epoch+1}/{BASE_EPOCHS} Loss={avg:.4f} | Val Dice={val_dice:.4f}")

        if val_dice > best_dice:
            best_dice = val_dice
            no_improve = 0
            torch.save(model.state_dict(), ckpt_path)
            print(f" -> New best! saved to {ckpt_path}")
        else:
            no_improve += 1
            if no_improve >= PATIENCE:
                print(f"Early stopping at epoch {epoch+1}")
                break

    print(f"\n[PFNet Base] Training Done. Best Dice={best_dice:.4f}")
    return ckpt_path


# ======================
# Novel 5-shot Finetune & Eval
# ======================
def finetune_and_eval_novel():
    print("\n" + "=" * 60)
    print("PFNet-like Novel 5-shot Fine-tuning")
    print("=" * 60)

    support_items = load_split_list(NOVEL_SUPPORT_LIST)
    query_items = load_split_list(NOVEL_QUERY_LIST)

    print(f"Novel Support = {len(support_items)}")
    print(f"Novel Query   = {len(query_items)}")

    # 加载 base 模型
    model = PFNetLike().to(DEVICE)
    ckpt = "checkpoints/pfnet_base.pth"
    model.load_state_dict(torch.load(ckpt, map_location=DEVICE))
    print(f"Loaded base weights: {ckpt}")

    support_loader = DataLoader(
        ImageMaskDataset(support_items, IMG_SIZE, True),
        batch_size=2, shuffle=True
    )

    opt = torch.optim.Adam(model.parameters(), lr=FT_LR)

    print("\nStart 5-shot Finetuning...")
    for epoch in range(FINETUNE_EPOCHS):
        model.train()
        total = 0
        for imgs, masks, scenes in support_loader:
            imgs, masks = imgs.to(DEVICE), masks.to(DEVICE)

            opt.zero_grad()
            logits = model(imgs)
            loss = total_loss(logits, masks)
            loss.backward()
            opt.step()

            total += loss.item() * imgs.size(0)

        print(f"[FT Ep {epoch+1}] Loss={total/len(support_loader.dataset):.4f}")

    # 保存微调后模型
    os.makedirs("checkpoints", exist_ok=True)
    ft_path = "checkpoints/pfnet_novel_5shot.pth"
    torch.save(model.state_dict(), ft_path)
    print(f"Saved finetuned weights to {ft_path}")

    # 在 novel query 上评估
    metrics = evaluate_dataset(model, query_items, DEVICE, desc="Novel 5-shot")

    print("\nFinal Novel Results:")
    for k, v in metrics.items():
        print(f"  {k}: {v:.4f}")

    return metrics


# ======================
# Main
# ======================
def main():
    print("PFNet-like Few-shot COD (Scheme B)")
    print(f"Using device: {DEVICE}\n")

    # Step 1: Base 训练
    train_base_pfnet()

    # Step 2: Novel 5-shot 微调 + 评估
    finetune_and_eval_novel()


if __name__ == "__main__":
    main()
