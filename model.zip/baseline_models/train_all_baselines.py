# -*- coding: utf-8 -*-
"""
统一基线训练脚本 - 合并所有基线模型
支持: DeepLabv3+, U-Net, U-Net++, SINet, C2FNet, PFNet, ZoomNet, PANet, HSNet

用法:
    python train_all_baselines.py --model all          # 训练所有模型
    python train_all_baselines.py --model deeplabv3plus  # 训练单个模型
    python train_all_baselines.py --model sinet,c2fnet   # 训练多个模型
"""
import os
import sys
import argparse
import random
from collections import defaultdict
import warnings
warnings.filterwarnings('ignore')

import numpy as np
from PIL import Image

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
import torch.optim as optim
from torchvision import models, transforms
from torchvision.transforms import functional as TF
from torch.optim.lr_scheduler import StepLR
import segmentation_models_pytorch as smp  # type: ignore
from metrics_cod import compute_all_metrics, MetricAccumulator  # type: ignore


# =========================
# 配置
# =========================
DATA_ROOT = "/root/FSL-COD数据集"
SPLIT_DIR = os.path.join(DATA_ROOT, "splits")

# 数据集划分文件
BASE_TRAIN_LIST = os.path.join(SPLIT_DIR, "base_train.txt")
BASE_VAL_LIST = os.path.join(SPLIT_DIR, "base_val.txt")
NOVEL_SUPPORT_LIST = os.path.join(SPLIT_DIR, "novel_support.txt")
NOVEL_QUERY_LIST = os.path.join(SPLIT_DIR, "novel_query.txt")

# 通用配置
IMG_SIZE = 352
BATCH_SIZE = 8
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
SEED = 42
SAVE_DIR = "./checkpoints"
os.makedirs(SAVE_DIR, exist_ok=True)

# 训练配置
BASE_EPOCHS = 50
FINETUNE_EPOCHS = 30
BASE_LR = 1e-3
FT_LR = 1e-5
PATIENCE = 10
K_SHOT = 5
N_QUERY = 1

# 所有支持的模型
ALL_MODELS = [
    # 通用分割
    "deeplabv3plus", "unet", "unetplusplus",
    # COD专用
    "sinet", "c2fnet", "pfnet", "zoomnet",
    # Few-shot
    "panet", "hsnet"
]

# 模型分类
GENERAL_MODELS = ["deeplabv3plus", "unet", "unetplusplus"]
COD_MODELS = ["sinet", "c2fnet", "pfnet", "zoomnet"]
FSS_MODELS = ["panet", "hsnet"]


def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


set_seed(SEED)


# =========================
# 通用工具
# =========================
def convert_path(path, data_root):
    """将路径转换为当前系统可用的路径"""
    import platform
    # 提取相对路径部分（从FSL-COD数据集开始）
    markers = ['FSL-COD数据集', 'FSL-COD数据集']
    for marker in markers:
        if marker in path:
            idx = path.find(marker)
            rel_path = path[idx + len(marker):]
            # 统一路径分隔符
            rel_path = rel_path.replace('\\', '/').replace('/', os.sep)
            if rel_path.startswith(os.sep):
                rel_path = rel_path[1:]
            return os.path.join(data_root, rel_path)
    # 如果找不到标记，尝试直接转换分隔符
    if platform.system() == 'Linux':
        path = path.replace('\\', '/')
    return path


def load_split_list(txt_path, data_root=None):
    """读取 txt 文件，返回 list[(img, mask, scene)]，自动转换路径"""
    if data_root is None:
        # 自动检测数据集根目录
        txt_dir = os.path.dirname(txt_path)
        data_root = os.path.dirname(txt_dir)  # splits的父目录就是数据集目录
    
    items = []
    with open(txt_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split()
            if len(parts) >= 3:
                img, mask, scene = parts[0], parts[1], parts[2]
            else:
                img, mask, scene = parts[0], parts[1], "unknown"
            # 转换路径
            img = convert_path(img, data_root)
            mask = convert_path(mask, data_root)
            items.append((img, mask, scene))
    return items


class SimpleTransform:
    def __init__(self, img_size=352, is_train=True):
        self.img_size = img_size
        self.is_train = is_train
        self.to_tensor = transforms.ToTensor()
        self.normalize = transforms.Normalize(
            mean=[0.485, 0.456, 0.406],
            std=[0.229, 0.224, 0.225]
        )

    def __call__(self, img, mask):
        img = img.resize((self.img_size, self.img_size), Image.BILINEAR)
        mask = mask.resize((self.img_size, self.img_size), Image.NEAREST)

        img = self.to_tensor(img)
        img = self.normalize(img)

        mask = np.array(mask, dtype=np.float32)
        if mask.max() > 1:
            mask = (mask > 127.5).astype(np.float32)
        else:
            mask = (mask > 0.5).astype(np.float32)
        mask = torch.from_numpy(mask)

        return img, mask


class ImageMaskDataset(Dataset):
    """普通监督分割数据集"""
    def __init__(self, items, img_size=352, is_train=True):
        self.items = items
        self.transform = SimpleTransform(img_size, is_train)

    def __len__(self):
        return len(self.items)

    def __getitem__(self, idx):
        img_path, mask_path, scene = self.items[idx]
        img = Image.open(img_path).convert("RGB")
        mask = Image.open(mask_path).convert("L")
        img, mask = self.transform(img, mask)
        return img, mask, scene


class FewShotEpisodeDataset(Dataset):
    """Few-shot Episode 数据集"""
    def __init__(self, split_list, img_size=352, k_shot=5, n_query=1):
        super().__init__()
        self.k_shot = k_shot
        self.n_query = n_query
        self.transform = SimpleTransform(img_size=img_size, is_train=True)

        self.by_scene = defaultdict(list)
        for img, mask, scene in split_list:
            self.by_scene[scene].append((img, mask))
        self.scenes = list(self.by_scene.keys())

    def __len__(self):
        return 100000

    def _load_img_mask(self, img_path, mask_path):
        img = Image.open(img_path).convert("RGB")
        mask = Image.open(mask_path).convert("L")
        return self.transform(img, mask)

    def __getitem__(self, idx):
        scene = random.choice(self.scenes)
        pairs = self.by_scene[scene]

        min_required = self.k_shot + self.n_query
        if len(pairs) < min_required:
            pairs = pairs * (min_required // len(pairs) + 1)

        idxs = list(range(len(pairs)))
        random.shuffle(idxs)
        support_idx = idxs[:self.k_shot]
        query_idx = idxs[self.k_shot:self.k_shot + self.n_query]

        support_imgs, support_masks = [], []
        query_imgs, query_masks = [], []

        for i in support_idx:
            img_path, mask_path = pairs[i]
            img, mask = self._load_img_mask(img_path, mask_path)
            support_imgs.append(img)
            support_masks.append(mask)

        for i in query_idx:
            img_path, mask_path = pairs[i]
            img, mask = self._load_img_mask(img_path, mask_path)
            query_imgs.append(img)
            query_masks.append(mask)

        support_imgs = torch.stack(support_imgs, dim=0)
        support_masks = torch.stack(support_masks, dim=0)
        query_imgs = torch.stack(query_imgs, dim=0)
        query_masks = torch.stack(query_masks, dim=0)

        return support_imgs, support_masks, query_imgs, query_masks, scene


# =========================
# 损失函数
# =========================
def dice_loss(pred_logits, target):
    prob = torch.sigmoid(pred_logits)
    if prob.dim() == 4 and prob.size(1) == 1:
        prob = prob[:, 0]
    target = target.float()
    inter = (prob * target).sum(dim=(1, 2))
    union = prob.sum(dim=(1, 2)) + target.sum(dim=(1, 2))
    dice = (2 * inter + 1e-5) / (union + 1e-5)
    return 1 - dice.mean()


def bce_dice_loss(pred_logits, target):
    if pred_logits.dim() == 4 and pred_logits.size(1) == 1:
        bce = F.binary_cross_entropy_with_logits(pred_logits[:, 0], target.float())
    else:
        bce = F.binary_cross_entropy_with_logits(pred_logits, target.float())
    dl = dice_loss(pred_logits, target)
    return 0.5 * bce + 0.5 * dl


def fss_dice_loss(pred, target):
    pred_fg = torch.softmax(pred, dim=1)[:, 1]
    target = target.float()
    inter = (pred_fg * target).sum(dim=(1, 2))
    union = pred_fg.sum(dim=(1, 2)) + target.sum(dim=(1, 2))
    dice = (2 * inter + 1e-5) / (union + 1e-5)
    return 1 - dice.mean()


def fss_bce_dice_loss(logits, masks):
    ce = F.cross_entropy(logits, masks.long())
    dl = fss_dice_loss(logits, masks)
    return ce + dl


# =========================
# COD 模型定义
# =========================
class ConvBNReLU(nn.Module):
    def __init__(self, in_c, out_c, k=3, s=1, p=1):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(in_c, out_c, kernel_size=k, stride=s, padding=p, bias=False),
            nn.BatchNorm2d(out_c),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        return self.block(x)


# --- SINet ---
class ReverseAttentionBlock(nn.Module):
    def __init__(self, in_c, inter_c):
        super().__init__()
        self.conv = nn.Sequential(
            ConvBNReLU(in_c, inter_c, 3, 1, 1),
            ConvBNReLU(inter_c, inter_c, 3, 1, 1),
        )
        self.pred = nn.Conv2d(inter_c, 1, kernel_size=3, padding=1)

    def forward(self, feat, pred_coarse_up):
        att = torch.sigmoid(pred_coarse_up)
        rev = 1.0 - att
        rev = rev.expand_as(feat)
        x = feat * rev
        x = self.conv(x)
        pred = self.pred(x)
        return pred


class SINetLike(nn.Module):
    def __init__(self):
        super().__init__()
        resnet = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V1)
        self.layer0 = nn.Sequential(resnet.conv1, resnet.bn1, resnet.relu, resnet.maxpool)
        self.layer1 = resnet.layer1
        self.layer2 = resnet.layer2
        self.layer3 = resnet.layer3
        self.layer4 = resnet.layer4
        self.conv4 = ConvBNReLU(2048, 256, 3, 1, 1)
        self.conv3 = ConvBNReLU(1024, 256, 3, 1, 1)
        self.conv2 = ConvBNReLU(512, 256, 3, 1, 1)
        self.pred4 = nn.Conv2d(256, 1, kernel_size=3, padding=1)
        self.ra3 = ReverseAttentionBlock(256, 256)
        self.ra2 = ReverseAttentionBlock(256, 256)

    def forward(self, x):
        H, W = x.size(2), x.size(3)
        x0 = self.layer0(x)
        x1 = self.layer1(x0)
        x2 = self.layer2(x1)
        x3 = self.layer3(x2)
        x4 = self.layer4(x3)
        f4 = self.conv4(x4)
        p4 = self.pred4(f4)
        f3 = self.conv3(x3)
        p4_up = F.interpolate(p4, size=f3.shape[2:], mode="bilinear", align_corners=True)
        p3 = self.ra3(f3, p4_up)
        f2 = self.conv2(x2)
        p3_up = F.interpolate(p3, size=f2.shape[2:], mode="bilinear", align_corners=True)
        p2 = self.ra2(f2, p3_up)
        pred_final = F.interpolate(p2, size=(H, W), mode="bilinear", align_corners=True)
        return pred_final


# --- C2FNet ---
class CoarseRefineBlock(nn.Module):
    def __init__(self, in_c, mid_c=256):
        super().__init__()
        self.conv = nn.Sequential(ConvBNReLU(in_c, mid_c), ConvBNReLU(mid_c, mid_c))
        self.pred = nn.Conv2d(mid_c, 1, 3, padding=1)

    def forward(self, feat_cat):
        x = self.conv(feat_cat)
        return self.pred(x)


class C2FNetLike(nn.Module):
    def __init__(self):
        super().__init__()
        resnet = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V1)
        self.layer0 = nn.Sequential(resnet.conv1, resnet.bn1, resnet.relu, resnet.maxpool)
        self.layer1 = resnet.layer1
        self.layer2 = resnet.layer2
        self.layer3 = resnet.layer3
        self.layer4 = resnet.layer4
        self.c2 = ConvBNReLU(512, 256)
        self.c3 = ConvBNReLU(1024, 256)
        self.c4 = ConvBNReLU(2048, 256)
        self.coarse_conv = ConvBNReLU(256, 256)
        self.coarse_pred = nn.Conv2d(256, 1, 3, padding=1)
        self.refine3 = CoarseRefineBlock(256 + 1, 256)
        self.refine2 = CoarseRefineBlock(256 + 1, 256)

    def forward(self, x):
        H, W = x.size(2), x.size(3)
        x0 = self.layer0(x)
        x1 = self.layer1(x0)
        x2 = self.layer2(x1)
        x3 = self.layer3(x2)
        x4 = self.layer4(x3)
        f2, f3, f4 = self.c2(x2), self.c3(x3), self.c4(x4)
        c4 = self.coarse_conv(f4)
        logit4 = self.coarse_pred(c4)
        logit4_up = F.interpolate(logit4, size=f3.shape[2:], mode="bilinear", align_corners=True)
        logit3 = self.refine3(torch.cat([f3, logit4_up], dim=1))
        logit3_up = F.interpolate(logit3, size=f2.shape[2:], mode="bilinear", align_corners=True)
        logit2 = self.refine2(torch.cat([f2, logit3_up], dim=1))
        return F.interpolate(logit2, size=(H, W), mode="bilinear", align_corners=True)


# --- PFNet ---
class AttentionEnhancer(nn.Module):
    def __init__(self, in_c):
        super().__init__()
        self.conv1 = ConvBNReLU(in_c, in_c)
        self.conv2 = nn.Conv2d(in_c, 1, 1)

    def forward(self, feat):
        x = self.conv1(feat)
        att = torch.sigmoid(self.conv2(x))
        return feat * (1 + att)


class BoundaryEnhancer(nn.Module):
    def __init__(self, in_c):
        super().__init__()
        self.sobel_x = nn.Conv2d(in_c, in_c, kernel_size=3, padding=1, bias=False)
        self.sobel_y = nn.Conv2d(in_c, in_c, kernel_size=3, padding=1, bias=False)
        sobel_x = torch.tensor([[[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]]], dtype=torch.float32)
        sobel_y = sobel_x.transpose(-1, -2)
        self.sobel_x.weight.data = sobel_x.repeat(in_c, 1, 1, 1)
        self.sobel_y.weight.data = sobel_y.repeat(in_c, 1, 1, 1)
        for p in self.sobel_x.parameters():
            p.requires_grad = False
        for p in self.sobel_y.parameters():
            p.requires_grad = False
        self.conv = ConvBNReLU(in_c, in_c)

    def forward(self, feat):
        gx = self.sobel_x(feat)
        gy = self.sobel_y(feat)
        edges = torch.abs(gx) + torch.abs(gy)
        return self.conv(edges)


class PFNetLike(nn.Module):
    def __init__(self):
        super().__init__()
        resnet = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V1)
        self.layer0 = nn.Sequential(resnet.conv1, resnet.bn1, resnet.relu, resnet.maxpool)
        self.layer1 = resnet.layer1
        self.layer2 = resnet.layer2
        self.layer3 = resnet.layer3
        self.layer4 = resnet.layer4
        self.c2 = ConvBNReLU(512, 256)
        self.c3 = ConvBNReLU(1024, 256)
        self.c4 = ConvBNReLU(2048, 256)
        self.cam_enhance = AttentionEnhancer(256)
        self.bdry_enhance = BoundaryEnhancer(256)
        self.fuse = nn.Sequential(ConvBNReLU(256 * 3, 256), ConvBNReLU(256, 64))
        self.predict = nn.Conv2d(64, 1, 3, padding=1)

    def forward(self, x):
        H, W = x.size(2), x.size(3)
        x0 = self.layer0(x)
        x1 = self.layer1(x0)
        x2 = self.layer2(x1)
        x3 = self.layer3(x2)
        x4 = self.layer4(x3)
        f2, f3, f4 = self.c2(x2), self.c3(x3), self.c4(x4)
        c2, c3, c4 = self.cam_enhance(f2), self.cam_enhance(f3), self.cam_enhance(f4)
        e2, e3, e4 = self.bdry_enhance(f2), self.bdry_enhance(f3), self.bdry_enhance(f4)
        c3_up = F.interpolate(c3, size=f2.shape[2:], mode="bilinear", align_corners=True)
        c4_up = F.interpolate(c4, size=f2.shape[2:], mode="bilinear", align_corners=True)
        e3_up = F.interpolate(e3, size=f2.shape[2:], mode="bilinear", align_corners=True)
        e4_up = F.interpolate(e4, size=f2.shape[2:], mode="bilinear", align_corners=True)
        fuse_feat = torch.cat([c2 + e2, c3_up + e3_up, c4_up + e4_up], dim=1)
        f = self.fuse(fuse_feat)
        out = self.predict(f)
        return F.interpolate(out, size=(H, W), mode="bilinear", align_corners=True)


# --- ZoomNet ---
class LocalRefinementModule(nn.Module):
    def __init__(self, in_c):
        super().__init__()
        self.conv1 = ConvBNReLU(in_c, in_c)
        self.conv2 = ConvBNReLU(in_c, in_c)
        self.att = nn.Sequential(
            nn.Conv2d(in_c, in_c // 4, 1), nn.ReLU(inplace=True),
            nn.Conv2d(in_c // 4, in_c, 1), nn.Sigmoid()
        )

    def forward(self, feat):
        x = self.conv1(feat)
        att = self.att(x)
        x = x * att + feat
        return self.conv2(x)


class AdaptiveUpsample(nn.Module):
    def __init__(self, in_c, out_c):
        super().__init__()
        self.conv = ConvBNReLU(in_c, out_c)
        self.weight_gen = nn.Sequential(
            nn.AdaptiveAvgPool2d(1), nn.Conv2d(in_c, out_c, 1), nn.Sigmoid()
        )

    def forward(self, feat, target_size):
        weight = self.weight_gen(feat)
        up = F.interpolate(feat, size=target_size, mode="bilinear", align_corners=True)
        up = self.conv(up)
        return up * weight


class ZoomNetLike(nn.Module):
    def __init__(self):
        super().__init__()
        resnet = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V1)
        self.layer0 = nn.Sequential(resnet.conv1, resnet.bn1, resnet.relu, resnet.maxpool)
        self.layer1 = resnet.layer1
        self.layer2 = resnet.layer2
        self.layer3 = resnet.layer3
        self.layer4 = resnet.layer4
        self.c2 = ConvBNReLU(512, 256)
        self.c3 = ConvBNReLU(1024, 256)
        self.c4 = ConvBNReLU(2048, 256)
        self.local_refine2 = LocalRefinementModule(256)
        self.local_refine3 = LocalRefinementModule(256)
        self.local_refine4 = LocalRefinementModule(256)
        self.adaptive_up3 = AdaptiveUpsample(256, 256)
        self.adaptive_up4 = AdaptiveUpsample(256, 256)
        self.fuse = nn.Sequential(ConvBNReLU(256 * 3, 256), ConvBNReLU(256, 64))
        self.predict = nn.Conv2d(64, 1, 3, padding=1)

    def forward(self, x):
        H, W = x.size(2), x.size(3)
        x0 = self.layer0(x)
        x1 = self.layer1(x0)
        x2 = self.layer2(x1)
        x3 = self.layer3(x2)
        x4 = self.layer4(x3)
        f2, f3, f4 = self.c2(x2), self.c3(x3), self.c4(x4)
        r2 = self.local_refine2(f2)
        r3 = self.local_refine3(f3)
        r4 = self.local_refine4(f4)
        r3_up = self.adaptive_up3(r3, r2.shape[2:])
        r4_up = self.adaptive_up4(r4, r2.shape[2:])
        fuse_feat = torch.cat([r2, r3_up, r4_up], dim=1)
        fused = self.fuse(fuse_feat)
        out = self.predict(fused)
        return F.interpolate(out, size=(H, W), mode="bilinear", align_corners=True)


# =========================
# Few-shot 模型定义
# =========================
# --- PANet ---
class PANetLike(nn.Module):
    def __init__(self):
        super().__init__()
        resnet = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V1)
        self.encoder = nn.Sequential(
            resnet.conv1, resnet.bn1, resnet.relu, resnet.maxpool,
            resnet.layer1, resnet.layer2, resnet.layer3, resnet.layer4,
        )
        self.feat_dim = 2048
        self.proj = nn.Conv2d(2048, 2048, kernel_size=1)

    def extract_feat(self, x):
        feat = self.encoder(x)
        return self.proj(feat)

    def get_prototype(self, supp_feat, supp_mask):
        K, C, Hf, Wf = supp_feat.shape
        supp_mask = supp_mask.unsqueeze(1).float()
        supp_mask = F.interpolate(supp_mask, size=(Hf, Wf), mode='nearest')
        fg_mask, bg_mask = supp_mask, 1.0 - supp_mask
        fg_proto = (supp_feat * fg_mask).sum(dim=(0, 2, 3)) / (fg_mask.sum(dim=(0, 2, 3)) + 1e-5)
        bg_proto = (supp_feat * bg_mask).sum(dim=(0, 2, 3)) / (bg_mask.sum(dim=(0, 2, 3)) + 1e-5)
        return torch.stack([bg_proto, fg_proto], dim=0)

    def forward(self, supp_imgs, supp_masks, qry_imgs):
        supp_feats = self.extract_feat(supp_imgs)
        qry_feats = self.extract_feat(qry_imgs)
        prototypes = self.get_prototype(supp_feats, supp_masks)
        Qf, C, Hf, Wf = qry_feats.shape
        qry_flat = qry_feats.view(Qf, C, -1)
        proto = prototypes.unsqueeze(0).repeat(Qf, 1, 1)
        qry_norm = F.normalize(qry_flat, dim=1)
        proto_norm = F.normalize(proto, dim=2)
        logits = torch.bmm(proto_norm, qry_norm).view(Qf, 2, Hf, Wf)
        return F.interpolate(logits, size=(supp_masks.size(-2), supp_masks.size(-1)),
                             mode='bilinear', align_corners=False)


# --- HSNet ---
class Correlation:
    @classmethod
    def multilayer_correlation(cls, query_feats, support_feats, support_mask, stack_ids):
        eps = 1e-5
        corrs = []
        for idx, (query_feat, support_feat) in enumerate(zip(query_feats, support_feats)):
            K, C, Hs, Ws = support_feat.shape
            _, _, Hq, Wq = query_feat.shape
            s_mask = support_mask.unsqueeze(1).float()
            s_mask = F.interpolate(s_mask, size=(Hs, Ws), mode='nearest')
            s_feat_masked = support_feat * s_mask
            prototype = s_feat_masked.sum(dim=(2, 3)) / (s_mask.sum(dim=(2, 3)) + eps)
            prototype = prototype.mean(dim=0, keepdim=True)
            q_flat = query_feat.view(1, C, -1)
            q_norm = F.normalize(q_flat, dim=1)
            p_norm = F.normalize(prototype, dim=1)
            corr = torch.bmm(p_norm.unsqueeze(1), q_norm).squeeze(1).view(1, 1, Hq, Wq)
            corrs.append(corr)
        return torch.cat(corrs, dim=1)


class HPNLearner(nn.Module):
    def __init__(self, inch):
        super().__init__()
        def make_block(in_c, out_c):
            return nn.Sequential(
                nn.Conv2d(in_c, out_c[0], 3, 1, 1, bias=False), nn.BatchNorm2d(out_c[0]), nn.ReLU(inplace=True),
                nn.Conv2d(out_c[0], out_c[1], 3, 1, 1, bias=False), nn.BatchNorm2d(out_c[1]), nn.ReLU(inplace=True),
            )
        self.decoder1 = make_block(inch, [128, 128])
        self.decoder2 = make_block(128, [64, 64])
        self.decoder3 = make_block(64, [32, 32])
        self.predictor = nn.Conv2d(32, 2, 3, 1, 1)

    def forward(self, corr):
        x = self.decoder1(corr)
        x = F.interpolate(x, scale_factor=2, mode='bilinear', align_corners=True)
        x = self.decoder2(x)
        x = F.interpolate(x, scale_factor=2, mode='bilinear', align_corners=True)
        x = self.decoder3(x)
        x = F.interpolate(x, scale_factor=2, mode='bilinear', align_corners=True)
        return self.predictor(x)


class HSNetLike(nn.Module):
    def __init__(self):
        super().__init__()
        resnet = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V1)
        self.layer0 = nn.Sequential(resnet.conv1, resnet.bn1, resnet.relu, resnet.maxpool)
        self.layer1 = resnet.layer1
        self.layer2 = resnet.layer2
        self.layer3 = resnet.layer3
        self.layer4 = resnet.layer4
        for param in self.layer0.parameters():
            param.requires_grad = False
        for param in self.layer1.parameters():
            param.requires_grad = False
        self.hpn_learner = HPNLearner(inch=3)

    def extract_feats(self, x):
        x = self.layer0(x)
        feat1 = self.layer1(x)
        feat2 = self.layer2(feat1)
        feat3 = self.layer3(feat2)
        feat4 = self.layer4(feat3)
        return [feat2, feat3, feat4]

    def forward(self, supp_imgs, supp_masks, qry_imgs):
        qry_feats = self.extract_feats(qry_imgs)
        supp_feats = self.extract_feats(supp_imgs)
        corr = Correlation.multilayer_correlation(qry_feats, supp_feats, supp_masks, [0, 1, 2])
        logits = self.hpn_learner(corr)
        return F.interpolate(logits, size=(supp_masks.size(-2), supp_masks.size(-1)),
                             mode='bilinear', align_corners=True)


# =========================
# 模型构建
# =========================
def build_model(model_name):
    model_name = model_name.lower()
    if model_name == "deeplabv3plus":
        return smp.DeepLabV3Plus(encoder_name="resnet50", encoder_weights="imagenet", in_channels=3, classes=1)
    elif model_name == "unet":
        return smp.Unet(encoder_name="resnet34", encoder_weights="imagenet", in_channels=3, classes=1)
    elif model_name == "unetplusplus":
        return smp.UnetPlusPlus(encoder_name="resnet34", encoder_weights="imagenet", in_channels=3, classes=1)
    elif model_name == "sinet":
        return SINetLike()
    elif model_name == "c2fnet":
        return C2FNetLike()
    elif model_name == "pfnet":
        return PFNetLike()
    elif model_name == "zoomnet":
        return ZoomNetLike()
    elif model_name == "panet":
        return PANetLike()
    elif model_name == "hsnet":
        return HSNetLike()
    else:
        raise ValueError(f"Unknown model: {model_name}")


# =========================
# 评估函数
# =========================
@torch.no_grad()
def evaluate_cod(model, items, device, desc="Eval"):
    """COD模型评估"""
    model.eval()
    transform = SimpleTransform(IMG_SIZE, is_train=False)
    preds, gts = [], []
    for img_path, mask_path, scene in items:
        img = Image.open(img_path).convert("RGB")
        mask = Image.open(mask_path).convert("L")
        img_t, mask_t = transform(img, mask)
        img_t = img_t.unsqueeze(0).to(device)
        logits = model(img_t)
        prob = torch.sigmoid(logits)
        if prob.dim() == 4:
            prob = prob[:, 0] if prob.size(1) == 1 else prob
        preds.append(prob.cpu().numpy()[0])
        gts.append(mask_t.numpy())
    preds, gts = np.stack(preds), np.stack(gts)
    metrics = compute_all_metrics(preds, gts)
    print(f"[{desc}] mIoU={metrics['mIoU']:.4f}, Dice={metrics['Dice']:.4f}, "
          f"S={metrics['S_measure']:.4f}, maxF={metrics['maxF']:.4f}")
    return metrics


@torch.no_grad()
def evaluate_fss(model, val_items, support_items, device, desc="Eval"):
    """Few-shot模型评估"""
    model.eval()
    support_by_scene = defaultdict(list)
    for img, mask, scene in support_items:
        support_by_scene[scene].append((img, mask))
    transform = SimpleTransform(img_size=IMG_SIZE, is_train=False)
    all_preds, all_gts = [], []
    for img_path, mask_path, scene in val_items:
        qry_img = Image.open(img_path).convert("RGB")
        qry_mask = Image.open(mask_path).convert("L")
        qry_img, qry_mask = transform(qry_img, qry_mask)
        qry_img = qry_img.unsqueeze(0).to(device)
        qry_mask_np = qry_mask.numpy()
        if scene in support_by_scene:
            supp_pairs = support_by_scene[scene][:K_SHOT]
        else:
            rand_scene = random.choice(list(support_by_scene.keys()))
            supp_pairs = support_by_scene[rand_scene][:K_SHOT]
        supp_imgs, supp_masks = [], []
        for sp_img, sp_mask in supp_pairs:
            s_img = Image.open(sp_img).convert("RGB")
            s_mask = Image.open(sp_mask).convert("L")
            s_img, s_mask = transform(s_img, s_mask)
            supp_imgs.append(s_img)
            supp_masks.append(s_mask)
        while len(supp_imgs) < K_SHOT:
            supp_imgs.append(supp_imgs[0])
            supp_masks.append(supp_masks[0])
        supp_imgs = torch.stack(supp_imgs).to(device)
        supp_masks = torch.stack(supp_masks).to(device)
        logits = model(supp_imgs, supp_masks, qry_img)
        pred_prob = torch.softmax(logits, dim=1)[:, 1]
        all_preds.append(pred_prob.cpu().numpy()[0])
        all_gts.append(qry_mask_np)
    all_preds, all_gts = np.stack(all_preds), np.stack(all_gts)
    metrics = compute_all_metrics(all_preds, all_gts)
    print(f"[{desc}] mIoU={metrics['mIoU']:.4f}, Dice={metrics['Dice']:.4f}, "
          f"S={metrics['S_measure']:.4f}, maxF={metrics['maxF']:.4f}")
    return metrics


# =========================
# 训练函数: 通用分割模型 (Base + Novel 5-shot)
# =========================
def train_general_model(model_name):
    print("=" * 60)
    print(f"训练通用分割模型: {model_name.upper()} (Base + Novel 5-shot)")
    print("=" * 60)

    # --- Base 监督训练 ---
    train_items = load_split_list(BASE_TRAIN_LIST)
    val_items = load_split_list(BASE_VAL_LIST)
    train_data = ImageMaskDataset(train_items, IMG_SIZE, True)
    train_loader = DataLoader(train_data, batch_size=BATCH_SIZE, shuffle=True, num_workers=4, pin_memory=True)

    model = build_model(model_name).to(DEVICE)
    optimizer = optim.AdamW(model.parameters(), lr=BASE_LR, weight_decay=1e-4)
    scheduler = StepLR(optimizer, step_size=20, gamma=0.5)

    best_dice, no_improve = 0.0, 0
    base_ckpt = os.path.join(SAVE_DIR, f"{model_name}_base.pth")

    for epoch in range(BASE_EPOCHS):
        model.train()
        total_loss = 0.0
        for imgs, masks, _ in train_loader:
            imgs, masks = imgs.to(DEVICE), masks.to(DEVICE)
            optimizer.zero_grad()
            logits = model(imgs)
            loss = bce_dice_loss(logits, masks)
            loss.backward()
            optimizer.step()
            total_loss += loss.item() * imgs.size(0)
        scheduler.step()
        avg_loss = total_loss / len(train_data)

        val_metrics = evaluate_cod(model, val_items, DEVICE, desc=f"Val E{epoch+1}")
        val_dice = val_metrics["Dice"]
        print(f"Base Epoch {epoch+1}/{BASE_EPOCHS} Loss={avg_loss:.4f} | Val Dice={val_dice:.4f}")

        if val_dice > best_dice:
            best_dice = val_dice
            no_improve = 0
            torch.save(model.state_dict(), base_ckpt)
            print(f" -> New best!")
        else:
            no_improve += 1
            if no_improve >= PATIENCE:
                print(f"Early stopping at epoch {epoch+1}")
                break

    print(f"\n[{model_name} Base] Done. Best Dice={best_dice:.4f}")

    # --- Novel 5-shot 微调 ---
    print(f"\n开始 {model_name} Novel 5-shot 微调...")
    model.load_state_dict(torch.load(base_ckpt, map_location=DEVICE))

    support_items = load_split_list(NOVEL_SUPPORT_LIST)
    query_items = load_split_list(NOVEL_QUERY_LIST)
    support_loader = DataLoader(ImageMaskDataset(support_items, IMG_SIZE, True), batch_size=2, shuffle=True)

    optimizer = optim.Adam(model.parameters(), lr=FT_LR)

    for epoch in range(FINETUNE_EPOCHS):
        model.train()
        for imgs, masks, _ in support_loader:
            imgs, masks = imgs.to(DEVICE), masks.to(DEVICE)
            optimizer.zero_grad()
            logits = model(imgs)
            loss = bce_dice_loss(logits, masks)
            loss.backward()
            optimizer.step()

    ft_ckpt = os.path.join(SAVE_DIR, f"{model_name}_5shot.pth")
    torch.save(model.state_dict(), ft_ckpt)

    # Novel 测试集评估
    metrics = evaluate_cod(model, query_items, DEVICE, desc=f"{model_name} Novel 5-shot")
    print(f"\n[{model_name} Novel] Final Dice={metrics['Dice']:.4f}, mIoU={metrics['mIoU']:.4f}")
    return ft_ckpt, metrics['Dice']


# =========================
# 训练函数: COD模型 (Base + Novel 5-shot)
# =========================
def train_cod_model(model_name):
    print("=" * 60)
    print(f"训练COD模型: {model_name.upper()} (Base + Novel 5-shot)")
    print("=" * 60)

    # --- Base 训练 ---
    train_items = load_split_list(BASE_TRAIN_LIST)
    val_items = load_split_list(BASE_VAL_LIST)
    train_data = ImageMaskDataset(train_items, IMG_SIZE, True)
    train_loader = DataLoader(train_data, batch_size=BATCH_SIZE, shuffle=True, num_workers=4, pin_memory=True)

    model = build_model(model_name).to(DEVICE)
    optimizer = optim.Adam(model.parameters(), lr=5e-5)

    best_dice, no_improve = 0.0, 0
    base_ckpt = os.path.join(SAVE_DIR, f"{model_name}_base.pth")

    for epoch in range(BASE_EPOCHS):
        model.train()
        total_loss = 0.0
        for imgs, masks, _ in train_loader:
            imgs, masks = imgs.to(DEVICE), masks.to(DEVICE)
            optimizer.zero_grad()
            logits = model(imgs)
            loss = bce_dice_loss(logits, masks)
            loss.backward()
            optimizer.step()
            total_loss += loss.item() * imgs.size(0)
        avg_loss = total_loss / len(train_data)

        val_metrics = evaluate_cod(model, val_items, DEVICE, desc=f"Val E{epoch+1}")
        val_dice = val_metrics["Dice"]
        print(f"Base Epoch {epoch+1}/{BASE_EPOCHS} Loss={avg_loss:.4f} | Val Dice={val_dice:.4f}")

        if val_dice > best_dice:
            best_dice = val_dice
            no_improve = 0
            torch.save(model.state_dict(), base_ckpt)
            print(f" -> New best!")
        else:
            no_improve += 1
            if no_improve >= PATIENCE:
                print(f"Early stopping at epoch {epoch+1}")
                break

    print(f"\n[{model_name} Base] Done. Best Dice={best_dice:.4f}")

    # --- Novel 5-shot 微调 ---
    print(f"\n开始 {model_name} Novel 5-shot 微调...")
    model.load_state_dict(torch.load(base_ckpt, map_location=DEVICE))

    support_items = load_split_list(NOVEL_SUPPORT_LIST)
    query_items = load_split_list(NOVEL_QUERY_LIST)
    support_loader = DataLoader(ImageMaskDataset(support_items, IMG_SIZE, True), batch_size=2, shuffle=True)

    optimizer = optim.Adam(model.parameters(), lr=FT_LR)

    for epoch in range(FINETUNE_EPOCHS):
        model.train()
        for imgs, masks, _ in support_loader:
            imgs, masks = imgs.to(DEVICE), masks.to(DEVICE)
            optimizer.zero_grad()
            logits = model(imgs)
            loss = bce_dice_loss(logits, masks)
            loss.backward()
            optimizer.step()

    ft_ckpt = os.path.join(SAVE_DIR, f"{model_name}_5shot.pth")
    torch.save(model.state_dict(), ft_ckpt)

    # Novel 测试
    metrics = evaluate_cod(model, query_items, DEVICE, desc=f"{model_name} Novel 5-shot")
    print(f"\n[{model_name} Novel] Final Dice={metrics['Dice']:.4f}, mIoU={metrics['mIoU']:.4f}")
    return ft_ckpt, metrics['Dice']


# =========================
# 训练函数: Few-shot模型 (Episode训练)
# =========================
def train_fss_model(model_name):
    print("=" * 60)
    print(f"训练Few-shot模型: {model_name.upper()} (Episode训练)")
    print("=" * 60)

    base_train_items = load_split_list(BASE_TRAIN_LIST)
    base_val_items = load_split_list(BASE_VAL_LIST)

    train_dataset = FewShotEpisodeDataset(base_train_items, img_size=IMG_SIZE, k_shot=K_SHOT, n_query=N_QUERY)
    train_loader = DataLoader(train_dataset, batch_size=1, shuffle=False)

    model = build_model(model_name).to(DEVICE)
    if model_name == "hsnet":
        trainable_params = [p for p in model.parameters() if p.requires_grad]
        optimizer = optim.Adam(trainable_params, lr=5e-5)
    else:
        optimizer = optim.Adam(model.parameters(), lr=5e-5)

    num_epochs, steps_per_epoch = 30, 200
    best_dice, no_improve = 0.0, 0
    ckpt_path = os.path.join(SAVE_DIR, f"{model_name}_base.pth")

    for epoch in range(num_epochs):
        model.train()
        running_loss = 0.0
        for step, batch in enumerate(train_loader):
            if step >= steps_per_epoch:
                break
            supp_imgs, supp_masks, qry_imgs, qry_masks, _ = batch
            supp_imgs = supp_imgs.squeeze(0).to(DEVICE)
            supp_masks = supp_masks.squeeze(0).to(DEVICE)
            qry_imgs = qry_imgs.squeeze(0).to(DEVICE)
            qry_masks = qry_masks.squeeze(0).to(DEVICE)

            optimizer.zero_grad()
            logits = model(supp_imgs, supp_masks, qry_imgs)
            loss = fss_bce_dice_loss(logits, qry_masks)
            loss.backward()
            optimizer.step()
            running_loss += loss.item()

        avg_loss = running_loss / steps_per_epoch
        metrics = evaluate_fss(model, base_val_items, base_train_items, DEVICE, desc=f"Val E{epoch+1}")
        val_dice = metrics['Dice']
        print(f"Epoch {epoch+1}/{num_epochs} Loss={avg_loss:.4f} | Val Dice={val_dice:.4f}")

        if val_dice > best_dice:
            best_dice = val_dice
            no_improve = 0
            torch.save(model.state_dict(), ckpt_path)
            print(f" -> New best!")
        else:
            no_improve += 1
            if no_improve >= PATIENCE:
                print(f"Early stopping at epoch {epoch+1}")
                break

    print(f"\n[{model_name} Base] Done. Best Dice={best_dice:.4f}")

    # Novel 测试
    model.load_state_dict(torch.load(ckpt_path, map_location=DEVICE))
    novel_support = load_split_list(NOVEL_SUPPORT_LIST)
    novel_query = load_split_list(NOVEL_QUERY_LIST)
    metrics = evaluate_fss(model, novel_query, novel_support, DEVICE, desc=f"{model_name} Novel 5-shot")
    print(f"\n[{model_name} Novel] Final Dice={metrics['Dice']:.4f}, mIoU={metrics['mIoU']:.4f}")
    return ckpt_path, metrics['Dice']


# =========================
# 训练调度器
# =========================
def train_model(model_name):
    model_name = model_name.lower()
    if model_name in GENERAL_MODELS:
        return train_general_model(model_name)
    elif model_name in COD_MODELS:
        return train_cod_model(model_name)
    elif model_name in FSS_MODELS:
        return train_fss_model(model_name)
    else:
        raise ValueError(f"Unknown model: {model_name}")


# =========================
# 主函数
# =========================
def main():
    parser = argparse.ArgumentParser(description="统一基线训练脚本")
    parser.add_argument("--model", type=str, default="all",
                        help="模型名称，可选: all, " + ", ".join(ALL_MODELS) + "，或用逗号分隔多个模型")
    args = parser.parse_args()

    print("=" * 60)
    print("统一基线训练脚本")
    print("=" * 60)
    print(f"设备: {DEVICE}")
    print(f"图像尺寸: {IMG_SIZE}x{IMG_SIZE}")
    print("=" * 60)

    # 解析要训练的模型
    if args.model.lower() == "all":
        models_to_train = ALL_MODELS
    else:
        models_to_train = [m.strip().lower() for m in args.model.split(",")]
        for m in models_to_train:
            if m not in ALL_MODELS:
                print(f"错误: 未知模型 '{m}'")
                print(f"可选模型: {', '.join(ALL_MODELS)}")
                return

    print(f"将训练以下模型: {', '.join(models_to_train)}")
    print("=" * 60)

    # 训练每个模型
    results = {}
    for model_name in models_to_train:
        try:
            ckpt, dice = train_model(model_name)
            results[model_name] = {"ckpt": ckpt, "dice": dice}
        except Exception as e:
            print(f"\n[ERROR] 训练 {model_name} 失败: {e}")
            results[model_name] = {"ckpt": None, "dice": 0.0, "error": str(e)}

    # 输出汇总
    print("\n" + "=" * 60)
    print("训练结果汇总")
    print("=" * 60)
    print(f"{'模型':<15} {'Dice':>10} {'状态':>10}")
    print("-" * 40)
    for name, res in results.items():
        if "error" in res:
            print(f"{name:<15} {'N/A':>10} {'失败':>10}")
        else:
            print(f"{name:<15} {res['dice']:>10.4f} {'成功':>10}")
    print("=" * 60)


if __name__ == "__main__":
    main()

