# -*- coding: utf-8 -*-
"""
SINet-like 伪装目标检测基线
- 适配方案B: base/novel 场景划分 + novel 5-shot 微调
- 模型特点: ResNet50 backbone + 多尺度特征 + Reverse Attention 解码
- 任务: 二值伪装目标分割 (foreground / background)
"""

import os
import sys
import random
from collections import defaultdict
import warnings
warnings.filterwarnings("ignore")

# 添加项目根目录到路径
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, PROJECT_ROOT)

import numpy as np
from PIL import Image

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

from torchvision import models, transforms

from utils.metrics_cod import compute_all_metrics  # type: ignore


# =======================
# 配置
# =======================
DATA_ROOT = r"D:\University\Homework\机器学习\机器学习课程设计\FSL-COD数据集"
SPLIT_DIR = os.path.join(DATA_ROOT, "splits")

BASE_TRAIN_LIST = os.path.join(SPLIT_DIR, "base_train.txt")
BASE_VAL_LIST = os.path.join(SPLIT_DIR, "base_val.txt")
NOVEL_SUPPORT_LIST = os.path.join(SPLIT_DIR, "novel_support.txt")
NOVEL_QUERY_LIST = os.path.join(SPLIT_DIR, "novel_query.txt")

IMG_SIZE = 352      # SINet 论文常用 352
BATCH_SIZE = 8
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
SEED = 42

BASE_EPOCHS = 50
FINETUNE_EPOCHS = 30
BASE_LR = 1e-4
FT_LR = 1e-5
PATIENCE = 10


def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


set_seed(SEED)


# =======================
# 通用工具
# =======================
def load_split_list(txt_path):
    """读取 txt 文件，返回 list[(img, mask, scene)]"""
    items = []
    with open(txt_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split()
            if len(parts) >= 3:
                img, mask, scene = parts[0], parts[1], parts[2]
            else:
                img, mask, scene = parts[0], parts[1], "unknown"
            items.append((img, mask, scene))
    return items


class SimpleTransform:
    def __init__(self, img_size=352, is_train=True):
        self.img_size = img_size
        self.is_train = is_train
        self.to_tensor = transforms.ToTensor()
        self.normalize = transforms.Normalize(
            mean=[0.485, 0.456, 0.406],
            std=[0.229, 0.224, 0.225],
        )

    def __call__(self, img, mask):
        img = img.resize((self.img_size, self.img_size), Image.BILINEAR)
        mask = mask.resize((self.img_size, self.img_size), Image.NEAREST)

        if self.is_train:
            if random.random() < 0.5:
                img = img.transpose(Image.FLIP_LEFT_RIGHT)
                mask = mask.transpose(Image.FLIP_LEFT_RIGHT)

        img = self.to_tensor(img)
        img = self.normalize(img)

        mask = np.array(mask, dtype=np.float32)
        if mask.max() > 1:
            mask = (mask > 127.5).astype(np.float32)
        else:
            mask = (mask > 0.5).astype(np.float32)
        mask = torch.from_numpy(mask)

        return img, mask


class ImageMaskDataset(Dataset):
    """普通监督分割数据集（不分 episode）"""
    def __init__(self, split_items, img_size=352, is_train=True):
        self.items = split_items
        self.transform = SimpleTransform(img_size=img_size, is_train=is_train)

    def __len__(self):
        return len(self.items)

    def __getitem__(self, idx):
        img_path, mask_path, scene = self.items[idx]
        img = Image.open(img_path).convert("RGB")
        mask = Image.open(mask_path).convert("L")
        img, mask = self.transform(img, mask)
        return img, mask, scene


# =======================
# SINet-like 模型
# =======================
class ConvBNReLU(nn.Module):
    def __init__(self, in_c, out_c, k=3, s=1, p=1):
        super().__init__()
        self.conv = nn.Conv2d(in_c, out_c, kernel_size=k, stride=s, padding=p, bias=False)
        self.bn = nn.BatchNorm2d(out_c)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        return self.relu(self.bn(self.conv(x)))


class ReverseAttentionBlock(nn.Module):
    """
    反向注意力模块：
    - 利用上一层 coarse prediction 的 (1 - sigmoid(pred)) 作为权重
    - 强调"当前预测错/不确定"的区域，进行细化
    """
    def __init__(self, in_c, inter_c):
        super().__init__()
        self.conv = nn.Sequential(
            ConvBNReLU(in_c, inter_c, 3, 1, 1),
            ConvBNReLU(inter_c, inter_c, 3, 1, 1),
        )
        self.pred = nn.Conv2d(inter_c, 1, kernel_size=3, padding=1)

    def forward(self, feat, pred_coarse_up):
        """
        feat: 当前层特征 (B,C,H,W)
        pred_coarse_up: 上一层预测上采样到同尺寸的 logits (B,1,H,W)
        """
        att = torch.sigmoid(pred_coarse_up)
        rev = 1.0 - att  # 反向注意力
        rev = rev.expand_as(feat)
        x = feat * rev
        x = self.conv(x)
        pred = self.pred(x)
        return pred


class SINetLike(nn.Module):
    """
    简化版 SINet:
    - ResNet50 backbone
    - 用 layer2/3/4 多尺度特征
    - 从最深层得到 coarse prediction，再逐层 RA 精化
    """
    def __init__(self, backbone="resnet50"):
        super().__init__()
        if backbone == "resnet50":
            resnet = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V1)
        else:
            raise NotImplementedError

        # backbone
        self.layer0 = nn.Sequential(
            resnet.conv1, resnet.bn1, resnet.relu, resnet.maxpool
        )
        self.layer1 = resnet.layer1  # 256
        self.layer2 = resnet.layer2  # 512
        self.layer3 = resnet.layer3  # 1024
        self.layer4 = resnet.layer4  # 2048

        # 通道对齐
        self.conv4 = ConvBNReLU(2048, 256, 3, 1, 1)
        self.conv3 = ConvBNReLU(1024, 256, 3, 1, 1)
        self.conv2 = ConvBNReLU(512, 256, 3, 1, 1)

        # 最深层 coarse prediction
        self.pred4 = nn.Conv2d(256, 1, kernel_size=3, padding=1)

        # 反向注意力模块
        self.ra3 = ReverseAttentionBlock(256, 256)
        self.ra2 = ReverseAttentionBlock(256, 256)

    def forward(self, x):
        H, W = x.size(2), x.size(3)

        x0 = self.layer0(x)
        x1 = self.layer1(x0)
        x2 = self.layer2(x1)
        x3 = self.layer3(x2)
        x4 = self.layer4(x3)

        f4 = self.conv4(x4)
        p4 = self.pred4(f4)

        # RA on layer3
        f3 = self.conv3(x3)
        p4_up = F.interpolate(p4, size=f3.shape[2:], mode="bilinear", align_corners=True)
        p3 = self.ra3(f3, p4_up)

        # RA on layer2
        f2 = self.conv2(x2)
        p3_up = F.interpolate(p3, size=f2.shape[2:], mode="bilinear", align_corners=True)
        p2 = self.ra2(f2, p3_up)

        # 最终预测
        pred_final = F.interpolate(p2, size=(H, W), mode="bilinear", align_corners=True)

        return pred_final  # (B,1,H,W)


# =======================
# 损失函数
# =======================
def dice_loss(pred_logits, target):
    pred_prob = torch.sigmoid(pred_logits)[:, 0]
    target = target.float()
    inter = (pred_prob * target).sum(dim=(1, 2))
    union = pred_prob.sum(dim=(1, 2)) + target.sum(dim=(1, 2))
    dice = (2 * inter + 1e-5) / (union + 1e-5)
    return 1 - dice.mean()


def bce_dice_loss(pred_logits, target):
    bce = F.binary_cross_entropy_with_logits(pred_logits[:, 0], target.float())
    dl = dice_loss(pred_logits, target)
    return bce + dl


# =======================
# 评估函数
# =======================
@torch.no_grad()
def eval_on_loader(model, loader, device):
    """在 DataLoader 上评估"""
    model.eval()
    all_preds = []
    all_gts = []

    for imgs, masks, scenes in loader:
        imgs = imgs.to(device)
        logits = model(imgs)
        pred_prob = torch.sigmoid(logits)[:, 0]  # (B,H,W)

        all_preds.append(pred_prob.cpu().numpy())
        all_gts.append(masks.numpy())

    all_preds = np.concatenate(all_preds, axis=0)
    all_gts = np.concatenate(all_gts, axis=0)

    return compute_all_metrics(all_preds, all_gts)


@torch.no_grad()
def evaluate_items(model, items, device, desc="Val"):
    """用 list[(img,mask,scene)] 评估"""
    model.eval()
    transform = SimpleTransform(img_size=IMG_SIZE, is_train=False)

    all_preds = []
    all_gts = []

    for img_path, mask_path, scene in items:
        img = Image.open(img_path).convert("RGB")
        mask = Image.open(mask_path).convert("L")
        img_t, mask_t = transform(img, mask)

        img_t = img_t.unsqueeze(0).to(device)
        mask_np = mask_t.numpy()

        logits = model(img_t)
        pred_prob = torch.sigmoid(logits)[:, 0]

        all_preds.append(pred_prob.cpu().numpy()[0])
        all_gts.append(mask_np)

    all_preds = np.stack(all_preds, axis=0)
    all_gts = np.stack(all_gts, axis=0)

    metrics = compute_all_metrics(all_preds, all_gts)
    print(f"[{desc}] mIoU={metrics['mIoU']:.4f}, Dice={metrics['Dice']:.4f}, "
          f"S={metrics['S_measure']:.4f}, maxF={metrics['maxF']:.4f}, "
          f"MAE={metrics['MAE']:.4f}, PixelAcc={metrics['PixelAcc']:.4f}")
    return metrics


# =======================
# Base 训练
# =======================
def train_base_sinet():
    print("=" * 60)
    print("SINet-like Base 训练 (base 场景全部样本)")
    print("=" * 60)

    base_train_items = load_split_list(BASE_TRAIN_LIST)
    base_val_items = load_split_list(BASE_VAL_LIST)

    train_dataset = ImageMaskDataset(base_train_items, img_size=IMG_SIZE, is_train=True)
    val_dataset = ImageMaskDataset(base_val_items, img_size=IMG_SIZE, is_train=False)

    train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE,
                              shuffle=True, num_workers=4, pin_memory=True)
    val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE,
                            shuffle=False, num_workers=4, pin_memory=True)

    model = SINetLike(backbone="resnet50").to(DEVICE)
    optimizer = torch.optim.Adam(model.parameters(), lr=BASE_LR)

    best_val_dice = 0.0
    no_improve = 0
    ckpt_path = os.path.join("checkpoints", "sinet_base.pth")
    os.makedirs("checkpoints", exist_ok=True)

    print(f"设备: {DEVICE}")
    print(f"训练集: {len(train_dataset)} 样本")
    print(f"验证集: {len(val_dataset)} 样本")
    print(f"早停 patience: {PATIENCE}")
    print("=" * 60)

    for epoch in range(BASE_EPOCHS):
        model.train()
        running_loss = 0.0

        for imgs, masks, scenes in train_loader:
            imgs = imgs.to(DEVICE)
            masks = masks.to(DEVICE)

            optimizer.zero_grad()
            logits = model(imgs)
            loss = bce_dice_loss(logits, masks)
            loss.backward()
            optimizer.step()

            running_loss += loss.item() * imgs.size(0)

        epoch_loss = running_loss / len(train_loader.dataset)

        # 验证
        val_metrics = eval_on_loader(model, val_loader, DEVICE)
        val_dice = val_metrics["Dice"]

        print(f"Epoch [{epoch+1:02d}/{BASE_EPOCHS}] "
              f"Loss={epoch_loss:.4f} | Val Dice={val_dice:.4f} | "
              f"Val mIoU={val_metrics['mIoU']:.4f} | S={val_metrics['S_measure']:.4f}")

        if val_dice > best_val_dice:
            best_val_dice = val_dice
            no_improve = 0
            torch.save(model.state_dict(), ckpt_path)
            print(f"  -> 新最佳! Dice={best_val_dice:.4f}")
        else:
            no_improve += 1
            if no_improve >= PATIENCE:
                print(f"\n早停触发! 连续{PATIENCE}轮无改进")
                break

    print(f"\n[SINet Base] 训练完成, 最佳 Val Dice={best_val_dice:.4f}")
    return ckpt_path


# =======================
# Novel 5-shot 微调
# =======================
def finetune_novel_sinet():
    print("\n" + "=" * 60)
    print("SINet-like Novel 5-shot 微调")
    print("=" * 60)

    # 加载 base 权重
    model = SINetLike(backbone="resnet50").to(DEVICE)
    base_ckpt = os.path.join("checkpoints", "sinet_base.pth")
    
    if os.path.exists(base_ckpt):
        model.load_state_dict(torch.load(base_ckpt, map_location=DEVICE))
        print(f"已加载 Base 模型: {base_ckpt}")
    else:
        print(f"警告: 找不到 Base 模型 {base_ckpt}，使用随机初始化")

    # 加载 novel support (10张 5-shot)
    novel_support_items = load_split_list(NOVEL_SUPPORT_LIST)
    novel_query_items = load_split_list(NOVEL_QUERY_LIST)

    print(f"Novel Support: {len(novel_support_items)} 样本 (5-shot × 2类)")
    print(f"Novel Query: {len(novel_query_items)} 样本 (用于测试)")

    # 微调数据集
    ft_dataset = ImageMaskDataset(novel_support_items, img_size=IMG_SIZE, is_train=True)
    ft_loader = DataLoader(ft_dataset, batch_size=min(BATCH_SIZE, len(novel_support_items)),
                           shuffle=True, num_workers=2, pin_memory=True)

    # 微调优化器（小学习率）
    optimizer = torch.optim.Adam(model.parameters(), lr=FT_LR)

    best_dice = 0.0
    ft_ckpt_path = os.path.join("checkpoints", "sinet_5shot.pth")

    for epoch in range(FINETUNE_EPOCHS):
        model.train()
        running_loss = 0.0

        # 每个 epoch 多次遍历（因为只有10张图）
        for _ in range(10):  # 每 epoch 重复10次
            for imgs, masks, scenes in ft_loader:
                imgs = imgs.to(DEVICE)
                masks = masks.to(DEVICE)

                optimizer.zero_grad()
                logits = model(imgs)
                loss = bce_dice_loss(logits, masks)
                loss.backward()
                optimizer.step()

                running_loss += loss.item() * imgs.size(0)

        epoch_loss = running_loss / (len(ft_loader.dataset) * 10)

        # 在 novel_query 上评估
        metrics = evaluate_items(model, novel_query_items, DEVICE, desc="Novel Query")
        
        print(f"FT Epoch [{epoch+1:02d}/{FINETUNE_EPOCHS}] "
              f"Loss={epoch_loss:.4f} | Query Dice={metrics['Dice']:.4f}")

        if metrics['Dice'] > best_dice:
            best_dice = metrics['Dice']
            torch.save(model.state_dict(), ft_ckpt_path)
            print(f"  -> 新最佳! 5-shot Dice={best_dice:.4f}")

    print(f"\n[SINet 5-shot] 微调完成, 最佳 Dice={best_dice:.4f}")
    return ft_ckpt_path


# =======================
# Novel 测试
# =======================
def test_novel_sinet():
    print("\n" + "=" * 60)
    print("SINet-like Novel 测试")
    print("=" * 60)

    novel_query_items = load_split_list(NOVEL_QUERY_LIST)

    model = SINetLike(backbone="resnet50").to(DEVICE)
    
    # 优先加载 5-shot 微调后的模型
    ft_ckpt = os.path.join("checkpoints", "sinet_5shot.pth")
    base_ckpt = os.path.join("checkpoints", "sinet_base.pth")
    
    if os.path.exists(ft_ckpt):
        model.load_state_dict(torch.load(ft_ckpt, map_location=DEVICE))
        print(f"加载 5-shot 微调模型: {ft_ckpt}")
    elif os.path.exists(base_ckpt):
        model.load_state_dict(torch.load(base_ckpt, map_location=DEVICE))
        print(f"加载 Base 模型: {base_ckpt}")
    else:
        print("警告: 未找到任何预训练模型")
        return

    print(f"测试样本: {len(novel_query_items)}")

    # 按场景分组测试
    scene_items = defaultdict(list)
    for item in novel_query_items:
        scene_items[item[2]].append(item)

    print("\n按场景测试结果:")
    print("-" * 60)
    
    all_metrics = []
    for scene, items in scene_items.items():
        metrics = evaluate_items(model, items, DEVICE, desc=scene)
        all_metrics.append(metrics)

    # 总体结果
    print("\n" + "=" * 60)
    print("Novel 测试总结果:")
    print("=" * 60)
    metrics = evaluate_items(model, novel_query_items, DEVICE, desc="Overall")
    
    print("\n主指标:")
    print(f"  mIoU:      {metrics['mIoU']:.4f}")
    print(f"  Dice:      {metrics['Dice']:.4f}")
    print(f"  S-measure: {metrics['S_measure']:.4f}")
    print("辅指标:")
    print(f"  maxF:      {metrics['maxF']:.4f}")
    print(f"  MAE:       {metrics['MAE']:.4f}")
    print(f"  PixelAcc:  {metrics['PixelAcc']:.4f}")
    print("=" * 60)
    
    return metrics


# =======================
# 主函数
# =======================
def main():
    print("=" * 60)
    print("SINet-like COD 基线 (方案B: Base训练 + Novel微调)")
    print("=" * 60)

    # 1. Base 训练
    train_base_sinet()

    # 2. Novel 5-shot 微调
    finetune_novel_sinet()

    # 3. Novel 测试
    test_novel_sinet()


if __name__ == "__main__":
    main()
