# -*- coding: utf-8 -*-
"""
注意力机制模块: SE, ECA, CBAM 和三重注意力组合
用于小样本伪装目标分割的特征增强
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


class SEBlock(nn.Module):
    """
    Squeeze-and-Excitation (SE) 注意力模块
    
    通过全局平均池化捕获通道依赖关系,自动学习每个通道的重要性权重
    """
    def __init__(self, channels, reduction=16):
        super().__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(channels, channels // reduction, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(channels // reduction, channels, bias=False),
            nn.Sigmoid()
        )
    
    def forward(self, x):
        b, c, _, _ = x.size()
        # Squeeze: 全局平均池化
        y = self.avg_pool(x).view(b, c)
        # Excitation: 全连接层学习通道权重
        y = self.fc(y).view(b, c, 1, 1)
        # Scale: 通道加权
        return x * y.expand_as(x)


class ECABlock(nn.Module):
    """
    Efficient Channel Attention (ECA) 模块
    
    使用自适应核大小的1D卷积避免降维,高效捕获局部跨通道交互
    """
    def __init__(self, channels, gamma=2, b=1):
        super().__init__()
        # 自适应核大小计算
        k_size = int(abs((math.log2(channels) + b) / gamma))
        k_size = k_size if k_size % 2 else k_size + 1
        
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.conv = nn.Conv1d(1, 1, kernel_size=k_size, padding=(k_size - 1) // 2, bias=False)
        self.sigmoid = nn.Sigmoid()
    
    def forward(self, x):
        # 全局平均池化
        y = self.avg_pool(x)
        # 1D卷积捕获跨通道交互
        y = self.conv(y.squeeze(-1).transpose(-1, -2)).transpose(-1, -2).unsqueeze(-1)
        # Sigmoid激活
        y = self.sigmoid(y)
        # 通道加权
        return x * y.expand_as(x)


class ChannelAttention(nn.Module):
    """CBAM中的通道注意力模块"""
    def __init__(self, channels, reduction=16):
        super().__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        
        self.fc = nn.Sequential(
            nn.Conv2d(channels, channels // reduction, 1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels // reduction, channels, 1, bias=False)
        )
        self.sigmoid = nn.Sigmoid()
    
    def forward(self, x):
        avg_out = self.fc(self.avg_pool(x))
        max_out = self.fc(self.max_pool(x))
        out = avg_out + max_out
        return self.sigmoid(out)


class SpatialAttention(nn.Module):
    """CBAM中的空间注意力模块"""
    def __init__(self, kernel_size=7):
        super().__init__()
        assert kernel_size in (3, 7), 'kernel size must be 3 or 7'
        padding = 3 if kernel_size == 7 else 1
        
        self.conv = nn.Conv2d(2, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()
    
    def forward(self, x):
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        out = torch.cat([avg_out, max_out], dim=1)
        out = self.conv(out)
        return self.sigmoid(out)


class CBAMBlock(nn.Module):
    """
    Convolutional Block Attention Module (CBAM)
    
    串联通道注意力和空间注意力,依次精炼特征
    """
    def __init__(self, channels, reduction=16, kernel_size=7):
        super().__init__()
        self.channel_attention = ChannelAttention(channels, reduction)
        self.spatial_attention = SpatialAttention(kernel_size)
    
    def forward(self, x):
        # 先应用通道注意力
        x = x * self.channel_attention(x)
        # 再应用空间注意力
        x = x * self.spatial_attention(x)
        return x


class TripleAttention(nn.Module):
    """
    三重注意力模块: SE + ECA + CBAM 串联
    
    结合三种注意力机制的优势:
    - SE: 全局通道依赖建模
    - ECA: 高效局部跨通道交互
    - CBAM: 通道+空间联合注意力
    """
    def __init__(self, channels, se_reduction=16, eca_gamma=2, cbam_reduction=16):
        super().__init__()
        self.se = SEBlock(channels, reduction=se_reduction)
        self.eca = ECABlock(channels, gamma=eca_gamma)
        self.cbam = CBAMBlock(channels, reduction=cbam_reduction)
        
        # 可学习的融合权重
        self.fusion_weights = nn.Parameter(torch.ones(3) / 3)
    
    def forward(self, x):
        # 并行计算三种注意力
        x_se = self.se(x)
        x_eca = self.eca(x)
        x_cbam = self.cbam(x)
        
        # 加权融合
        w = F.softmax(self.fusion_weights, dim=0)
        out = w[0] * x_se + w[1] * x_eca + w[2] * x_cbam
        
        # 残差连接
        return x + out


# 导入math模块用于ECA的核大小计算
import math

__all__ = ['SEBlock', 'ECABlock', 'CBAMBlock', 'TripleAttention', 
           'ChannelAttention', 'SpatialAttention']


if __name__ == "__main__":
    # 单元测试
    print("测试注意力模块...")
    
    B, C, H, W = 2, 256, 32, 32
    x = torch.randn(B, C, H, W)
    
    # 测试SE
    se = SEBlock(C)
    out_se = se(x)
    print(f"SE Block: {x.shape} -> {out_se.shape}")
    
    # 测试ECA
    eca = ECABlock(C)
    out_eca = eca(x)
    print(f"ECA Block: {x.shape} -> {out_eca.shape}")
    
    # 测试CBAM
    cbam = CBAMBlock(C)
    out_cbam = cbam(x)
    print(f"CBAM Block: {x.shape} -> {out_cbam.shape}")
    
    # 测试三重注意力
    triple = TripleAttention(C)
    out_triple = triple(x)
    print(f"Triple Attention: {x.shape} -> {out_triple.shape}")
    
    print("\n所有注意力模块测试通过!")
