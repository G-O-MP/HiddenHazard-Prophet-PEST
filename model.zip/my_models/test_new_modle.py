# -*- coding: utf-8 -*-
"""测试 FS_CamoSeg_Model 和相关功能"""
import torch
import torch.nn as nn
from fewshot_camouflage_seg import (
    create_fscamo_model, 
    freeze_encoder_bn, 
    get_tta_params_v2,
    FS_CamoSeg_Model,
    freeze_bn
)
from encoder_decoder import ResNetEncoder

print("=" * 60)
print("测试 FS_CamoSeg_Model 和相关功能")
print("=" * 60)

# 1. 使用工厂函数创建模型
print("\n1. 使用工厂函数创建推荐配置模型...")
model = create_fscamo_model(
    backbone='resnet50',
    pretrained=False,
    use_edge=True,
    use_cross_attn=True,
    use_token_proto=False,
    use_adapter=True,
    adapt_levels=("p2", "p3"),
    freeze_encoder_batchnorm=True
)
print("   创建成功!")
print(f"   总参数: {sum(p.numel() for p in model.parameters())/1e6:.2f}M")

# 2. 测试 BN 冻结
print("\n2. 测试 encoder BN 冻结...")
bn_training = sum(1 for m in model.encoder.modules() 
                 if isinstance(m, nn.BatchNorm2d) and m.training)
print(f"   训练中的 BN 层: {bn_training} (应该为 0)")

# 3. 测试 TTA 参数获取
print("\n3. 测试 TTA 参数获取...")
for mode in ["adapter_only", "adapter_plus_cross"]:
    params = get_tta_params_v2(model, mode=mode)
    count = sum(p.numel() for p in params)
    print(f"   {mode}: {count:,} 参数")

# 4. 测试 forward
print("\n4. 测试 forward...")
K, H, W = 5, 256, 256  # 使用较小分辨率测试
supp_imgs = torch.randn(K, 3, H, W)
supp_masks = (torch.randn(K, 1, H, W) > 0).float()
qry_imgs = torch.randn(1, 3, H, W)

with torch.no_grad():
    out, logits, guides = model(supp_imgs, supp_masks, qry_imgs)

print(f"   out: {out.shape}")
print(f"   log2: {logits['log2'].shape}")
print(f"   g2: {guides['g2'].shape}")

# 5. 测试直接创建模型
print("\n5. 测试直接创建 FS_CamoSeg_Model...")
encoder = ResNetEncoder(backbone='resnet50', pretrained=False)
model2 = FS_CamoSeg_Model(
    encoder=encoder,
    use_edge=True,
    use_cross_attn=True,
    use_token_proto=False,
    use_adapter=True,
    adapt_levels=("p2", "p3")
)
encoder.apply(freeze_bn)  # 手动冻结 BN

with torch.no_grad():
    out2, _, _ = model2(supp_imgs, supp_masks, qry_imgs)
print(f"   out2: {out2.shape}")

# 6. 测试模型 TTA 参数方法
print("\n6. 测试模型内置 TTA 方法...")
for mode in ["adapter_only", "adapter_plus_cross"]:
    count = model2.count_tta_params(mode)
    print(f"   {mode}: {count:,} 参数")

print("\n" + "=" * 60)
print("所有测试通过!")
print("=" * 60)
print("\n推荐的训练脚本调用方式:")
print("pred, logits, guides = model(supp_imgs, supp_masks, qry_imgs)")
print("loss = bce_dice_loss(pred, qry_masks) + 0.5 * multi_scale_loss(logits, qry_masks)")
