# -*- coding: utf-8 -*-
"""
Few-shot Camouflage Segmentation Model
支持消融实验的完整模型框架
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

from .encoder_decoder import (
    ResNetEncoder, C2FDecoder, FPNDecoder, EdgeDetector, PredHead,
    ConvBNReLU, Adapter, freeze_bn
)


class CrossAttention(nn.Module):
    """Cross-Attention 模块"""
    def __init__(self, dim, num_heads=4):
        super().__init__()
        self.num_heads = num_heads
        self.head_dim = dim // num_heads
        self.scale = self.head_dim ** -0.5
        
        self.q_proj = nn.Linear(dim, dim)
        self.k_proj = nn.Linear(dim, dim)
        self.v_proj = nn.Linear(dim, dim)
        self.out_proj = nn.Linear(dim, dim)
        
    def forward(self, query, key, value):
        """
        query: (B, N, C)
        key, value: (B, M, C)
        """
        B, N, C = query.shape
        M = key.shape[1]
        
        q = self.q_proj(query).view(B, N, self.num_heads, self.head_dim).permute(0, 2, 1, 3)
        k = self.k_proj(key).view(B, M, self.num_heads, self.head_dim).permute(0, 2, 1, 3)
        v = self.v_proj(value).view(B, M, self.num_heads, self.head_dim).permute(0, 2, 1, 3)
        
        attn = (q @ k.transpose(-2, -1)) * self.scale
        attn = attn.softmax(dim=-1)
        
        out = (attn @ v).permute(0, 2, 1, 3).reshape(B, N, C)
        return self.out_proj(out)


class ProtoFormerBridge(nn.Module):
    """原型引导的 Cross-Attention Bridge"""
    def __init__(self, dim, num_heads=4):
        super().__init__()
        self.cross = CrossAttention(dim, num_heads)
        self.norm1 = nn.LayerNorm(dim)
        self.norm2 = nn.LayerNorm(dim)
        self.ffn = nn.Sequential(
            nn.Linear(dim, dim * 4),
            nn.GELU(),
            nn.Linear(dim * 4, dim)
        )
        
    def forward(self, query_feat, proto):
        """
        query_feat: (B, C, H, W) - 查询特征
        proto: (B, C) - 原型
        """
        B, C, H, W = query_feat.shape
        
        # 展平 query
        query = query_feat.flatten(2).permute(0, 2, 1)  # (B, HW, C)
        
        # 原型作为 key/value
        proto_kv = proto.unsqueeze(1)  # (B, 1, C)
        
        # Cross-Attention
        query = query + self.cross(self.norm1(query), proto_kv, proto_kv)
        query = query + self.ffn(self.norm2(query))
        
        # 恢复形状
        out = query.permute(0, 2, 1).view(B, C, H, W)
        return out


class MaskedAvgPool(nn.Module):
    """Masked Average Pooling 计算原型"""
    def __init__(self):
        super().__init__()
        
    def forward(self, feat, mask):
        """
        feat: (K, C, H, W)
        mask: (K, 1, H', W')
        返回: (C,) 全局原型
        """
        K, C, H, W = feat.shape
        mask = F.interpolate(mask, size=(H, W), mode='nearest')
        
        # 前景原型
        fg_sum = (feat * mask).sum(dim=(0, 2, 3))  # (C,)
        fg_cnt = mask.sum() + 1e-5
        fg_proto = fg_sum / fg_cnt
        
        return fg_proto


class TokenProtoBuilder(nn.Module):
    """Token-level 原型构建器"""
    def __init__(self, grid_size=(3, 3)):
        super().__init__()
        self.grid_h, self.grid_w = grid_size
        
    def forward(self, feat, mask):
        """
        feat: (K, C, H, W)
        mask: (K, 1, H', W')
        返回: (grid_h * grid_w, C) token 原型
        """
        K, C, H, W = feat.shape
        mask = F.interpolate(mask, size=(H, W), mode='nearest')
        
        # 计算每个 grid 的原型
        gh = H // self.grid_h
        gw = W // self.grid_w
        
        token_protos = []
        for i in range(self.grid_h):
            for j in range(self.grid_w):
                h_start, h_end = i * gh, (i + 1) * gh
                w_start, w_end = j * gw, (j + 1) * gw
                
                patch_feat = feat[:, :, h_start:h_end, w_start:w_end]
                patch_mask = mask[:, :, h_start:h_end, w_start:w_end]
                
                fg_sum = (patch_feat * patch_mask).sum(dim=(0, 2, 3))
                fg_cnt = patch_mask.sum() + 1e-5
                proto = fg_sum / fg_cnt
                token_protos.append(proto)
        
        token_protos = torch.stack(token_protos, dim=0)  # (n_tokens, C)
        return token_protos


class GuideBuilder(nn.Module):
    """引导图构建器"""
    def __init__(self, mode='global'):
        super().__init__()
        self.mode = mode  # 'global' or 'token'
        
    def forward(self, query_feat, proto):
        """
        query_feat: (1, C, H, W)
        proto: (C,) for global, (n_tokens, C) for token
        返回: (1, 1, H, W) 引导图
        """
        _, C, H, W = query_feat.shape
        
        if self.mode == 'global':
            # 全局余弦相似度
            query_flat = query_feat.view(C, -1)  # (C, HW)
            proto = proto.view(C, 1)  # (C, 1)
            
            query_norm = F.normalize(query_flat, dim=0)
            proto_norm = F.normalize(proto, dim=0)
            
            guide = (query_norm * proto_norm).sum(dim=0)  # (HW,)
            guide = guide.view(1, 1, H, W)
        else:
            # Token 级别相似度 (取最大值)
            n_tokens, C = proto.shape
            query_flat = query_feat.view(C, -1)  # (C, HW)
            
            query_norm = F.normalize(query_flat, dim=0)
            proto_norm = F.normalize(proto.T, dim=0)  # (C, n_tokens)
            
            sim = torch.mm(proto_norm.T, query_norm)  # (n_tokens, HW)
            guide = sim.max(dim=0)[0]  # (HW,)
            guide = guide.view(1, 1, H, W)
        
        return guide


class FS_CamoSeg_Model(nn.Module):
    """
    Few-shot Camouflage Segmentation 主模型 (改进版)
    
    改进内容:
    - 使用FPNDecoder替代C2FDecoder(ASPP + FPN)
    - 集成三重注意力(CBAM + SE + ECA)
    - 支持消融实验的开关
    
    支持消融实验的开关:
    - use_edge: 是否使用边缘增强
    - use_cross_attn: 是否使用 Cross-Attention
    - use_token_proto: 是否使用 Token-level 原型
    - use_adapter: 是否使用 Adapter (TTA 用)
    - use_fpn: 是否使用FPN解码器(默认True)
    - use_attention: 是否使用三重注意力(默认True)
    """
    def __init__(
        self,
        encoder,
        use_edge=True,
        use_cross_attn=True,
        use_token_proto=False,
        use_adapter=False,
        adapt_levels=("p2", "p3"),
        hidden=256,
        token_grid=(3, 3),
        use_fpn=True,
        use_attention=True
    ):
        super().__init__()
        
        self.use_edge = use_edge
        self.use_cross_attn = use_cross_attn
        self.use_token_proto = use_token_proto
        self.use_adapter = use_adapter
        self.adapt_levels = adapt_levels
        self.hidden = hidden
        self.use_fpn = use_fpn
        self.use_attention = use_attention
        
        # 编码器
        self.encoder = encoder
        
        # 解码器: 使用FPN或C2F
        if use_fpn:
            self.decoder = FPNDecoder(
                in_dims=(512, 1024, 2048),
                hidden=hidden,
                use_adapter=use_adapter,
                adapt_levels=adapt_levels,
                use_attention=use_attention
            )
        else:
            self.decoder = C2FDecoder(
                in_dims=(512, 1024, 2048),
                hidden=hidden,
                use_adapter=use_adapter,
                adapt_levels=adapt_levels
            )
        
        # 边缘检测器 (可选)
        if use_edge:
            self.edge_detector = EdgeDetector(hidden, hidden)
        
        # 原型构建
        self.masked_avg_pool = MaskedAvgPool()
        if use_token_proto:
            self.token_proto_builder = TokenProtoBuilder(token_grid)
        
        # 引导图构建器
        self.guide_builder = GuideBuilder('global')
        if use_token_proto:
            self.token_guide_builder = GuideBuilder('token')
        
        # Cross-Attention (可选)
        if use_cross_attn:
            self.bridge = ProtoFormerBridge(hidden, num_heads=4)
        
        # 预测头
        in_c = hidden
        if use_edge:
            in_c += hidden  # 边缘特征
        
        self.pred_head2 = PredHead(in_c)
        self.pred_head3 = PredHead(in_c)
        self.pred_head4 = PredHead(in_c)
        
        # 引导图投影
        self.guide_proj = nn.Conv2d(1, hidden, 3, padding=1)
        
    def extract_features(self, x):
        """提取多尺度特征"""
        enc_feats = self.encoder(x)
        dec_feats = self.decoder(enc_feats['c2'], enc_feats['c3'], enc_feats['c4'])
        return dec_feats
    
    def compute_prototype(self, supp_feats, supp_masks):
        """计算支持集原型"""
        # 全局原型
        global_proto = self.masked_avg_pool(supp_feats, supp_masks)
        
        # Token 原型 (可选)
        token_proto = None
        if self.use_token_proto:
            token_proto = self.token_proto_builder(supp_feats, supp_masks)
        
        return global_proto, token_proto
    
    def compute_guide(self, query_feat, global_proto, token_proto=None):
        """计算引导图"""
        guide = self.guide_builder(query_feat, global_proto)
        
        if self.use_token_proto and token_proto is not None:
            token_guide = self.token_guide_builder(query_feat, token_proto)
            guide = guide + token_guide  # 融合
        
        return guide
    
    def forward(self, supp_imgs, supp_masks, qry_imgs):
        """
        Few-shot forward (原始)
        supp_imgs: (K, 3, H, W) - K 张支持图像
        supp_masks: (K, 1, H, W) - K 张支持掩码
        qry_imgs: (1, 3, H, W) - 查询图像
        
        返回:
        - pred: (1, 1, H, W) 最终预测
        - logits: dict, 多尺度 logits
        - guides: dict, 多尺度引导图
        """
        # 提取特征
        supp_feats = self.extract_features(supp_imgs)
        qry_feats = self.extract_features(qry_imgs)
        
        # 多尺度处理
        logits = {}
        guides = {}
        
        for level in ['p2', 'p3', 'p4']:
            supp_feat = supp_feats[level]
            qry_feat = qry_feats[level]
            
            # 计算原型
            global_proto, token_proto = self.compute_prototype(supp_feat, supp_masks)
            
            # Cross-Attention 增强 (可选)
            if self.use_cross_attn:
                qry_feat = self.bridge(qry_feat, global_proto.unsqueeze(0))
            
            # 计算引导图
            guide = self.compute_guide(qry_feat, global_proto, token_proto)
            guides[f'g{level[1]}'] = guide
            
            # 融合引导图 (在边缘增强之前)
            guide_feat = self.guide_proj(guide)
            guide_feat = F.interpolate(
                guide_feat, size=qry_feat.shape[2:], mode='bilinear', align_corners=False
            )
            qry_feat = qry_feat + guide_feat  # 此时 qry_feat 还是 hidden 通道
            
            # 边缘增强 (可选，在融合引导图之后)
            if self.use_edge:
                edge_feat = self.edge_detector(qry_feat)
                qry_feat = torch.cat([qry_feat, edge_feat], dim=1)
            
            # 预测
            pred_head = getattr(self, f'pred_head{level[1]}')
            logit = pred_head(qry_feat)
            logits[f'log{level[1]}'] = logit
        
        # 上采样到原图尺寸
        H, W = qry_imgs.shape[2:]
        pred = F.interpolate(logits['log2'], size=(H, W), mode='bilinear', align_corners=False)
        
        return pred, logits, guides
    
    def forward_full_supervised(self, imgs):
        """
        全监督 forward (用于COD10K等全监督数据集)
        
        Args:
            imgs: (B, 3, H, W) 输入图像
        
        Returns:
            pred: (B, 1, H, W) 最终预测
        """
        # 提取特征
        enc_feats = self.encoder(imgs)
        dec_feats = self.decoder(enc_feats['c2'], enc_feats['c3'], enc_feats['c4'])
        
        # 多尺度预测
        logits = {}
        
        for level in ['p2', 'p3', 'p4']:
            feat = dec_feats[level]
            
            # 边缘增强 (可选)
            if self.use_edge:
                edge_feat = self.edge_detector(feat)
                feat = torch.cat([feat, edge_feat], dim=1)
            
            # 预测
            pred_head = getattr(self, f'pred_head{level[1]}')
            logit = pred_head(feat)
            logits[f'log{level[1]}'] = logit
        
        # 上采样到原图尺寸
        H, W = imgs.shape[2:]
        pred = F.interpolate(logits['log2'], size=(H, W), mode='bilinear', align_corners=False)
        
        return pred
    
    def forward_full_supervised_with_logits(self, imgs):
        """
        全监督 forward (返回pred, logits, guides)
        
        Args:
            imgs: (B, 3, H, W) 输入图像
        
        Returns:
            pred: (B, 1, H, W)
            logits: dict
            guides: dict (empty for full supervised)
        """
        # 提取特征
        enc_feats = self.encoder(imgs)
        dec_feats = self.decoder(enc_feats['c2'], enc_feats['c3'], enc_feats['c4'])
        
        # 多尺度预测
        logits = {}
        guides = {}  # 全监督模式下无guides
        
        for level in ['p2', 'p3', 'p4']:
            feat = dec_feats[level]
            
            # 边缘增强 (可选)
            if self.use_edge:
                edge_feat = self.edge_detector(feat)
                feat_combined = torch.cat([feat, edge_feat], dim=1)
            else:
                feat_combined = feat
            
            # 预测
            pred_head = getattr(self, f'pred_head{level[1]}')
            logit = pred_head(feat_combined)
            logits[f'log{level[1]}'] = logit
        
        # 上采样到原图尺寸
        H, W = imgs.shape[2:]
        pred = F.interpolate(logits['log2'], size=(H, W), mode='bilinear', align_corners=False)
        
        return pred, logits, guides
    
    def get_tta_params(self, mode='adapter_only'):
        """获取 TTA 可训练参数"""
        params = []
        
        if mode == 'adapter_only':
            if self.use_adapter and hasattr(self.decoder, 'adapters'):
                for adapter in self.decoder.adapters.values():
                    params.extend(adapter.parameters())
        elif mode == 'cross_only':
            # 仅使用 cross-attention 参数
            if self.use_cross_attn:
                params.extend(self.bridge.parameters())
        elif mode == 'adapter_plus_cross':
            if self.use_adapter and hasattr(self.decoder, 'adapters'):
                for adapter in self.decoder.adapters.values():
                    params.extend(adapter.parameters())
            if self.use_cross_attn:
                params.extend(self.bridge.parameters())
        
        return params
    
    def count_tta_params(self, mode='adapter_only'):
        """统计 TTA 参数数量"""
        return sum(p.numel() for p in self.get_tta_params(mode))


def freeze_encoder_bn(model):
    """冻结编码器中的 BN 层"""
    if hasattr(model, 'encoder'):
        model.encoder.apply(freeze_bn)


def get_tta_params_v2(model, mode='adapter_only'):
    """获取 TTA 参数（模块级别函数）"""
    return model.get_tta_params(mode)


def create_fscamo_model(
    backbone='resnet50',
    pretrained=True,
    use_edge=True,
    use_cross_attn=True,
    use_token_proto=False,
    use_adapter=True,
    adapt_levels=("p2", "p3"),
    freeze_encoder_batchnorm=True,
    use_fpn=True,
    use_attention=True
):
    """工厂函数创建模型(改进版)"""
    encoder = ResNetEncoder(backbone=backbone, pretrained=pretrained)
    
    model = FS_CamoSeg_Model(
        encoder=encoder,
        use_edge=use_edge,
        use_cross_attn=use_cross_attn,
        use_token_proto=use_token_proto,
        use_adapter=use_adapter,
        adapt_levels=adapt_levels,
        use_fpn=use_fpn,
        use_attention=use_attention
    )
    
    if freeze_encoder_batchnorm:
        freeze_encoder_bn(model)
    
    return model


# 导出
__all__ = [
    'FS_CamoSeg_Model',
    'create_fscamo_model',
    'freeze_encoder_bn',
    'freeze_bn',
    'get_tta_params_v2',
    'ResNetEncoder',
]
