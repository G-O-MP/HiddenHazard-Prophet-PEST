# -*- coding: utf-8 -*-
"""
my_models 包初始化
Few-shot Camouflage Segmentation 模型组件
"""

from .encoder_decoder import (
    ResNetEncoder,
    C2FDecoder,
    EdgeDetector,
    PredHead,
    ConvBNReLU,
    Adapter,
    freeze_bn
)

from .fewshot_camouflage_seg import (
    FS_CamoSeg_Model,
    create_fscamo_model,
    freeze_encoder_bn,
    get_tta_params_v2,
    CrossAttention,
    ProtoFormerBridge,
    MaskedAvgPool,
    TokenProtoBuilder,
    GuideBuilder
)

__all__ = [
    # Encoder/Decoder
    'ResNetEncoder',
    'C2FDecoder',
    'EdgeDetector',
    'PredHead',
    'ConvBNReLU',
    'Adapter',
    'freeze_bn',
    
    # Model
    'FS_CamoSeg_Model',
    'create_fscamo_model',
    'freeze_encoder_bn',
    'get_tta_params_v2',
    
    # Components
    'CrossAttention',
    'ProtoFormerBridge',
    'MaskedAvgPool',
    'TokenProtoBuilder',
    'GuideBuilder',
]
