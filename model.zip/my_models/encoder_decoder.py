# -*- coding: utf-8 -*-
"""
ResNet Encoder + C2F Decoder for Few-shot Camouflage Segmentation
支持ASPP多尺度上下文和FPN特征金字塔
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import models
from .attention_modules import TripleAttention


def freeze_bn(module):
    """冻结 BatchNorm 层"""
    if isinstance(module, (nn.BatchNorm2d, nn.BatchNorm1d)):
        module.eval()
        for param in module.parameters():
            param.requires_grad = False


class ConvBNReLU(nn.Module):
    """Conv + BN + ReLU 基础模块"""
    def __init__(self, in_c, out_c, k=3, s=1, p=1):
        super().__init__()
        self.conv = nn.Conv2d(in_c, out_c, k, s, p, bias=False)
        self.bn = nn.BatchNorm2d(out_c)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        return self.relu(self.bn(self.conv(x)))


class Adapter(nn.Module):
    """轻量级 Adapter 模块用于 TTA"""
    def __init__(self, dim, ratio=4):
        super().__init__()
        hidden = max(dim // ratio, 16)
        self.down = nn.Conv2d(dim, hidden, 1)
        self.act = nn.GELU()
        self.up = nn.Conv2d(hidden, dim, 1)
        self.scale = nn.Parameter(torch.ones(1) * 0.1)
        
    def forward(self, x):
        return x + self.scale * self.up(self.act(self.down(x)))


class ResNetEncoder(nn.Module):
    """ResNet 编码器，输出多尺度特征"""
    def __init__(self, backbone='resnet50', pretrained=True):
        super().__init__()
        
        if backbone == 'resnet50':
            if pretrained:
                resnet = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V1)
            else:
                resnet = models.resnet50(weights=None)
            self.feat_dims = [256, 512, 1024, 2048]
        elif backbone == 'resnet101':
            if pretrained:
                resnet = models.resnet101(weights=models.ResNet101_Weights.IMAGENET1K_V1)
            else:
                resnet = models.resnet101(weights=None)
            self.feat_dims = [256, 512, 1024, 2048]
        else:
            raise ValueError(f"Unsupported backbone: {backbone}")
        
        # 编码器各阶段
        self.layer0 = nn.Sequential(
            resnet.conv1, resnet.bn1, resnet.relu, resnet.maxpool
        )
        self.layer1 = resnet.layer1  # /4, 256
        self.layer2 = resnet.layer2  # /8, 512
        self.layer3 = resnet.layer3  # /16, 1024
        self.layer4 = resnet.layer4  # /32, 2048
        
    def forward(self, x):
        """
        返回多尺度特征 dict
        c2: /8, c3: /16, c4: /32
        """
        x0 = self.layer0(x)   # /4
        c1 = self.layer1(x0)  # /4, 256
        c2 = self.layer2(c1)  # /8, 512
        c3 = self.layer3(c2)  # /16, 1024
        c4 = self.layer4(c3)  # /32, 2048
        
        return {'c2': c2, 'c3': c3, 'c4': c4}


class ASPPModule(nn.Module):
    """
    Atrous Spatial Pyramid Pooling (ASPP) 模块
    
    使用不同膨胀率的空洞卷积捕获多尺度上下文信息
    """
    def __init__(self, in_channels, out_channels=256, dilations=[6, 12, 18]):
        super().__init__()
        
        # 1x1 卷积分支
        self.branch1 = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, 1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )
        
        # 不同膨胀率的3x3卷积分支
        self.branches = nn.ModuleList([
            nn.Sequential(
                nn.Conv2d(in_channels, out_channels, 3, padding=d, dilation=d, bias=False),
                nn.BatchNorm2d(out_channels),
                nn.ReLU(inplace=True)
            ) for d in dilations
        ])
        
        # 全局平均池化分支 (使用GroupNorm避免batch size=1问题)
        self.global_pool = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(in_channels, out_channels, 1, bias=False),
            nn.GroupNorm(min(32, out_channels), out_channels),  # 用GroupNorm替代BatchNorm
            nn.ReLU(inplace=True)
        )
        
        # 融合后的投影
        self.project = nn.Sequential(
            nn.Conv2d(out_channels * (len(dilations) + 2), out_channels, 1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Dropout2d(0.1)
        )
    
    def forward(self, x):
        features = [self.branch1(x)]
        
        # 多尺度空洞卷积
        for branch in self.branches:
            features.append(branch(x))
        
        # 全局平均池化并上采样
        global_feat = self.global_pool(x)
        global_feat = F.interpolate(global_feat, size=x.shape[2:], mode='bilinear', align_corners=False)
        features.append(global_feat)
        
        # 拼接所有分支
        out = torch.cat(features, dim=1)
        out = self.project(out)
        
        return out


class FPNDecoder(nn.Module):
    """
    Feature Pyramid Network (FPN) 解码器
    
    自顶向下特征融合,保留高分辨率细节
    替代原有的C2FDecoder
    """
    def __init__(self, in_dims=(512, 1024, 2048), hidden=256, use_adapter=False, adapt_levels=(), use_attention=True):
        super().__init__()
        
        self.use_adapter = use_adapter
        self.adapt_levels = adapt_levels
        self.use_attention = use_attention
        
        # ASPP处理c4特征
        self.aspp = ASPPModule(in_dims[2], hidden)
        
        # 横向连接: 统一通道数到hidden
        self.lateral_c2 = ConvBNReLU(in_dims[0], hidden)
        self.lateral_c3 = ConvBNReLU(in_dims[1], hidden)
        # c4通过ASPP已经统一到hidden
        
        # 自顶向下融合层
        self.fuse_p3 = ConvBNReLU(hidden, hidden)
        self.fuse_p2 = ConvBNReLU(hidden, hidden)
        
        # 三重注意力模块(可选)
        if use_attention:
            self.attention_p2 = TripleAttention(hidden)
            self.attention_p3 = TripleAttention(hidden)
            self.attention_p4 = TripleAttention(hidden)
        else:
            self.attention_p2 = nn.Identity()
            self.attention_p3 = nn.Identity()
            self.attention_p4 = nn.Identity()
        
        # Adapter（可选）
        if use_adapter:
            self.adapters = nn.ModuleDict()
            if 'p2' in adapt_levels:
                self.adapters['p2'] = Adapter(hidden)
            if 'p3' in adapt_levels:
                self.adapters['p3'] = Adapter(hidden)
            if 'p4' in adapt_levels:
                self.adapters['p4'] = Adapter(hidden)
    
    def forward(self, c2, c3, c4):
        """
        输入: c2(/8), c3(/16), c4(/32)
        输出: p2(/8), p3(/16), p4(/32)
        """
        # c4通过ASPP增强
        p4 = self.aspp(c4)  # /32
        
        # 应用注意力
        p4 = self.attention_p4(p4)
        
        # Adapter for p4
        if self.use_adapter and 'p4' in self.adapt_levels and 'p4' in self.adapters:
            p4 = self.adapters['p4'](p4)
        
        # 自顶向下融合: p4 -> p3
        p4_up = F.interpolate(p4, size=c3.shape[2:], mode='bilinear', align_corners=False)
        p3 = self.lateral_c3(c3) + p4_up
        p3 = self.fuse_p3(p3)
        p3 = self.attention_p3(p3)
        
        # Adapter for p3
        if self.use_adapter and 'p3' in self.adapt_levels and 'p3' in self.adapters:
            p3 = self.adapters['p3'](p3)
        
        # 自顶向下融合: p3 -> p2
        p3_up = F.interpolate(p3, size=c2.shape[2:], mode='bilinear', align_corners=False)
        p2 = self.lateral_c2(c2) + p3_up
        p2 = self.fuse_p2(p2)
        p2 = self.attention_p2(p2)
        
        # Adapter for p2
        if self.use_adapter and 'p2' in self.adapt_levels and 'p2' in self.adapters:
            p2 = self.adapters['p2'](p2)
        
        return {'p2': p2, 'p3': p3, 'p4': p4}


class C2FDecoder(nn.Module):
    """
    Coarse-to-Fine Decoder (保留用于兼容)
    从深层到浅层逐级融合特征
    """
    def __init__(self, in_dims=(512, 1024, 2048), hidden=256, use_adapter=False, adapt_levels=()):
        super().__init__()
        
        self.use_adapter = use_adapter
        self.adapt_levels = adapt_levels
        
        # 投影层
        self.proj_c2 = ConvBNReLU(in_dims[0], hidden)
        self.proj_c3 = ConvBNReLU(in_dims[1], hidden)
        self.proj_c4 = ConvBNReLU(in_dims[2], hidden)
        
        # 融合层
        self.fuse4 = ConvBNReLU(hidden, hidden)
        self.fuse3 = ConvBNReLU(hidden * 2, hidden)
        self.fuse2 = ConvBNReLU(hidden * 2, hidden)
        
        # Adapter（可选）
        if use_adapter:
            self.adapters = nn.ModuleDict()
            if 'p2' in adapt_levels:
                self.adapters['p2'] = Adapter(hidden)
            if 'p3' in adapt_levels:
                self.adapters['p3'] = Adapter(hidden)
            if 'p4' in adapt_levels:
                self.adapters['p4'] = Adapter(hidden)
        
    def forward(self, c2, c3, c4):
        """
        输入: c2(/8), c3(/16), c4(/32)
        输出: p2(/8), p3(/16), p4(/32) 以及 logits
        """
        # 投影
        p4 = self.proj_c4(c4)  # /32
        p3 = self.proj_c3(c3)  # /16
        p2 = self.proj_c2(c2)  # /8
        
        # Adapter
        if self.use_adapter:
            if 'p4' in self.adapt_levels and 'p4' in self.adapters:
                p4 = self.adapters['p4'](p4)
            if 'p3' in self.adapt_levels and 'p3' in self.adapters:
                p3 = self.adapters['p3'](p3)
            if 'p2' in self.adapt_levels and 'p2' in self.adapters:
                p2 = self.adapters['p2'](p2)
        
        # 自顶向下融合
        f4 = self.fuse4(p4)
        f4_up = F.interpolate(f4, size=p3.shape[2:], mode='bilinear', align_corners=False)
        f3 = self.fuse3(torch.cat([p3, f4_up], dim=1))
        f3_up = F.interpolate(f3, size=p2.shape[2:], mode='bilinear', align_corners=False)
        f2 = self.fuse2(torch.cat([p2, f3_up], dim=1))
        
        return {'p2': f2, 'p3': f3, 'p4': f4}


class EdgeDetector(nn.Module):
    """Sobel 边缘检测器"""
    def __init__(self, in_c, out_c):
        super().__init__()
        
        self.sobel_x = nn.Conv2d(in_c, in_c, 3, padding=1, bias=False, groups=in_c)
        self.sobel_y = nn.Conv2d(in_c, in_c, 3, padding=1, bias=False, groups=in_c)
        
        # Sobel 算子
        sobel_x = torch.tensor([[[-1, 0, 1],
                                 [-2, 0, 2],
                                 [-1, 0, 1]]], dtype=torch.float32)
        sobel_y = sobel_x.transpose(-1, -2)
        
        self.sobel_x.weight.data = sobel_x.repeat(in_c, 1, 1, 1)
        self.sobel_y.weight.data = sobel_y.repeat(in_c, 1, 1, 1)
        
        for p in self.sobel_x.parameters():
            p.requires_grad = False
        for p in self.sobel_y.parameters():
            p.requires_grad = False
        
        self.conv = ConvBNReLU(in_c, out_c)
        
    def forward(self, feat):
        gx = self.sobel_x(feat)
        gy = self.sobel_y(feat)
        edges = torch.abs(gx) + torch.abs(gy)
        return self.conv(edges)


class PredHead(nn.Module):
    """预测头"""
    def __init__(self, in_c, out_c=1):
        super().__init__()
        self.conv = nn.Sequential(
            ConvBNReLU(in_c, in_c // 2),
            nn.Conv2d(in_c // 2, out_c, 1)
        )
        
    def forward(self, x):
        return self.conv(x)
