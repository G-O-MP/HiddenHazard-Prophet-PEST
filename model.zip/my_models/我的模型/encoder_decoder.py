# -*- coding: utf-8 -*-
"""
ResNet 编码器与 C2F (Coarse-to-Fine) 解码器
用于小样本伪装目标分割的多尺度特征提取与解码
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import models

try:
    from .modules import ConvBNReLU
    from .tta import Adapter
except ImportError:
    from modules import ConvBNReLU
    from tta import Adapter


# ==================== ResNet 多尺度编码器 ====================

class ResNetEncoder(nn.Module):
    """
    ResNet 多尺度特征提取器
    
    输出 4 个尺度特征：
    - C2: 1/4 分辨率 (256 channels for ResNet50)
    - C3: 1/8 分辨率 (512 channels)
    - C4: 1/16 分辨率 (1024 channels)
    - C5: 1/32 分辨率 (2048 channels)
    """
    def __init__(self, backbone='resnet50', pretrained=True):
        super().__init__()
        
        if backbone == 'resnet50':
            if pretrained:
                resnet = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V1)
            else:
                resnet = models.resnet50(weights=None)
            self.feat_dims = {'c2': 256, 'c3': 512, 'c4': 1024, 'c5': 2048}
        elif backbone == 'resnet101':
            if pretrained:
                resnet = models.resnet101(weights=models.ResNet101_Weights.IMAGENET1K_V1)
            else:
                resnet = models.resnet101(weights=None)
            self.feat_dims = {'c2': 256, 'c3': 512, 'c4': 1024, 'c5': 2048}
        elif backbone == 'resnet34':
            if pretrained:
                resnet = models.resnet34(weights=models.ResNet34_Weights.IMAGENET1K_V1)
            else:
                resnet = models.resnet34(weights=None)
            self.feat_dims = {'c2': 64, 'c3': 128, 'c4': 256, 'c5': 512}
        else:
            raise NotImplementedError(f"Backbone {backbone} not supported")
        
        # 分离 ResNet 各层
        self.stem = nn.Sequential(
            resnet.conv1,
            resnet.bn1, 
            resnet.relu, 
            resnet.maxpool
        )  # 输出 1/4 分辨率
        
        self.layer1 = resnet.layer1  # C2: 1/4
        self.layer2 = resnet.layer2  # C3: 1/8
        self.layer3 = resnet.layer3  # C4: 1/16
        self.layer4 = resnet.layer4  # C5: 1/32

    def forward(self, x):
        """
        Args:
            x: (B, 3, H, W) 输入图像
        
        Returns:
            feats: dict with keys 'c2', 'c3', 'c4', 'c5'
        """
        x = self.stem(x)
        c2 = self.layer1(x)   # (B, 256, H/4, W/4)
        c3 = self.layer2(c2)  # (B, 512, H/8, W/8)
        c4 = self.layer3(c3)  # (B, 1024, H/16, W/16)
        c5 = self.layer4(c4)  # (B, 2048, H/32, W/32)
        return {"c2": c2, "c3": c3, "c4": c4, "c5": c5}

    def get_feat_dim(self, level):
        """获取指定层的特征维度"""
        return self.feat_dims[level]


# ==================== C2F 解码器 ====================

class C2FDecoder(nn.Module):
    """
    Coarse-to-Fine 解码器
    
    从 C5 (1/32) 开始，逐级上采样融合 C4/C3/C2，
    每一级输入都拼接 [feat, up_logits, guidance]
    
    guidance 来自原型匹配的相似度图
    
    支持 TTA (Test-Time Adaptation):
    - use_adapter=True 时在每层投影后插入轻量级 Adapter
    - TTA 时只更新 Adapter 参数，主干冻结
    """
    def __init__(self, 
                 ch_c2=256, ch_c3=512, ch_c4=1024, ch_c5=2048,
                 guide_ch=2, 
                 mid=256,
                 use_adapter=False,
                 adapter_reduction=16):
        """
        Args:
            ch_c2-ch_c5: 各层特征通道数（对应 ResNet50）
            guide_ch: guidance map 通道数（2 = s_diff + s_edge）
            mid: 中间特征通道数
            use_adapter: 是否使用 Adapter（用于 TTA）
            adapter_reduction: Adapter 的降维比例
        """
        super().__init__()
        
        self.use_adapter = use_adapter
        
        # 将 encoder 输出投影到 mid 维度
        self.p5 = ConvBNReLU(ch_c5, mid, k=1, p=0)
        self.p4 = ConvBNReLU(ch_c4, mid, k=1, p=0)
        self.p3 = ConvBNReLU(ch_c3, mid, k=1, p=0)
        self.p2 = ConvBNReLU(ch_c2, mid, k=1, p=0)
        
        # 可选的 Adapter（用于 TTA）
        if use_adapter:
            self.adapter5 = Adapter(mid, reduction=adapter_reduction)
            self.adapter4 = Adapter(mid, reduction=adapter_reduction)
            self.adapter3 = Adapter(mid, reduction=adapter_reduction)
            self.adapter2 = Adapter(mid, reduction=adapter_reduction)

        # 每层 refine 模块
        # Level 5 (1/32): 输入 = mid + guide_ch (无上一级 logit)
        self.r5 = nn.Sequential(
            ConvBNReLU(mid + guide_ch, mid),
            ConvBNReLU(mid, mid)
        )
        self.h5 = nn.Conv2d(mid, 1, 1)

        # Level 4 (1/16): 输入 = mid + 1(上采样 logit) + guide_ch
        self.r4 = nn.Sequential(
            ConvBNReLU(mid + 1 + guide_ch, mid),
            ConvBNReLU(mid, mid)
        )
        self.h4 = nn.Conv2d(mid, 1, 1)

        # Level 3 (1/8): 输入 = mid + 1 + guide_ch
        self.r3 = nn.Sequential(
            ConvBNReLU(mid + 1 + guide_ch, mid),
            ConvBNReLU(mid, mid)
        )
        self.h3 = nn.Conv2d(mid, 1, 1)

        # Level 2 (1/4): 输入 = mid + 1 + guide_ch
        self.r2 = nn.Sequential(
            ConvBNReLU(mid + 1 + guide_ch, mid),
            ConvBNReLU(mid, mid)
        )
        self.h2 = nn.Conv2d(mid, 1, 1)

    def forward(self, feats, guides):
        """
        Args:
            feats: dict with keys 'c2', 'c3', 'c4', 'c5'
            guides: dict with keys 'g2', 'g3', 'g4', 'g5'
                    each (B, guide_ch, H/scale, W/scale)
        
        Returns:
            logits: dict with keys 'log2', 'log3', 'log4', 'log5'
        """
        c2, c3, c4, c5 = feats["c2"], feats["c3"], feats["c4"], feats["c5"]
        g2, g3, g4, g5 = guides["g2"], guides["g3"], guides["g4"], guides["g5"]

        # Level 5 (1/32) - 最粗糙
        p5 = self.p5(c5)
        if self.use_adapter:
            p5 = self.adapter5(p5)
        x5 = self.r5(torch.cat([p5, g5], dim=1))
        log5 = self.h5(x5)

        # Level 4 (1/16)
        p4 = self.p4(c4)
        if self.use_adapter:
            p4 = self.adapter4(p4)
        log5_up = F.interpolate(log5, size=p4.shape[-2:], mode="bilinear", align_corners=False)
        x4 = self.r4(torch.cat([p4, log5_up, g4], dim=1))
        log4 = self.h4(x4)

        # Level 3 (1/8)
        p3 = self.p3(c3)
        if self.use_adapter:
            p3 = self.adapter3(p3)
        log4_up = F.interpolate(log4, size=p3.shape[-2:], mode="bilinear", align_corners=False)
        x3 = self.r3(torch.cat([p3, log4_up, g3], dim=1))
        log3 = self.h3(x3)

        # Level 2 (1/4) - 最精细
        p2 = self.p2(c2)
        if self.use_adapter:
            p2 = self.adapter2(p2)
        log3_up = F.interpolate(log3, size=p2.shape[-2:], mode="bilinear", align_corners=False)
        x2 = self.r2(torch.cat([p2, log3_up, g2], dim=1))
        log2 = self.h2(x2)

        return {"log2": log2, "log3": log3, "log4": log4, "log5": log5}
    
    def get_adapter_params(self):
        """获取所有 Adapter 参数（用于 TTA）"""
        if not self.use_adapter:
            return []
        params = []
        for name, module in self.named_modules():
            if isinstance(module, Adapter):
                params.extend(module.parameters())
        return params


# ==================== C2F Decoder with Selective Adapter ====================

class C2FDecoderWithAdapter(nn.Module):
    """
    增强版 C2F 解码器，支持选择性 Adapter
    
    特点：
    1. 可通过 adapt_levels 指定哪些层使用 Adapter
    2. 用户可选择只在 p2/p3 或 p2/p3/p4 等层添加 Adapter
    3. TTA 时只更新指定层的 Adapter，更灵活
    
    推荐配置：
    - adapt_levels=("p2", "p3"): 最稳定，只在细粒度层做 TTA
    - adapt_levels=("p2", "p3", "p4"): 适中
    - adapt_levels=("p2", "p3", "p4", "p5"): 更强但风险更大
    
    Args:
        ch_c2-ch_c5: 各层特征通道数
        guide_ch: guidance map 通道数
        mid: 中间特征通道数
        use_adapter: 是否启用 Adapter
        adapt_levels: 哪些层使用 Adapter，如 ("p2", "p3")
        adapter_reduction: Adapter 降维比例
    """
    def __init__(self, 
                 ch_c2=256, ch_c3=512, ch_c4=1024, ch_c5=2048,
                 guide_ch=2, 
                 mid=256,
                 use_adapter=True,
                 adapt_levels=("p2", "p3"),
                 adapter_reduction=16):
        super().__init__()
        
        self.use_adapter = use_adapter
        self.adapt_levels = set(adapt_levels) if use_adapter else set()
        self.mid = mid
        
        # 将 encoder 输出投影到 mid 维度
        self.p5 = ConvBNReLU(ch_c5, mid, k=1, p=0)
        self.p4 = ConvBNReLU(ch_c4, mid, k=1, p=0)
        self.p3 = ConvBNReLU(ch_c3, mid, k=1, p=0)
        self.p2 = ConvBNReLU(ch_c2, mid, k=1, p=0)
        
        # 选择性 Adapter
        if use_adapter:
            if "p5" in self.adapt_levels:
                self.adapter5 = Adapter(mid, reduction=adapter_reduction)
            if "p4" in self.adapt_levels:
                self.adapter4 = Adapter(mid, reduction=adapter_reduction)
            if "p3" in self.adapt_levels:
                self.adapter3 = Adapter(mid, reduction=adapter_reduction)
            if "p2" in self.adapt_levels:
                self.adapter2 = Adapter(mid, reduction=adapter_reduction)

        # 每层 refine 模块
        # Level 5 (1/32): 输入 = mid + guide_ch
        self.r5 = nn.Sequential(
            ConvBNReLU(mid + guide_ch, mid),
            ConvBNReLU(mid, mid)
        )
        self.h5 = nn.Conv2d(mid, 1, 1)

        # Level 4 (1/16): 输入 = mid + 1(上采样 logit) + guide_ch
        self.r4 = nn.Sequential(
            ConvBNReLU(mid + 1 + guide_ch, mid),
            ConvBNReLU(mid, mid)
        )
        self.h4 = nn.Conv2d(mid, 1, 1)

        # Level 3 (1/8)
        self.r3 = nn.Sequential(
            ConvBNReLU(mid + 1 + guide_ch, mid),
            ConvBNReLU(mid, mid)
        )
        self.h3 = nn.Conv2d(mid, 1, 1)

        # Level 2 (1/4) - 最精细
        self.r2 = nn.Sequential(
            ConvBNReLU(mid + 1 + guide_ch, mid),
            ConvBNReLU(mid, mid)
        )
        self.h2 = nn.Conv2d(mid, 1, 1)

    def forward(self, feats, guides):
        """
        Args:
            feats: dict with keys 'c2', 'c3', 'c4', 'c5'
            guides: dict with keys 'g2', 'g3', 'g4', 'g5'
        
        Returns:
            logits: dict with keys 'log2', 'log3', 'log4', 'log5'
        """
        c2, c3, c4, c5 = feats["c2"], feats["c3"], feats["c4"], feats["c5"]
        g2, g3, g4, g5 = guides["g2"], guides["g3"], guides["g4"], guides["g5"]

        # Level 5 (1/32)
        p5 = self.p5(c5)
        if self.use_adapter and "p5" in self.adapt_levels:
            p5 = self.adapter5(p5)
        x5 = self.r5(torch.cat([p5, g5], dim=1))
        log5 = self.h5(x5)

        # Level 4 (1/16)
        p4 = self.p4(c4)
        if self.use_adapter and "p4" in self.adapt_levels:
            p4 = self.adapter4(p4)
        log5_up = F.interpolate(log5, size=p4.shape[-2:], mode="bilinear", align_corners=False)
        x4 = self.r4(torch.cat([p4, log5_up, g4], dim=1))
        log4 = self.h4(x4)

        # Level 3 (1/8)
        p3 = self.p3(c3)
        if self.use_adapter and "p3" in self.adapt_levels:
            p3 = self.adapter3(p3)
        log4_up = F.interpolate(log4, size=p3.shape[-2:], mode="bilinear", align_corners=False)
        x3 = self.r3(torch.cat([p3, log4_up, g3], dim=1))
        log3 = self.h3(x3)

        # Level 2 (1/4)
        p2 = self.p2(c2)
        if self.use_adapter and "p2" in self.adapt_levels:
            p2 = self.adapter2(p2)
        log3_up = F.interpolate(log3, size=p2.shape[-2:], mode="bilinear", align_corners=False)
        x2 = self.r2(torch.cat([p2, log3_up, g2], dim=1))
        log2 = self.h2(x2)

        return {"log2": log2, "log3": log3, "log4": log4, "log5": log5}
    
    def get_adapter_params(self):
        """
        获取所有 Adapter 参数（用于 TTA）
        
        Returns:
            参数列表
        """
        if not self.use_adapter:
            return []
        
        params = []
        for lvl in ["p2", "p3", "p4", "p5"]:
            if lvl in self.adapt_levels:
                adapter_name = f"adapter{lvl[1]}"  # "p2" -> "adapter2"
                if hasattr(self, adapter_name):
                    adapter = getattr(self, adapter_name)
                    params.extend(adapter.parameters())
        return params
    
    def get_head_params(self):
        """获取预测头参数"""
        params = []
        for h in [self.h2, self.h3, self.h4, self.h5]:
            params.extend(h.parameters())
        return params
    
    def count_adapter_params(self):
        """统计 Adapter 参数量"""
        return sum(p.numel() for p in self.get_adapter_params())


# ==================== 测试代码 ====================

if __name__ == "__main__":
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    # 测试 ResNetEncoder
    encoder = ResNetEncoder(backbone='resnet50', pretrained=False).to(device)
    
    x = torch.randn(2, 3, 512, 512).to(device)
    feats = encoder(x)
    
    print("ResNetEncoder 输出尺寸:")
    for k, v in feats.items():
        print(f"  {k}: {v.shape}")
    
    # 测试 C2FDecoder
    guide_ch = 2
    decoder = C2FDecoder(
        ch_c2=256, ch_c3=512, ch_c4=1024, ch_c5=2048,
        guide_ch=guide_ch, mid=256
    ).to(device)
    
    # 构造假的 guidance maps
    guides = {
        "g2": torch.randn(2, guide_ch, 128, 128).to(device),
        "g3": torch.randn(2, guide_ch, 64, 64).to(device),
        "g4": torch.randn(2, guide_ch, 32, 32).to(device),
        "g5": torch.randn(2, guide_ch, 16, 16).to(device),
    }
    
    logits = decoder(feats, guides)
    
    print("\nC2FDecoder 输出尺寸:")
    for k, v in logits.items():
        print(f"  {k}: {v.shape}")
    
    print("\n编码器和解码器测试通过!")
