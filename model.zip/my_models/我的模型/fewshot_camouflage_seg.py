# -*- coding: utf-8 -*-
"""
FewShotCamouflageSeg - 小样本伪装目标分割融合框架

核心思路：
1. FG/BG 对比原型 - 区分前景和背景
2. 边界原型 - 捕捉目标边界信息
3. Token 原型集合 - 更精细的区域表示
4. Proto-guided C2F 解码 - 多尺度细化
5. Cross-Attention + DyT - 在 c4 层做 support→query 信息传递 (可选)

约定：1-way K-shot (K=5)
输入：support_imgs/support_masks/query_img
输出：query 的 mask logits
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, Tuple, Optional, List

try:
    from .modules import MaskedAvgPool, ProtoMatcher, TokenProtoBuilder, make_edge_mask, ProtoBuilder, GuideBuilder
    from .encoder_decoder import ResNetEncoder, C2FDecoder, C2FDecoderWithAdapter
    from .cross_attention import ProtoFormerBridge
except ImportError:
    from modules import MaskedAvgPool, ProtoMatcher, TokenProtoBuilder, make_edge_mask, ProtoBuilder, GuideBuilder
    from encoder_decoder import ResNetEncoder, C2FDecoder, C2FDecoderWithAdapter
    from cross_attention import ProtoFormerBridge


class FewShotCamouflageSeg(nn.Module):
    """
    小样本伪装目标分割融合框架
    
    Pipeline:
    1. 编码器提取 support 和 query 的多尺度特征
    2. 从 support 构建原型 (FG/BG/Edge + Token)
    3. (可选) 在 c4 层做 Cross-Attention 增强 query 特征
    4. 使用原型计算 query 上的 guidance maps
    5. C2F 解码器利用 guidance 生成分割结果
    
    TTA 支持:
    - Adapter 插在 decoder 的 p2/p3/p4/p5 投影后
    - TTA 时只更新 adapter 参数，保持主干冻结
    
    Cross-Attention 支持:
    - 在 c4 层用 support memory 增强 query 特征
    - 使用 DyT 替代 LayerNorm，更轻量
    """
    
    def __init__(self, 
                 backbone: str = 'resnet50',
                 pretrained: bool = True,
                 use_edge: bool = True, 
                 use_token: bool = True, 
                 token_grid: Tuple[int, int] = (3, 3),
                 mid_ch: int = 256,
                 edge_kernel: int = 7,
                 use_adapter: bool = False,
                 adapter_reduction: int = 16,
                 # Cross-Attention 相关参数
                 use_cross_attn: bool = False,
                 cross_attn_num_heads: int = 8,
                 cross_attn_nfg: int = 64,
                 cross_attn_nbg: int = 64,
                 cross_attn_nedge: int = 64,
                 cross_attn_mlp_ratio: float = 4.0,
                 cross_attn_res_scale: float = 0.1):
        """
        Args:
            backbone: 主干网络 ('resnet50', 'resnet101', 'resnet34')
            pretrained: 是否使用预训练权重
            use_edge: 是否使用边界原型
            use_token: 是否使用 token 原型
            token_grid: token 网格大小 (tH, tW)
            mid_ch: 解码器中间通道数
            edge_kernel: 边界 mask 构造的卷积核大小
            use_adapter: 是否使用 Adapter（用于 TTA）
            adapter_reduction: Adapter 的降维比例
            use_cross_attn: 是否使用 Cross-Attention (在 c4 层)
            cross_attn_num_heads: Cross-Attention 头数
            cross_attn_nfg: 前景 memory token 数量
            cross_attn_nbg: 背景 memory token 数量
            cross_attn_nedge: 边界 memory token 数量
            cross_attn_mlp_ratio: Cross-Attention MLP 扩展比例
            cross_attn_res_scale: Cross-Attention 残差缩放因子
        """
        super().__init__()
        
        self.use_edge = use_edge
        self.use_token = use_token
        self.edge_kernel = edge_kernel
        self.use_adapter = use_adapter
        self.use_cross_attn = use_cross_attn
        
        # 编码器
        self.encoder = ResNetEncoder(backbone=backbone, pretrained=pretrained)
        feat_dims = self.encoder.feat_dims
        
        # 原型相关模块
        self.pool = MaskedAvgPool()
        self.match = ProtoMatcher()
        
        if use_token:
            self.token_builder = TokenProtoBuilder(*token_grid)
        
        # Cross-Attention Bridge (在 c4 层)
        if use_cross_attn:
            self.cross_attn_bridge = ProtoFormerBridge(
                dim=feat_dims['c4'],
                num_heads=cross_attn_num_heads,
                use_edge=use_edge,
                nfg=cross_attn_nfg,
                nbg=cross_attn_nbg,
                nedge=cross_attn_nedge,
                edge_kernel=edge_kernel,
                mlp_ratio=cross_attn_mlp_ratio,
                res_scale=cross_attn_res_scale
            )
        
        # Guidance 通道数：s_diff(1) + s_edge(1) = 2（若不用 edge 则为 1）
        guide_ch = 2 if use_edge else 1
        
        # C2F 解码器
        self.decoder = C2FDecoder(
            ch_c2=feat_dims['c2'],
            ch_c3=feat_dims['c3'],
            ch_c4=feat_dims['c4'],
            ch_c5=feat_dims['c5'],
            guide_ch=guide_ch,
            mid=mid_ch,
            use_adapter=use_adapter,
            adapter_reduction=adapter_reduction
        )

    def build_protos(self, support_feats, support_mask):
        """
        从 support set 构建原型
        
        Args:
            support_feats: dict c2..c5, 每个 (K, C, H, W)，K 是 shot 数
            support_mask: (K, 1, H0, W0) 原始分辨率的 mask
        
        Returns:
            protos: 每层的原型字典
                - p_fg: (1, C) 前景原型
                - p_bg: (1, C) 背景原型  
                - p_edge: (1, C) 边界原型 (可选)
                - t_fg: (1, Kt, C) 前景 token 原型 (可选)
                - t_bg: (1, Kt, C) 背景 token 原型 (可选)
        """
        protos = {}
        M = support_mask  # (K, 1, H, W)
        
        if self.use_edge:
            M_edge = make_edge_mask(M, k=self.edge_kernel)
        
        for lvl in ["c2", "c3", "c4", "c5"]:
            Fs = support_feats[lvl]  # (K, C, h, w)
            
            # 前景和背景原型
            p_fg = self.pool(Fs, M)            # (K, C)
            p_bg = self.pool(Fs, 1.0 - M)      # (K, C)
            
            # 聚合 K-shot：平均成一个原型
            p_fg = p_fg.mean(dim=0, keepdim=True)  # (1, C)
            p_bg = p_bg.mean(dim=0, keepdim=True)
            
            protos[lvl] = {"p_fg": p_fg, "p_bg": p_bg}
            
            # 边界原型
            if self.use_edge:
                p_edge = self.pool(Fs, M_edge).mean(dim=0, keepdim=True)  # (1, C)
                protos[lvl]["p_edge"] = p_edge
            
            # Token 原型
            if self.use_token:
                # 每张 support 得到 tokens，再平均
                tokens_fg = self.token_builder(Fs, M)           # (K, Kt, C)
                tokens_bg = self.token_builder(Fs, 1.0 - M)     # (K, Kt, C)
                protos[lvl]["t_fg"] = tokens_fg.mean(dim=0, keepdim=True)  # (1, Kt, C)
                protos[lvl]["t_bg"] = tokens_bg.mean(dim=0, keepdim=True)
        
        return protos

    def build_guides(self, query_feats, protos):
        """
        使用原型在 query 特征上生成 guidance maps
        
        Args:
            query_feats: dict c2..c5, 每个 (B, C, h, w)
            protos: 原型字典（来自 build_protos）
        
        Returns:
            guides: dict g2..g5, 每个 (B, guide_ch, h, w)
                - guide_ch=2: [s_diff, s_edge]
                - guide_ch=1: [s_diff]
        """
        guides = {}
        lvl_to_gname = {"c2": "g2", "c3": "g3", "c4": "g4", "c5": "g5"}
        
        for lvl, gname in lvl_to_gname.items():
            Fq = query_feats[lvl]  # (B, C, h, w)
            
            if self.use_token:
                # 使用 token 原型计算相似度
                sim_fg = self.match(Fq, protos[lvl]["t_fg"], aggregate="max")  # (B, 1, h, w)
                sim_bg = self.match(Fq, protos[lvl]["t_bg"], aggregate="max")
            else:
                # 使用全局原型计算相似度
                sim_fg = self.match(Fq, protos[lvl]["p_fg"])
                sim_bg = self.match(Fq, protos[lvl]["p_bg"])
            
            # 差异图：前景 - 背景
            s_diff = sim_fg - sim_bg  # (B, 1, h, w)
            
            if self.use_edge:
                # 边界相似度图
                sim_edge = self.match(Fq, protos[lvl]["p_edge"])  # (B, 1, h, w)
                guides[gname] = torch.cat([s_diff, sim_edge], dim=1)  # (B, 2, h, w)
            else:
                guides[gname] = s_diff  # (B, 1, h, w)
        
        return guides

    def forward(self, support_imgs, support_masks, query_img):
        """
        前向传播
        
        Args:
            support_imgs: (K, 3, H, W) K-shot support 图像
            support_masks: (K, 1, H, W) float {0, 1} support masks
            query_img: (B, 3, H, W) query 图像，通常 B=1
        
        Returns:
            out: (B, 1, H, W) 最终预测 logits
            logits: dict 多尺度 logits (log2..log5)
            guides: dict 多尺度 guidance maps (g2..g5)
        """
        # 确保 support_masks 是 4D
        if support_masks.dim() == 3:
            support_masks = support_masks.unsqueeze(1)
        
        # 1) 编码器提取特征
        s_feats = self.encoder(support_imgs)  # dict c2..c5
        q_feats = self.encoder(query_img)
        
        # 2) (可选) 在 c4 层做 Cross-Attention 增强
        if self.use_cross_attn:
            q_feats = self._apply_cross_attention(q_feats, s_feats, support_masks)
        
        # 3) 从 support 构建原型
        protos = self.build_protos(s_feats, support_masks)
        
        # 4) 在 query 上生成 guidance maps
        guides = self.build_guides(q_feats, protos)
        
        # 5) C2F 解码
        logits = self.decoder(q_feats, guides)  # log2..log5
        
        # 6) 上采样到原始分辨率
        out = F.interpolate(
            logits["log2"], 
            size=query_img.shape[-2:], 
            mode="bilinear", 
            align_corners=False
        )
        
        return out, logits, guides
    
    def _apply_cross_attention(self, q_feats: Dict, s_feats: Dict, s_mask: torch.Tensor) -> Dict:
        """
        在 c4 层应用 Cross-Attention 增强
        
        Args:
            q_feats: query 特征 dict (c2..c5)
            s_feats: support 特征 dict (c2..c5)
            s_mask: support masks (K, 1, H, W)
        
        Returns:
            增强后的 q_feats (只有 c4 被修改)
        """
        # 只增强 c4
        q_c4_enhanced = self.cross_attn_bridge(
            q_c4=q_feats['c4'],
            s_c4=s_feats['c4'],
            s_mask=s_mask
        )
        
        # 返回修改后的特征 dict
        return {
            'c2': q_feats['c2'],
            'c3': q_feats['c3'],
            'c4': q_c4_enhanced,
            'c5': q_feats['c5']
        }

    def get_tta_params(self, mode: str = "adapter"):
        """
        获取 TTA 时需要更新的参数
        
        Args:
            mode: 更新模式
                - "adapter": 只更新 decoder 中的 adapter 参数（最稳定）
                - "decoder": 更新整个 decoder
                - "decoder_head": 只更新 decoder 的预测头 (h2, h3, h4, h5)
        
        Returns:
            参数列表
        """
        params = []
        
        if mode == "adapter":
            # 只更新 adapter 参数
            if self.use_adapter and hasattr(self.decoder, 'get_adapter_params'):
                params = self.decoder.get_adapter_params()
            else:
                # 如果没有 adapter，回退到 decoder_head
                for name, param in self.decoder.named_parameters():
                    if any(h in name for h in ['h2', 'h3', 'h4', 'h5']):
                        if param.requires_grad:
                            params.append(param)
        
        elif mode == "decoder":
            # 更新整个 decoder
            for param in self.decoder.parameters():
                if param.requires_grad:
                    params.append(param)
        
        elif mode == "decoder_head":
            # 只更新 decoder 的预测头
            for name, param in self.decoder.named_parameters():
                if any(h in name for h in ['h2', 'h3', 'h4', 'h5']):
                    if param.requires_grad:
                        params.append(param)
        
        else:
            raise ValueError(f"Unknown TTA mode: {mode}. Choose from 'adapter', 'decoder', 'decoder_head'")
        
        return params
    
    def count_tta_params(self, mode: str = "adapter"):
        """统计 TTA 参数量"""
        params = self.get_tta_params(mode)
        return sum(p.numel() for p in params)
    
    def get_cross_attn_params(self) -> List[torch.nn.Parameter]:
        """
        获取 Cross-Attention 模块的参数
        
        Returns:
            参数列表
        """
        if not self.use_cross_attn:
            return []
        return list(self.cross_attn_bridge.parameters())
    
    def freeze_encoder(self):
        """冻结编码器参数"""
        for param in self.encoder.parameters():
            param.requires_grad = False
    
    def unfreeze_decoder(self):
        """解冻解码器参数"""
        for param in self.decoder.parameters():
            param.requires_grad = True
    
    def freeze_all_except_adapter(self):
        """
        冻结除 adapter 外的所有参数
        用于 TTA 时只更新 adapter
        """
        for param in self.parameters():
            param.requires_grad = False
        
        if self.use_adapter:
            for param in self.decoder.get_adapter_params():
                param.requires_grad = True


# ==================== 轻量版模型（不使用 Token 和 Edge）====================

class FewShotCamouflageSeg_Lite(FewShotCamouflageSeg):
    """轻量版：仅使用 FG/BG 对比原型，不使用 Token 和 Edge"""
    
    def __init__(self, backbone='resnet50', pretrained=True, mid_ch=256):
        super().__init__(
            backbone=backbone,
            pretrained=pretrained,
            use_edge=False,
            use_token=False,
            mid_ch=mid_ch
        )


class FewShotCamouflageSeg_CrossAttn(FewShotCamouflageSeg):
    """
    带 Cross-Attention 增强的版本
    
    在 c4 层用 support memory 增强 query 特征
    使用 DyT 替代 LayerNorm，更轻量高效
    """
    
    def __init__(self, 
                 backbone='resnet50', 
                 pretrained=True, 
                 mid_ch=256,
                 use_adapter=False,
                 adapter_reduction=16,
                 cross_attn_num_heads=8,
                 cross_attn_nfg=64,
                 cross_attn_nbg=64,
                 cross_attn_nedge=64):
        super().__init__(
            backbone=backbone,
            pretrained=pretrained,
            use_edge=True,
            use_token=True,
            mid_ch=mid_ch,
            use_adapter=use_adapter,
            adapter_reduction=adapter_reduction,
            use_cross_attn=True,
            cross_attn_num_heads=cross_attn_num_heads,
            cross_attn_nfg=cross_attn_nfg,
            cross_attn_nbg=cross_attn_nbg,
            cross_attn_nedge=cross_attn_nedge
        )


# ==================== 集成版 TTA 模型 ====================

class FewShotCamouflageSeg_ProtoFormerTTA(nn.Module):
    """
    小样本伪装目标分割 - ProtoFormer TTA 版本
    
    这是最终的"冲榜"版本，集成所有核心组件：
    
    1. ResNet 编码器 - 提取多尺度特征 (c2..c5)
    2. 原型构建 - FG/BG/EDGE 原型 + 可选 Token 原型
    3. ProtoFormer Bridge - c4 层 Cross-Attention 增强 query
    4. C2F Decoder with Adapter - 带 TTA 支持的解码器
    
    TTA 策略：
    - adapter_only: 只更新 decoder 中的 adapter (最稳定)
    - adapter_plus_cross: 更新 adapter + bridge.cross 的投影层 (更强)
    - adapter_plus_head: 更新 adapter + decoder 预测头
    
    论文关键词：
    - Support-conditioned Cross-Attention Memory
    - FG/BG/Edge Memory Tokens
    - Proto-guided Coarse-to-Fine Decoder
    - Support-supervised TTA with Tiny Adapters
    
    Args:
        backbone: 主干网络 ('resnet50', 'resnet101')
        pretrained: 是否使用预训练权重
        use_edge: 是否使用边界原型
        use_token_proto: 是否使用 Token 原型集合
        token_grid: Token 网格大小 (tH, tW)
        use_cross_attn: 是否使用 c4 Cross-Attention
        cross_dim: Cross-Attention 维度 (ResNet50 c4=1024)
        cross_num_heads: Cross-Attention 头数
        cross_nfg/nbg/nedge: Memory token 数量
        cross_res_scale: Cross-Attention 残差缩放因子
        use_adapter: 是否使用 Adapter (TTA 必须)
        adapt_levels: 哪些层使用 Adapter
        adapter_reduction: Adapter 降维比例
        mid_ch: Decoder 中间通道数
        edge_kernel: 边界 mask 卷积核大小
    """
    
    def __init__(self,
                 backbone: str = 'resnet50',
                 pretrained: bool = True,
                 # 原型相关
                 use_edge: bool = True,
                 use_token_proto: bool = True,
                 token_grid: Tuple[int, int] = (3, 3),
                 # Cross-Attention 相关
                 use_cross_attn: bool = True,
                 cross_dim: int = 1024,
                 cross_num_heads: int = 8,
                 cross_nfg: int = 64,
                 cross_nbg: int = 64,
                 cross_nedge: int = 64,
                 cross_res_scale: float = 0.1,
                 # Adapter 相关 (TTA)
                 use_adapter: bool = True,
                 adapt_levels: Tuple[str, ...] = ("p2", "p3"),
                 adapter_reduction: int = 16,
                 # Decoder 相关
                 mid_ch: int = 256,
                 edge_kernel: int = 7):
        super().__init__()
        
        self.use_edge = use_edge
        self.use_token_proto = use_token_proto
        self.edge_kernel = edge_kernel
        self.use_cross_attn = use_cross_attn
        self.use_adapter = use_adapter
        self.adapt_levels = adapt_levels
        
        # 1. 编码器
        self.encoder = ResNetEncoder(backbone=backbone, pretrained=pretrained)
        feat_dims = self.encoder.feat_dims
        
        # 2. 原型模块
        self.pool = MaskedAvgPool()
        self.match = ProtoMatcher()
        
        if use_token_proto:
            self.token_builder = TokenProtoBuilder(*token_grid)
        
        # 3. Cross-Attention Bridge (在 c4 层)
        if use_cross_attn:
            self.bridge = ProtoFormerBridge(
                dim=cross_dim,
                num_heads=cross_num_heads,
                use_edge=use_edge,
                nfg=cross_nfg,
                nbg=cross_nbg,
                nedge=cross_nedge,
                edge_kernel=edge_kernel,
                res_scale=cross_res_scale
            )
        
        # 4. Decoder with Adapter
        guide_ch = 2 if use_edge else 1
        self.decoder = C2FDecoderWithAdapter(
            ch_c2=feat_dims['c2'],
            ch_c3=feat_dims['c3'],
            ch_c4=feat_dims['c4'],
            ch_c5=feat_dims['c5'],
            guide_ch=guide_ch,
            mid=mid_ch,
            use_adapter=use_adapter,
            adapt_levels=adapt_levels,
            adapter_reduction=adapter_reduction
        )
    
    def build_protos(self, support_feats: Dict, support_mask: torch.Tensor) -> Dict:
        """
        从 support set 构建原型
        
        Args:
            support_feats: dict c2..c5, 每个 (K, C, H, W)
            support_mask: (K, 1, H0, W0) 原始分辨率的 mask
        
        Returns:
            protos: 每层的原型字典 {p_fg, p_bg, p_edge, t_fg, t_bg}
        """
        protos = {}
        M = support_mask  # (K, 1, H, W)
        
        if self.use_edge:
            M_edge = make_edge_mask(M, k=self.edge_kernel)
        
        for lvl in ["c2", "c3", "c4", "c5"]:
            Fs = support_feats[lvl]  # (K, C, h, w)
            
            # 前景和背景原型
            p_fg = self.pool(Fs, M)            # (K, C)
            p_bg = self.pool(Fs, 1.0 - M)      # (K, C)
            
            # 聚合 K-shot：平均成一个原型
            p_fg = p_fg.mean(dim=0, keepdim=True)  # (1, C)
            p_bg = p_bg.mean(dim=0, keepdim=True)
            
            protos[lvl] = {"p_fg": p_fg, "p_bg": p_bg}
            
            # 边界原型
            if self.use_edge:
                p_edge = self.pool(Fs, M_edge).mean(dim=0, keepdim=True)  # (1, C)
                protos[lvl]["p_edge"] = p_edge
            
            # Token 原型
            if self.use_token_proto:
                tokens_fg = self.token_builder(Fs, M)           # (K, Kt, C)
                tokens_bg = self.token_builder(Fs, 1.0 - M)     # (K, Kt, C)
                protos[lvl]["t_fg"] = tokens_fg.mean(dim=0, keepdim=True)  # (1, Kt, C)
                protos[lvl]["t_bg"] = tokens_bg.mean(dim=0, keepdim=True)
        
        return protos
    
    def build_guides(self, query_feats: Dict, protos: Dict) -> Dict:
        """
        使用原型在 query 特征上生成 guidance maps
        
        Args:
            query_feats: dict c2..c5, 每个 (B, C, h, w)
            protos: 原型字典
        
        Returns:
            guides: dict g2..g5, 每个 (B, guide_ch, h, w)
        """
        guides = {}
        lvl_to_gname = {"c2": "g2", "c3": "g3", "c4": "g4", "c5": "g5"}
        
        for lvl, gname in lvl_to_gname.items():
            Fq = query_feats[lvl]  # (B, C, h, w)
            
            if self.use_token_proto:
                # 使用 token 原型计算相似度
                sim_fg = self.match(Fq, protos[lvl]["t_fg"], aggregate="max")  # (B, 1, h, w)
                sim_bg = self.match(Fq, protos[lvl]["t_bg"], aggregate="max")
            else:
                # 使用全局原型计算相似度
                sim_fg = self.match(Fq, protos[lvl]["p_fg"])
                sim_bg = self.match(Fq, protos[lvl]["p_bg"])
            
            # 差异图：前景 - 背景
            s_diff = sim_fg - sim_bg  # (B, 1, h, w)
            
            if self.use_edge:
                # 边界相似度图
                sim_edge = self.match(Fq, protos[lvl]["p_edge"])  # (B, 1, h, w)
                guides[gname] = torch.cat([s_diff, sim_edge], dim=1)  # (B, 2, h, w)
            else:
                guides[gname] = s_diff  # (B, 1, h, w)
        
        return guides
    
    def forward(self, support_imgs: torch.Tensor, support_masks: torch.Tensor, 
                query_img: torch.Tensor) -> Tuple[torch.Tensor, Dict, Dict]:
        """
        前向传播
        
        Args:
            support_imgs: (K, 3, H, W) K-shot support 图像
            support_masks: (K, 1, H, W) float {0, 1} support masks
            query_img: (B, 3, H, W) query 图像
        
        Returns:
            out: (B, 1, H, W) 最终预测 logits
            logits: dict 多尺度 logits (log2..log5)
            guides: dict 多尺度 guidance maps (g2..g5)
        """
        # 确保 support_masks 是 4D
        if support_masks.dim() == 3:
            support_masks = support_masks.unsqueeze(1)
        
        # 1) 编码 support & query
        s_feats = self.encoder(support_imgs)  # dict c2..c5
        q_feats = self.encoder(query_img)
        
        # 2) Cross-Attention 插在 c4：增强 query c4
        if self.use_cross_attn:
            q_feats = self._apply_cross_attention(q_feats, s_feats, support_masks)
        
        # 3) 从 support 构建原型
        protos = self.build_protos(s_feats, support_masks)
        
        # 4) 在 query 上生成 guidance maps
        guides = self.build_guides(q_feats, protos)
        
        # 5) C2F 解码 with guidance (+ adapter)
        logits = self.decoder(q_feats, guides)
        
        # 6) 上采样到原始分辨率
        out = F.interpolate(
            logits["log2"], 
            size=query_img.shape[-2:], 
            mode="bilinear", 
            align_corners=False
        )
        
        return out, logits, guides
    
    def _apply_cross_attention(self, q_feats: Dict, s_feats: Dict, s_mask: torch.Tensor) -> Dict:
        """在 c4 层应用 Cross-Attention 增强"""
        q_c4_enhanced = self.bridge(
            q_c4=q_feats['c4'],
            s_c4=s_feats['c4'],
            s_mask=s_mask
        )
        
        return {
            'c2': q_feats['c2'],
            'c3': q_feats['c3'],
            'c4': q_c4_enhanced,
            'c5': q_feats['c5']
        }
    
    # ==================== TTA 参数管理 ====================
    
    def get_tta_params(self, mode: str = "adapter_only") -> List[torch.nn.Parameter]:
        """
        获取 TTA 时需要更新的参数
        
        Args:
            mode:
                - "adapter_only": 只更新 decoder 中的 adapter (最稳定)
                - "adapter_plus_cross": adapter + bridge.cross 的投影层 (更强)
                - "adapter_plus_head": adapter + decoder 预测头
                - "full": adapter + cross + head (风险最大)
        
        Returns:
            参数列表
        """
        params = []
        
        if mode == "adapter_only":
            # 只更新 decoder 中的 adapter
            params = list(self.decoder.get_adapter_params())
        
        elif mode == "adapter_plus_cross":
            # 更新 adapter + bridge.cross 的 Q/K/V/Out 投影层
            params = list(self.decoder.get_adapter_params())
            if self.use_cross_attn:
                # 添加 cross attention 的投影层参数
                for name, p in self.bridge.named_parameters():
                    if "cross" in name and any(x in name for x in ["q_proj", "k_proj", "v_proj", "out_proj"]):
                        params.append(p)
        
        elif mode == "adapter_plus_head":
            # 更新 adapter + decoder 预测头
            params = list(self.decoder.get_adapter_params())
            params.extend(self.decoder.get_head_params())
        
        elif mode == "full":
            # adapter + cross + head
            params = list(self.decoder.get_adapter_params())
            params.extend(self.decoder.get_head_params())
            if self.use_cross_attn:
                for name, p in self.bridge.named_parameters():
                    if "cross" in name:
                        params.append(p)
        
        else:
            raise ValueError(f"Unknown TTA mode: {mode}. Choose from 'adapter_only', 'adapter_plus_cross', 'adapter_plus_head', 'full'")
        
        return params
    
    def count_tta_params(self, mode: str = "adapter_only") -> int:
        """统计 TTA 参数量"""
        return sum(p.numel() for p in self.get_tta_params(mode))
    
    def freeze_for_tta(self, mode: str = "adapter_only"):
        """
        冻结除 TTA 参数外的所有参数
        
        Args:
            mode: TTA 更新模式
        """
        # 先冻结所有
        for param in self.parameters():
            param.requires_grad = False
        
        # 解冻 TTA 参数
        for param in self.get_tta_params(mode):
            param.requires_grad = True
    
    def freeze_encoder(self):
        """冻结编码器参数"""
        for param in self.encoder.parameters():
            param.requires_grad = False
    
    def get_encoder_params(self) -> List[torch.nn.Parameter]:
        """获取编码器参数"""
        return list(self.encoder.parameters())
    
    def get_decoder_params(self) -> List[torch.nn.Parameter]:
        """获取解码器参数"""
        return list(self.decoder.parameters())
    
    def get_bridge_params(self) -> List[torch.nn.Parameter]:
        """获取 Cross-Attention Bridge 参数"""
        if not self.use_cross_attn:
            return []
        return list(self.bridge.parameters())


# ==================== 独立的 TTA 参数选择函数 ====================

def get_tta_params(model: nn.Module, mode: str = "adapter_only") -> List[torch.nn.Parameter]:
    """
    从模型中获取 TTA 参数（独立函数版本）
    
    支持 FewShotCamouflageSeg_ProtoFormerTTA 和其他模型
    
    Args:
        model: 模型实例
        mode:
            - "adapter_only": 只更新 decoder.adapter (最稳定)
            - "adapter_plus_cross": adapter + bridge.cross (更强)
    
    Returns:
        参数列表
    """
    params = []
    
    if mode == "adapter_only":
        for name, p in model.named_parameters():
            if "decoder" in name and "adapter" in name:
                params.append(p)
    
    elif mode == "adapter_plus_cross":
        for name, p in model.named_parameters():
            # Decoder adapter
            if "decoder" in name and "adapter" in name:
                params.append(p)
            # Bridge cross attention 投影层
            elif "bridge" in name and "cross" in name:
                if any(x in name for x in ["q_proj", "k_proj", "v_proj", "out_proj"]):
                    params.append(p)
    
    else:
        raise ValueError(f"Unknown mode: {mode}")
    
    return params


# ==================== 简洁版模型 (FS_CamoSeg_Model) ====================

class FS_CamoSeg_Model(nn.Module):
    """
    简洁版小样本伪装目标分割模型
    
    完全匹配 ResNetEncoder dict + episode shape
    
    推荐配置（最容易 >0.75）:
    - use_edge=True
    - use_cross_attn=True（DyT 生效）
    - use_token_proto=False（先别开，降风险）
    - use_adapter=True（训练阶段先不用 TTA）
    - encoder BN 冻结
    - 测试时再加 TTA(adapter_only) 冲分
    
    Args:
        encoder: ResNetEncoder 实例
        use_edge: 是否使用边界原型
        use_cross_attn: 是否在 c4 层使用 Cross-Attention
        use_token_proto: 是否使用 Token 原型
        use_adapter: 是否使用 Adapter（TTA 必须）
        adapt_levels: 哪些层使用 Adapter，如 ("p2", "p3")
    """
    
    def __init__(self, 
                 encoder: nn.Module,
                 use_edge: bool = True,
                 use_cross_attn: bool = True,
                 use_token_proto: bool = False,
                 use_adapter: bool = True,
                 adapt_levels: Tuple[str, ...] = ("p2", "p3")):
        super().__init__()
        self.encoder = encoder
        self.use_cross_attn = use_cross_attn
        self.use_edge = use_edge
        self.use_token_proto = use_token_proto
        self.use_adapter = use_adapter
        
        # 原型和引导构建器
        self.proto_builder = ProtoBuilder(use_edge=use_edge, use_token=use_token_proto, token_grid=(3, 3))
        self.guide_builder = GuideBuilder(use_edge=use_edge, use_token_proto=use_token_proto, token_agg="max")
        
        # Cross-Attention Bridge (可选)
        if use_cross_attn:
            self.bridge = ProtoFormerBridge(dim=1024, num_heads=8, use_edge=use_edge, nfg=64, nbg=64, nedge=64)
        
        # Decoder with Adapter
        guide_ch = 2 if use_edge else 1
        feat_dims = encoder.feat_dims
        self.decoder = C2FDecoderWithAdapter(
            ch_c2=feat_dims['c2'],
            ch_c3=feat_dims['c3'],
            ch_c4=feat_dims['c4'],
            ch_c5=feat_dims['c5'],
            guide_ch=guide_ch,
            use_adapter=use_adapter,
            adapt_levels=adapt_levels
        )
    
    def forward(self, support_imgs: torch.Tensor, support_masks: torch.Tensor, 
                query_imgs: torch.Tensor) -> Tuple[torch.Tensor, Dict, Dict]:
        """
        前向传播
        
        Args:
            support_imgs: (K, 3, H, W) K-shot support 图像
            support_masks: (K, 1, H, W) float {0, 1} support masks
            query_imgs: (N, 3, H, W) query 图像，通常 N=1
        
        Returns:
            out: (N, 1, H, W) 最终预测 logits
            logits: dict 多尺度 logits {log2, log3, log4, log5}
            guides: dict 多尺度 guidance maps {g2, g3, g4, g5}
        """
        # 确保 support_masks 是 4D
        if support_masks.dim() == 3:
            support_masks = support_masks.unsqueeze(1)
        
        # 1) 编码 support & query
        s_feats = self.encoder(support_imgs)  # dict c2..c5
        q_feats = self.encoder(query_imgs)
        
        # 2) Cross-Attention 增强 c4 (可选)
        if self.use_cross_attn:
            q_feats = self._apply_cross_attention(q_feats, s_feats, support_masks)
        
        # 3) 构建原型
        protos = self.proto_builder(s_feats, support_masks)
        
        # 4) 生成 guidance maps
        guides = self.guide_builder(q_feats, protos)
        
        # 5) 解码
        logits = self.decoder(q_feats, guides)
        
        # 6) 上采样到原始分辨率
        out = F.interpolate(logits["log2"], size=query_imgs.shape[-2:], mode="bilinear", align_corners=False)
        
        return out, logits, guides
    
    def _apply_cross_attention(self, q_feats: Dict, s_feats: Dict, s_mask: torch.Tensor) -> Dict:
        """在 c4 层应用 Cross-Attention 增强"""
        q_c4_enhanced = self.bridge(
            q_c4=q_feats['c4'],
            s_c4=s_feats['c4'],
            s_mask=s_mask
        )
        return {
            'c2': q_feats['c2'],
            'c3': q_feats['c3'],
            'c4': q_c4_enhanced,
            'c5': q_feats['c5']
        }
    
    def get_tta_params(self, mode: str = "adapter_only") -> List[torch.nn.Parameter]:
        """
        获取 TTA 时需要更新的参数
        
        Args:
            mode:
                - "adapter_only": 只更新 decoder.adapter2/adapter3 (最稳定)
                - "adapter_plus_cross": adapter + bridge.cross 的投影层 (更强)
        
        Returns:
            参数列表
        """
        params = []
        
        if mode == "adapter_only":
            for n, p in self.named_parameters():
                if ("decoder.adapter2" in n) or ("decoder.adapter3" in n):
                    params.append(p)
        
        elif mode == "adapter_plus_cross":
            for n, p in self.named_parameters():
                if ("decoder.adapter2" in n) or ("decoder.adapter3" in n):
                    params.append(p)
                elif "bridge.cross" in n:
                    params.append(p)
        
        else:
            raise ValueError(f"Unknown mode: {mode}")
        
        return params
    
    def count_tta_params(self, mode: str = "adapter_only") -> int:
        """统计 TTA 参数量"""
        return sum(p.numel() for p in self.get_tta_params(mode))
    
    def freeze_for_tta(self, mode: str = "adapter_only"):
        """冻结除 TTA 参数外的所有参数"""
        for param in self.parameters():
            param.requires_grad = False
        for param in self.get_tta_params(mode):
            param.requires_grad = True


# ==================== BN 冻结工具函数 ====================

def freeze_bn(m: nn.Module):
    """
    冻结 BatchNorm 层的统计信息
    
    用于 episode 训练时，防止 support(K=5) 和 query(B=1) 混用时 BN 统计被搞乱
    
    用法:
        model.encoder.apply(freeze_bn)
    """
    if isinstance(m, (nn.BatchNorm2d, nn.BatchNorm1d, nn.SyncBatchNorm)):
        m.eval()


def freeze_encoder_bn(model: nn.Module):
    """
    冻结模型中 encoder 的所有 BN 层
    
    Args:
        model: FewShotCamouflageSeg 或 FS_CamoSeg_Model
    """
    if hasattr(model, 'encoder'):
        model.encoder.apply(freeze_bn)


# ==================== 独立 TTA 参数选择函数 (更新版) ====================

def get_tta_params_v2(model: nn.Module, mode: str = "adapter_only") -> List[torch.nn.Parameter]:
    """
    从模型中获取 TTA 参数（适配 FS_CamoSeg_Model 命名）
    
    Args:
        model: 模型实例
        mode:
            - "adapter_only": 只更新 decoder.adapter2/adapter3 (最稳定)
            - "adapter_plus_cross": adapter + bridge.cross (更强)
    
    Returns:
        参数列表
    """
    params = []
    
    if mode == "adapter_only":
        for n, p in model.named_parameters():
            if ("decoder.adapter2" in n) or ("decoder.adapter3" in n):
                params.append(p)
    
    elif mode == "adapter_plus_cross":
        for n, p in model.named_parameters():
            if ("decoder.adapter2" in n) or ("decoder.adapter3" in n):
                params.append(p)
            elif "bridge.cross" in n:
                params.append(p)
    
    else:
        raise ValueError(f"Unknown mode: {mode}")
    
    return params


# ==================== 创建推荐配置模型的工厂函数 ====================

def create_fscamo_model(
    backbone: str = 'resnet50',
    pretrained: bool = True,
    use_edge: bool = True,
    use_cross_attn: bool = True,
    use_token_proto: bool = False,
    use_adapter: bool = True,
    adapt_levels: Tuple[str, ...] = ("p2", "p3"),
    freeze_encoder_batchnorm: bool = True
) -> FS_CamoSeg_Model:
    """
    创建推荐配置的 FS_CamoSeg_Model
    
    默认使用最容易达到 >0.75 的配置：
    - use_edge=True
    - use_cross_attn=True
    - use_token_proto=False
    - use_adapter=True
    - adapt_levels=("p2", "p3")
    - freeze_encoder_batchnorm=True
    
    Args:
        backbone: 主干网络 ('resnet50', 'resnet101')
        pretrained: 是否使用预训练权重
        use_edge: 是否使用边界原型
        use_cross_attn: 是否使用 c4 Cross-Attention
        use_token_proto: 是否使用 Token 原型
        use_adapter: 是否使用 Adapter
        adapt_levels: 哪些层使用 Adapter
        freeze_encoder_batchnorm: 是否冻结 encoder 的 BN
    
    Returns:
        配置好的 FS_CamoSeg_Model
    """
    try:
        from .encoder_decoder import ResNetEncoder
    except ImportError:
        from encoder_decoder import ResNetEncoder
    
    encoder = ResNetEncoder(backbone=backbone, pretrained=pretrained)
    
    model = FS_CamoSeg_Model(
        encoder=encoder,
        use_edge=use_edge,
        use_cross_attn=use_cross_attn,
        use_token_proto=use_token_proto,
        use_adapter=use_adapter,
        adapt_levels=adapt_levels
    )
    
    if freeze_encoder_batchnorm:
        freeze_encoder_bn(model)
    
    return model


# ==================== 测试代码 ====================

if __name__ == "__main__":
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")
    
    # 模拟输入
    K = 5  # 5-shot
    B = 1  # batch size
    H, W = 512, 512
    
    support_imgs = torch.randn(K, 3, H, W).to(device)
    support_masks = (torch.randn(K, 1, H, W) > 0).float().to(device)
    query_img = torch.randn(B, 3, H, W).to(device)
    
    # 测试完整版模型
    print("\n" + "="*60)
    print("测试 FewShotCamouflageSeg (完整版)")
    print("="*60)
    
    model = FewShotCamouflageSeg(
        backbone='resnet50',
        pretrained=False,
        use_edge=True,
        use_token=True,
        token_grid=(3, 3)
    ).to(device)
    
    with torch.no_grad():
        out, logits, guides = model(support_imgs, support_masks, query_img)
    
    print(f"输入:")
    print(f"  support_imgs: {support_imgs.shape}")
    print(f"  support_masks: {support_masks.shape}")
    print(f"  query_img: {query_img.shape}")
    
    print(f"\n输出:")
    print(f"  out (final logits): {out.shape}")
    print(f"  多尺度 logits:")
    for k, v in logits.items():
        print(f"    {k}: {v.shape}")
    print(f"  guidance maps:")
    for k, v in guides.items():
        print(f"    {k}: {v.shape}")
    
    # 测试轻量版
    print("\n" + "="*60)
    print("测试 FewShotCamouflageSeg_Lite")
    print("="*60)
    
    model_lite = FewShotCamouflageSeg_Lite(
        backbone='resnet50',
        pretrained=False
    ).to(device)
    
    with torch.no_grad():
        out_lite, _, guides_lite = model_lite(support_imgs, support_masks, query_img)
    
    print(f"Lite 版 guidance channels: {guides_lite['g2'].shape[1]}")  # 应该是 1
    
    # 测试 Cross-Attention 版本
    print("\n" + "="*60)
    print("测试 FewShotCamouflageSeg_CrossAttn")
    print("="*60)
    
    model_crossattn = FewShotCamouflageSeg_CrossAttn(
        backbone='resnet50',
        pretrained=False,
        use_adapter=True,
        cross_attn_num_heads=8,
        cross_attn_nfg=64,
        cross_attn_nbg=64,
        cross_attn_nedge=64
    ).to(device)
    
    with torch.no_grad():
        out_ca, logits_ca, guides_ca = model_crossattn(support_imgs, support_masks, query_img)
    
    print(f"Cross-Attention 版输出: {out_ca.shape}")
    
    # 测试带 Adapter 的模型
    print("\n" + "="*60)
    print("测试 Adapter 功能")
    print("="*60)
    
    model_adapter = FewShotCamouflageSeg(
        backbone='resnet50',
        pretrained=False,
        use_adapter=True,
        adapter_reduction=16
    ).to(device)
    
    # 获取 TTA 参数
    tta_params = model_adapter.get_tta_params(mode="adapter")
    tta_param_count = sum(p.numel() for p in tta_params)
    print(f"Adapter 参数量: {tta_param_count:,}")
    
    # 测试冻结功能
    model_adapter.freeze_all_except_adapter()
    trainable_count = sum(p.numel() for p in model_adapter.parameters() if p.requires_grad)
    print(f"冻结后可训练参数量: {trainable_count:,} (应该等于 Adapter 参数量)")
    
    # 统计参数量
    print("\n" + "="*60)
    print("参数量统计")
    print("="*60)
    
    total_params = sum(p.numel() for p in model.parameters())
    print(f"完整版参数量: {total_params/1e6:.2f}M")
    
    total_params_lite = sum(p.numel() for p in model_lite.parameters())
    print(f"轻量版参数量: {total_params_lite/1e6:.2f}M")
    
    total_params_ca = sum(p.numel() for p in model_crossattn.parameters())
    cross_attn_params = sum(p.numel() for p in model_crossattn.get_cross_attn_params())
    print(f"Cross-Attention 版参数量: {total_params_ca/1e6:.2f}M (Cross-Attn: {cross_attn_params:,})")
    
    # 测试 ProtoFormer TTA 版本 (最终冲榜版)
    print("\n" + "="*60)
    print("测试 FewShotCamouflageSeg_ProtoFormerTTA (最终版)")
    print("="*60)
    
    model_tta = FewShotCamouflageSeg_ProtoFormerTTA(
        backbone='resnet50',
        pretrained=False,
        # 原型配置
        use_edge=True,
        use_token_proto=True,
        token_grid=(3, 3),
        # Cross-Attention 配置
        use_cross_attn=True,
        cross_dim=1024,
        cross_num_heads=8,
        cross_nfg=64,
        cross_nbg=64,
        cross_nedge=64,
        cross_res_scale=0.1,
        # Adapter 配置 (TTA)
        use_adapter=True,
        adapt_levels=("p2", "p3"),
        adapter_reduction=16,
        # Decoder 配置
        mid_ch=256,
        edge_kernel=7
    ).to(device)
    
    with torch.no_grad():
        out_tta, logits_tta, guides_tta = model_tta(support_imgs, support_masks, query_img)
    
    print(f"\nProtoFormerTTA 输出: {out_tta.shape}")
    
    # 测试不同 TTA 模式的参数
    print("\nTTA 参数统计:")
    for mode in ["adapter_only", "adapter_plus_cross", "adapter_plus_head", "full"]:
        count = model_tta.count_tta_params(mode)
        print(f"  {mode}: {count:,} 参数")
    
    # 测试冻结功能
    print("\n测试 TTA 冻结功能:")
    model_tta.freeze_for_tta(mode="adapter_only")
    trainable = sum(p.numel() for p in model_tta.parameters() if p.requires_grad)
    adapter_params = model_tta.count_tta_params("adapter_only")
    print(f"  冻结后可训练: {trainable:,}")
    print(f"  Adapter 参数量: {adapter_params:,}")
    print(f"  匹配: {'Yes' if trainable == adapter_params else 'No'}")
    
    # 统计总参数量
    total_params_tta = sum(p.numel() for p in model_tta.parameters())
    bridge_params = sum(p.numel() for p in model_tta.get_bridge_params())
    decoder_params = sum(p.numel() for p in model_tta.get_decoder_params())
    encoder_params = sum(p.numel() for p in model_tta.get_encoder_params())
    
    print(f"\nProtoFormerTTA 参数分布:")
    print(f"  总参数: {total_params_tta/1e6:.2f}M")
    print(f"  Encoder: {encoder_params/1e6:.2f}M")
    print(f"  Bridge: {bridge_params:,}")
    print(f"  Decoder: {decoder_params:,}")
    
    # 测试独立的 get_tta_params 函数
    print("\n测试独立的 get_tta_params 函数:")
    params_adapter = get_tta_params(model_tta, mode="adapter_only")
    params_cross = get_tta_params(model_tta, mode="adapter_plus_cross")
    print(f"  adapter_only: {sum(p.numel() for p in params_adapter):,}")
    print(f"  adapter_plus_cross: {sum(p.numel() for p in params_cross):,}")
    
    print("\n" + "="*60)
    print("所有模型测试通过!")
    print("="*60)
    print("\n推荐配置 (跟榜用):")
    print("  - Cross-attn 放在 c4 (1/16, C=1024)")
    print("  - Memory token 数: FG=64, BG=64, Edge=64 (总 192)")
    print("  - heads=8, res_scale=0.1")
    print("  - TTA: steps=10, lr=1e-3, prox_lambda=1e-4")
    print("  - TTA 更新: 默认只更新 adapter2/adapter3")
    print("  - 冲更高再试 adapter_plus_cross (steps 减到 5~10)")
    
    # ==================== 测试简洁版 FS_CamoSeg_Model ====================
    print("\n" + "="*60)
    print("测试 FS_CamoSeg_Model (简洁版)")
    print("="*60)
    
    # 使用工厂函数创建推荐配置模型
    model_simple = create_fscamo_model(
        backbone='resnet50',
        pretrained=False,
        use_edge=True,
        use_cross_attn=True,
        use_token_proto=False,  # 先别开，降风险
        use_adapter=True,
        adapt_levels=("p2", "p3"),
        freeze_encoder_batchnorm=True
    ).to(device)
    
    with torch.no_grad():
        out_simple, logits_simple, guides_simple = model_simple(support_imgs, support_masks, query_img)
    
    print(f"\nFS_CamoSeg_Model 输出:")
    print(f"  out: {out_simple.shape}")
    print(f"  log2: {logits_simple['log2'].shape}")
    print(f"  g2: {guides_simple['g2'].shape}")
    
    # 测试 TTA 参数
    print("\nFS_CamoSeg_Model TTA 参数:")
    for mode in ["adapter_only", "adapter_plus_cross"]:
        count = model_simple.count_tta_params(mode)
        print(f"  {mode}: {count:,} 参数")
    
    # 测试 BN 冻结
    bn_training_count = sum(1 for m in model_simple.encoder.modules() 
                           if isinstance(m, nn.BatchNorm2d) and m.training)
    print(f"\nEncoder BN 层状态: {bn_training_count} 个在训练模式 (应该为 0)")
    
    # 测试独立函数
    params_v2 = get_tta_params_v2(model_simple, mode="adapter_only")
    print(f"\nget_tta_params_v2 adapter_only: {sum(p.numel() for p in params_v2):,} 参数")
    
    # 统计参数量
    total_simple = sum(p.numel() for p in model_simple.parameters())
    print(f"\nFS_CamoSeg_Model 总参数: {total_simple/1e6:.2f}M")
    
    print("\n" + "="*60)
    print("FS_CamoSeg_Model 测试通过!")
    print("="*60)
