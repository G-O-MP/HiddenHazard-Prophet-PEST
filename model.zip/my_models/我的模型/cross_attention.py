# -*- coding: utf-8 -*-
"""
Cross-Attention + DyT 模块

核心组件:
1. DyT (Dynamic Tanh): 替代 LayerNorm 的轻量归一化
2. Token 采样: 从 support 特征中采样 FG/BG/Edge tokens
3. Memory 构造: K-shot 聚合 + 类型 embedding
4. CrossAttentionDyT: 带 DyT 的 Cross-Attention block
5. ProtoFormerBridge: 在 c4 层做 support→query cross-attention 增强

设计原则:
- 放在 c4 (1/16 分辨率) 最合适：语义足够 + token 数可控
- DyT 替代 LN: 参数少、推理快、效果相当
- 类型 Embedding: 让 attention 区分 FG/BG/Edge

默认超参:
- nfg=64, nbg=64, nedge=64 (总 memory token M=192)
- num_heads=8
- res_scale=0.1 (残差缩放，稳定训练)
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

try:
    from .modules import make_edge_mask
except ImportError:
    from modules import make_edge_mask


# ==================== DyT (Dynamic Tanh) ====================

class DyT(nn.Module):
    """
    Dynamic Tanh - 替代 LayerNorm 的轻量归一化
    
    公式: y = tanh(alpha * x) * weight + bias
    
    特点:
    - 无需计算均值/方差，推理更快
    - alpha 可学习，控制非线性强度
    - 参数量与 LayerNorm 相当
    
    Args:
        num_features: 特征维度
        alpha_init_value: alpha 初始值（控制 tanh 饱和程度）
    """
    def __init__(self, num_features: int, alpha_init_value: float = 0.5):
        super().__init__()
        self.alpha = nn.Parameter(torch.ones(1) * alpha_init_value)
        self.weight = nn.Parameter(torch.ones(num_features))
        self.bias = nn.Parameter(torch.zeros(num_features))
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: (B, N, C) 或 (B, C, H, W)
        Returns:
            normalized tensor with same shape
        """
        x = torch.tanh(self.alpha * x)
        return x * self.weight + self.bias


# ==================== Token 采样 ====================

def sample_tokens(feat: torch.Tensor, mask: torch.Tensor, num_tokens: int) -> torch.Tensor:
    """
    从特征图中按 mask 采样固定数量的 tokens
    
    Args:
        feat: (B, C, h, w) 特征图 (B=K-shot 或合并后的 support batch)
        mask: (B, 1, h, w) float {0, 1} 采样区域
        num_tokens: 每张图采样的 token 数量
    
    Returns:
        tokens: (B, num_tokens, C) 采样的 tokens
    """
    B, C, h, w = feat.shape
    mask = mask.squeeze(1)  # (B, h, w)
    
    tokens_out = []
    for b in range(B):
        # 找到 mask 区域的像素索引
        idx = (mask[b] > 0.5).nonzero(as_tuple=False)  # (T, 2) [y, x]
        
        if idx.shape[0] == 0:
            # 无 token：返回零向量（极少发生，防崩溃）
            tokens = feat.new_zeros((num_tokens, C))
        else:
            # 采样 num_tokens 个位置
            if idx.shape[0] >= num_tokens:
                # 随机采样
                perm = torch.randperm(idx.shape[0], device=feat.device)[:num_tokens]
                sel = idx[perm]
            else:
                # 不足则重复采样补齐
                rep_idx = torch.randint(0, idx.shape[0], (num_tokens,), device=feat.device)
                sel = idx[rep_idx]
            
            # 从特征图 gather tokens
            y, x = sel[:, 0], sel[:, 1]
            tokens = feat[b, :, y, x].transpose(0, 1)  # (num_tokens, C)
        
        tokens_out.append(tokens)
    
    return torch.stack(tokens_out, dim=0)  # (B, num_tokens, C)


# ==================== Memory 构造 ====================

def build_support_memory(
    s_feat_c4: torch.Tensor,
    s_mask: torch.Tensor,
    use_edge: bool = True,
    nfg: int = 64,
    nbg: int = 64,
    nedge: int = 64,
    edge_kernel: int = 7
) -> torch.Tensor:
    """
    从 K-shot support 构建 memory tokens
    
    策略: 
    - 每张 support 各采样固定数量的 FG/BG/Edge tokens
    - 在 shot 维度上求平均，得到最终 memory
    
    Args:
        s_feat_c4: (K, C, h, w) support 的 c4 层特征
        s_mask: (K, 1, H, W) support 原始分辨率 mask（会 resize 到 c4 尺寸）
        use_edge: 是否使用边界 tokens
        nfg: 前景 token 数量
        nbg: 背景 token 数量
        nedge: 边界 token 数量（仅 use_edge=True 时有效）
        edge_kernel: 边界 mask 构造的卷积核大小
    
    Returns:
        memory: (1, M, C) 其中 M = nfg + nbg (+ nedge if use_edge)
    """
    K, C, h, w = s_feat_c4.shape
    
    # resize mask 到特征图尺寸
    m = F.interpolate(s_mask.float(), size=(h, w), mode="nearest")  # (K, 1, h, w)
    
    # 采样 FG tokens
    fg_tokens = sample_tokens(s_feat_c4, m, nfg)  # (K, nfg, C)
    
    # 采样 BG tokens
    bg_tokens = sample_tokens(s_feat_c4, 1.0 - m, nbg)  # (K, nbg, C)
    
    # 采样 Edge tokens (可选)
    if use_edge:
        edge = make_edge_mask(s_mask.float(), k=edge_kernel)
        edge = F.interpolate(edge, size=(h, w), mode="nearest")
        ed_tokens = sample_tokens(s_feat_c4, edge, nedge)  # (K, nedge, C)
    
    # Shot 聚合：对 K 个 shot 求平均 -> (1, n, C)
    fg = fg_tokens.mean(dim=0, keepdim=True)  # (1, nfg, C)
    bg = bg_tokens.mean(dim=0, keepdim=True)  # (1, nbg, C)
    
    if use_edge:
        ed = ed_tokens.mean(dim=0, keepdim=True)  # (1, nedge, C)
        mem = torch.cat([fg, bg, ed], dim=1)  # (1, M, C)
    else:
        mem = torch.cat([fg, bg], dim=1)  # (1, M, C)
    
    return mem


# ==================== Type Embedding ====================

class TypeEmbedding(nn.Module):
    """
    类型 Embedding：区分 FG/BG/Edge tokens
    
    让 Cross-Attention 学到 "这段 memory 是前景还是背景还是边界"
    
    Args:
        dim: embedding 维度（与特征通道数一致）
        n_types: 类型数量（默认 3: FG=0, BG=1, Edge=2）
    """
    def __init__(self, dim: int, n_types: int = 3):
        super().__init__()
        self.emb = nn.Embedding(n_types, dim)
    
    def forward(self, nfg: int, nbg: int, nedge: int = 0) -> torch.Tensor:
        """
        Args:
            nfg: 前景 token 数量
            nbg: 背景 token 数量
            nedge: 边界 token 数量
        
        Returns:
            type_emb: (1, M, dim) 类型 embedding
        """
        # 构造类型 ID 序列
        ids = []
        ids += [0] * nfg   # FG type
        ids += [1] * nbg   # BG type
        if nedge > 0:
            ids += [2] * nedge  # Edge type
        
        ids = torch.tensor(ids, device=self.emb.weight.device).unsqueeze(0)  # (1, M)
        return self.emb(ids)  # (1, M, dim)


# ==================== Cross-Attention + DyT ====================

class CrossAttentionDyT(nn.Module):
    """
    带 DyT 的 Cross-Attention Block
    
    结构:
    1. Pre-norm (DyT) + Cross-Attention + Residual
    2. Pre-norm (DyT) + MLP + Residual
    
    用于 support memory → query features 的信息传递
    
    Args:
        dim: 特征维度
        num_heads: 注意力头数
        mlp_ratio: MLP 隐层扩展比例
        drop: dropout 概率（暂未使用）
        res_scale: 残差缩放因子（稳定训练）
    """
    def __init__(
        self,
        dim: int,
        num_heads: int = 8,
        mlp_ratio: float = 4.0,
        drop: float = 0.0,
        res_scale: float = 0.1
    ):
        super().__init__()
        self.dim = dim
        self.h = num_heads
        self.dh = dim // num_heads
        assert dim % num_heads == 0, f"dim {dim} must be divisible by num_heads {num_heads}"
        
        # Pre-norm for attention
        self.pret = DyT(dim)
        
        # Q/K/V projections
        self.q_proj = nn.Linear(dim, dim, bias=False)
        self.k_proj = nn.Linear(dim, dim, bias=False)
        self.v_proj = nn.Linear(dim, dim, bias=False)
        self.out_proj = nn.Linear(dim, dim, bias=False)
        
        # Pre-norm for MLP
        self.pret2 = DyT(dim)
        
        # MLP
        hidden = int(dim * mlp_ratio)
        self.mlp = nn.Sequential(
            nn.Linear(dim, hidden),
            nn.GELU(),
            nn.Linear(hidden, dim),
        )
        
        self.res_scale = res_scale
        
        # 初始化：让初始输出接近恒等
        nn.init.zeros_(self.out_proj.weight)
        nn.init.zeros_(self.mlp[-1].weight)
        nn.init.zeros_(self.mlp[-1].bias)
    
    def forward(self, q: torch.Tensor, mem: torch.Tensor) -> torch.Tensor:
        """
        Cross-Attention: Query 从 Memory 中提取信息
        
        Args:
            q: (B, Nq, C) query tokens
            mem: (B, Nm, C) memory tokens (support)
        
        Returns:
            enhanced query: (B, Nq, C)
        """
        x = q
        
        # === Cross-Attention ===
        qn = self.pret(q)   # pre-norm query
        mn = self.pret(mem) # pre-norm memory
        
        Q = self.q_proj(qn)
        K = self.k_proj(mn)
        V = self.v_proj(mn)
        
        B, Nq, C = Q.shape
        Nm = K.shape[1]
        
        # Reshape to multi-head format
        Q = Q.view(B, Nq, self.h, self.dh).transpose(1, 2)  # (B, h, Nq, dh)
        K = K.view(B, Nm, self.h, self.dh).transpose(1, 2)  # (B, h, Nm, dh)
        V = V.view(B, Nm, self.h, self.dh).transpose(1, 2)  # (B, h, Nm, dh)
        
        # Scaled dot-product attention
        scale = self.dh ** -0.5
        attn = (Q @ K.transpose(-2, -1)) * scale  # (B, h, Nq, Nm)
        attn = attn.softmax(dim=-1)
        
        out = attn @ V  # (B, h, Nq, dh)
        out = out.transpose(1, 2).contiguous().view(B, Nq, C)  # (B, Nq, C)
        out = self.out_proj(out)
        
        # Residual with scaling
        x = x + self.res_scale * out
        
        # === MLP ===
        y = self.pret2(x)
        y = self.mlp(y)
        x = x + self.res_scale * y
        
        return x


# ==================== ProtoFormer Bridge ====================

class ProtoFormerBridge(nn.Module):
    """
    ProtoFormer Bridge - 在 c4 层做 Support→Query Cross-Attention 增强
    
    核心思路:
    - 从 support 的 c4 特征中采样 FG/BG/Edge tokens 作为 memory
    - 用 Cross-Attention 让 query 的 c4 特征从 memory 中学习
    - 增强后的 q_c4 送入 decoder 的 p4 分支
    
    为什么放在 c4:
    - c5 太粗：边界信息不足
    - c3 太细：token 数多，显存爆炸
    - c4 折中：有语义 + 有细节 + token 数可控
    
    Args:
        dim: 特征维度（c4 通道数，ResNet50 为 1024）
        num_heads: 注意力头数
        use_edge: 是否使用边界 tokens
        nfg: 前景 token 数量
        nbg: 背景 token 数量
        nedge: 边界 token 数量
        edge_kernel: 边界 mask 卷积核大小
        mlp_ratio: MLP 隐层扩展比例
        res_scale: 残差缩放因子
    """
    def __init__(
        self,
        dim: int = 1024,
        num_heads: int = 8,
        use_edge: bool = True,
        nfg: int = 64,
        nbg: int = 64,
        nedge: int = 64,
        edge_kernel: int = 7,
        mlp_ratio: float = 4.0,
        res_scale: float = 0.1
    ):
        super().__init__()
        self.use_edge = use_edge
        self.nfg = nfg
        self.nbg = nbg
        self.nedge = nedge if use_edge else 0
        self.edge_kernel = edge_kernel
        
        # Type embedding
        self.type_emb = TypeEmbedding(dim, n_types=3)
        
        # Cross-Attention block
        self.cross = CrossAttentionDyT(
            dim=dim,
            num_heads=num_heads,
            mlp_ratio=mlp_ratio,
            res_scale=res_scale
        )
    
    def forward(
        self,
        q_c4: torch.Tensor,
        s_c4: torch.Tensor,
        s_mask: torch.Tensor
    ) -> torch.Tensor:
        """
        Args:
            q_c4: (B, C, h, w) query 的 c4 特征，通常 B=1
            s_c4: (K, C, h, w) support 的 c4 特征
            s_mask: (K, 1, H, W) support 的原始分辨率 mask
        
        Returns:
            q_c4_enhanced: (B, C, h, w) 增强后的 query c4 特征
        """
        B, C, h, w = q_c4.shape
        
        # 1) 构建 support memory: (1, M, C)
        mem = build_support_memory(
            s_c4, s_mask,
            use_edge=self.use_edge,
            nfg=self.nfg,
            nbg=self.nbg,
            nedge=self.nedge,
            edge_kernel=self.edge_kernel
        )
        
        # 2) 添加类型 embedding: (1, M, C)
        mem = mem + self.type_emb(self.nfg, self.nbg, self.nedge)
        
        # 3) 展平 query tokens: (B, Nq, C) where Nq = h * w
        q = q_c4.flatten(2).transpose(1, 2)  # (B, h*w, C)
        
        # 4) Cross-Attention: query 从 memory 中学习
        # 扩展 memory 到 batch 维度
        mem_expanded = mem.expand(B, -1, -1)  # (B, M, C)
        q2 = self.cross(q, mem_expanded)  # (B, Nq, C)
        
        # 5) Reshape 回空间维度
        out = q2.transpose(1, 2).reshape(B, C, h, w)  # (B, C, h, w)
        
        return out


# ==================== 测试代码 ====================

if __name__ == "__main__":
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Testing on device: {device}")
    
    # 模拟参数
    K = 5       # 5-shot
    B = 1       # query batch
    C = 1024    # c4 通道数
    h, w = 32, 32  # c4 分辨率 (假设输入 512x512)
    H, W = 512, 512  # 原始分辨率
    
    # 1. 测试 DyT
    print("\n1. Testing DyT...")
    dyt = DyT(C).to(device)
    x = torch.randn(B, h*w, C).to(device)
    y = dyt(x)
    print(f"   Input: {x.shape} -> Output: {y.shape}")
    
    # 2. 测试 sample_tokens
    print("\n2. Testing sample_tokens...")
    feat = torch.randn(K, C, h, w).to(device)
    mask = (torch.randn(K, 1, h, w) > 0).float().to(device)
    tokens = sample_tokens(feat, mask, num_tokens=64)
    print(f"   Feat: {feat.shape}, Mask: {mask.shape} -> Tokens: {tokens.shape}")
    
    # 3. 测试 build_support_memory
    print("\n3. Testing build_support_memory...")
    s_feat = torch.randn(K, C, h, w).to(device)
    s_mask = (torch.randn(K, 1, H, W) > 0).float().to(device)
    mem = build_support_memory(s_feat, s_mask, use_edge=True, nfg=64, nbg=64, nedge=64)
    print(f"   S_feat: {s_feat.shape}, S_mask: {s_mask.shape} -> Memory: {mem.shape}")
    
    # 4. 测试 TypeEmbedding
    print("\n4. Testing TypeEmbedding...")
    type_emb = TypeEmbedding(C).to(device)
    emb = type_emb(nfg=64, nbg=64, nedge=64)
    print(f"   Type embedding: {emb.shape}")
    
    # 5. 测试 CrossAttentionDyT
    print("\n5. Testing CrossAttentionDyT...")
    cross = CrossAttentionDyT(dim=C, num_heads=8).to(device)
    q = torch.randn(B, h*w, C).to(device)
    mem_test = torch.randn(B, 192, C).to(device)  # 64+64+64
    out = cross(q, mem_test)
    print(f"   Q: {q.shape}, Mem: {mem_test.shape} -> Out: {out.shape}")
    
    # 6. 测试 ProtoFormerBridge (完整流程)
    print("\n6. Testing ProtoFormerBridge...")
    bridge = ProtoFormerBridge(
        dim=C,
        num_heads=8,
        use_edge=True,
        nfg=64, nbg=64, nedge=64
    ).to(device)
    
    q_c4 = torch.randn(B, C, h, w).to(device)
    s_c4 = torch.randn(K, C, h, w).to(device)
    s_mask = (torch.randn(K, 1, H, W) > 0).float().to(device)
    
    q_c4_enhanced = bridge(q_c4, s_c4, s_mask)
    print(f"   Q_c4: {q_c4.shape}, S_c4: {s_c4.shape}, S_mask: {s_mask.shape}")
    print(f"   -> Q_c4_enhanced: {q_c4_enhanced.shape}")
    
    # 检查 residual 初始化是否接近恒等
    diff = (q_c4_enhanced - q_c4).abs().mean().item()
    print(f"   Initial diff from input: {diff:.6f} (should be small due to res_scale)")
    
    # 计算参数量
    num_params = sum(p.numel() for p in bridge.parameters())
    print(f"   ProtoFormerBridge params: {num_params:,}")
    
    print("\n所有 Cross-Attention 模块测试通过!")
