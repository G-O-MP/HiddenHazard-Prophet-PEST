# -*- coding: utf-8 -*-
"""
FewShotCamouflageSeg with Classification - 带分类能力的小样本伪装目标分割模型

核心改进：
1. 在分割基础上添加分类头，实现分割+分类统一输出
2. 输出格式：类别、位置框、置信度
3. 支持多类别虫害检测

用于实验5.2/5.3/5.4
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, Tuple, Optional, List
import math

try:
    from .modules import MaskedAvgPool, ProtoMatcher, TokenProtoBuilder, make_edge_mask, ProtoBuilder, GuideBuilder
    from .encoder_decoder import ResNetEncoder, C2FDecoder, C2FDecoderWithAdapter
    from .cross_attention import ProtoFormerBridge
except ImportError:
    from modules import MaskedAvgPool, ProtoMatcher, TokenProtoBuilder, make_edge_mask, ProtoBuilder, GuideBuilder
    from encoder_decoder import ResNetEncoder, C2FDecoder, C2FDecoderWithAdapter
    from cross_attention import ProtoFormerBridge


class ClassificationHead(nn.Module):
    """
    分类头：从分割特征中提取类别信息
    
    使用全局平均池化 + MLP进行分类
    """
    def __init__(self, in_channels: int, num_classes: int, hidden_dim: int = 512):
        super().__init__()
        self.num_classes = num_classes
        
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(in_channels, hidden_dim),
            nn.ReLU(inplace=True),
            nn.Dropout(0.3),
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(inplace=True),
            nn.Dropout(0.3),
            nn.Linear(hidden_dim // 2, num_classes)
        )
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: (B, C, H, W) 特征图
        
        Returns:
            logits: (B, num_classes) 分类logits
        """
        x = self.pool(x)  # (B, C, 1, 1)
        x = x.view(x.size(0), -1)  # (B, C)
        logits = self.fc(x)  # (B, num_classes)
        return logits


class BoundingBoxHead(nn.Module):
    """
    边界框回归头：从分割mask预测边界框
    
    输入：分割概率图
    输出：边界框 [x_center, y_center, width, height] (归一化)
    """
    def __init__(self, hidden_dim: int = 256):
        super().__init__()
        
        self.conv = nn.Sequential(
            nn.Conv2d(1, 32, 3, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=True),
            nn.Conv2d(32, 64, 3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.AdaptiveAvgPool2d(1)
        )
        
        self.fc = nn.Sequential(
            nn.Linear(64, hidden_dim),
            nn.ReLU(inplace=True),
            nn.Linear(hidden_dim, 4)  # x, y, w, h
        )
        
        self._init_weights()
    
    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)
            elif isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
    
    def forward(self, mask_prob: torch.Tensor) -> torch.Tensor:
        """
        Args:
            mask_prob: (B, 1, H, W) 分割概率图
        
        Returns:
            bbox: (B, 4) 归一化边界框 [cx, cy, w, h]
        """
        x = self.conv(mask_prob)  # (B, 64, 1, 1)
        x = x.view(x.size(0), -1)  # (B, 64)
        bbox = self.fc(x)  # (B, 4)
        bbox = torch.sigmoid(bbox)  # 归一化到 [0, 1]
        return bbox


class FewShotCamouflageSegWithClass(nn.Module):
    """
    带分类能力的小样本伪装目标分割模型
    
    输出：
    - 分割mask
    - 类别预测
    - 边界框
    - 置信度
    
    用于实验5.2/5.3/5.4
    """
    
    def __init__(self, 
                 backbone: str = 'resnet50',
                 pretrained: bool = True,
                 num_classes: int = 102,  # IP02数据集有102类
                 use_edge: bool = True, 
                 use_token: bool = True, 
                 token_grid: Tuple[int, int] = (3, 3),
                 mid_ch: int = 256,
                 edge_kernel: int = 7,
                 use_adapter: bool = False,
                 adapter_reduction: int = 16,
                 use_cross_attn: bool = True,
                 cross_attn_num_heads: int = 8,
                 cross_attn_nfg: int = 64,
                 cross_attn_nbg: int = 64,
                 cross_attn_nedge: int = 64,
                 cross_attn_mlp_ratio: float = 4.0,
                 cross_attn_res_scale: float = 0.1):
        super().__init__()
        
        self.num_classes = num_classes
        self.use_edge = use_edge
        self.use_token = use_token
        self.edge_kernel = edge_kernel
        self.use_adapter = use_adapter
        self.use_cross_attn = use_cross_attn
        
        self.encoder = ResNetEncoder(backbone=backbone, pretrained=pretrained)
        feat_dims = self.encoder.feat_dims
        
        self.pool = MaskedAvgPool()
        self.match = ProtoMatcher()
        
        if use_token:
            self.token_builder = TokenProtoBuilder(*token_grid)
        
        if use_cross_attn:
            self.cross_attn_bridge = ProtoFormerBridge(
                dim=feat_dims['c4'],
                num_heads=cross_attn_num_heads,
                use_edge=use_edge,
                nfg=cross_attn_nfg,
                nbg=cross_attn_nbg,
                nedge=cross_attn_nedge,
                edge_kernel=edge_kernel,
                mlp_ratio=cross_attn_mlp_ratio,
                res_scale=cross_attn_res_scale
            )
        
        guide_ch = 2 if use_edge else 1
        
        self.decoder = C2FDecoder(
            ch_c2=feat_dims['c2'],
            ch_c3=feat_dims['c3'],
            ch_c4=feat_dims['c4'],
            ch_c5=feat_dims['c5'],
            guide_ch=guide_ch,
            mid=mid_ch,
            use_adapter=use_adapter,
            adapter_reduction=adapter_reduction
        )
        
        self.class_head = ClassificationHead(feat_dims['c4'], num_classes)
        self.bbox_head = BoundingBoxHead()
        
        self.confidence_fc = nn.Sequential(
            nn.Linear(1, 32),
            nn.ReLU(inplace=True),
            nn.Linear(32, 1),
            nn.Sigmoid()
        )

    def build_protos(self, support_feats, support_mask):
        protos = {}
        M = support_mask
        
        if self.use_edge:
            M_edge = make_edge_mask(M, k=self.edge_kernel)
        
        for lvl in ["c2", "c3", "c4", "c5"]:
            Fs = support_feats[lvl]
            
            p_fg = self.pool(Fs, M)
            p_bg = self.pool(Fs, 1.0 - M)
            
            p_fg = p_fg.mean(dim=0, keepdim=True)
            p_bg = p_bg.mean(dim=0, keepdim=True)
            
            protos[lvl] = {"p_fg": p_fg, "p_bg": p_bg}
            
            if self.use_edge:
                p_edge = self.pool(Fs, M_edge).mean(dim=0, keepdim=True)
                protos[lvl]["p_edge"] = p_edge
            
            if self.use_token:
                tokens_fg = self.token_builder(Fs, M)
                tokens_bg = self.token_builder(Fs, 1.0 - M)
                protos[lvl]["t_fg"] = tokens_fg.mean(dim=0, keepdim=True)
                protos[lvl]["t_bg"] = tokens_bg.mean(dim=0, keepdim=True)
        
        return protos

    def build_guides(self, query_feats, protos):
        guides = {}
        lvl_to_gname = {"c2": "g2", "c3": "g3", "c4": "g4", "c5": "g5"}
        
        for lvl, gname in lvl_to_gname.items():
            Fq = query_feats[lvl]
            
            if self.use_token:
                sim_fg = self.match(Fq, protos[lvl]["t_fg"], aggregate="max")
                sim_bg = self.match(Fq, protos[lvl]["t_bg"], aggregate="max")
            else:
                sim_fg = self.match(Fq, protos[lvl]["p_fg"])
                sim_bg = self.match(Fq, protos[lvl]["p_bg"])
            
            s_diff = sim_fg - sim_bg
            
            if self.use_edge:
                sim_edge = self.match(Fq, protos[lvl]["p_edge"])
                guides[gname] = torch.cat([s_diff, sim_edge], dim=1)
            else:
                guides[gname] = s_diff
        
        return guides

    def forward(self, support_imgs, support_masks, query_img, class_label=None):
        """
        前向传播
        
        Args:
            support_imgs: (K, 3, H, W) K-shot support 图像
            support_masks: (K, 1, H, W) float {0, 1} support masks
            query_img: (B, 3, H, W) query 图像
            class_label: (B,) 类别标签（训练时使用）
        
        Returns:
            dict: {
                'seg_logits': (B, 1, H, W) 分割logits,
                'seg_prob': (B, 1, H, W) 分割概率,
                'class_logits': (B, num_classes) 分类logits,
                'class_prob': (B, num_classes) 分类概率,
                'bbox': (B, 4) 边界框 [cx, cy, w, h],
                'confidence': (B, 1) 置信度,
                'logits': dict 多尺度logits,
                'guides': dict 多尺度guides
            }
        """
        if support_masks.dim() == 3:
            support_masks = support_masks.unsqueeze(1)
        
        s_feats = self.encoder(support_imgs)
        q_feats = self.encoder(query_img)
        
        if self.use_cross_attn:
            q_feats = self._apply_cross_attention(q_feats, s_feats, support_masks)
        
        protos = self.build_protos(s_feats, support_masks)
        guides = self.build_guides(q_feats, protos)
        
        logits = self.decoder(q_feats, guides)
        
        seg_logits = F.interpolate(
            logits["log2"], 
            size=query_img.shape[-2:], 
            mode="bilinear", 
            align_corners=False
        )
        
        seg_prob = torch.sigmoid(seg_logits)
        
        class_logits = self.class_head(q_feats['c4'])
        class_prob = F.softmax(class_logits, dim=-1)
        
        bbox = self.bbox_head(seg_prob)
        
        max_class_prob = class_prob.max(dim=-1, keepdim=True)[0]
        confidence = self.confidence_fc(max_class_prob)
        
        return {
            'seg_logits': seg_logits,
            'seg_prob': seg_prob,
            'class_logits': class_logits,
            'class_prob': class_prob,
            'bbox': bbox,
            'confidence': confidence,
            'logits': logits,
            'guides': guides
        }
    
    def _apply_cross_attention(self, q_feats: Dict, s_feats: Dict, s_mask: torch.Tensor) -> Dict:
        q_c4_enhanced = self.cross_attn_bridge(
            q_c4=q_feats['c4'],
            s_c4=s_feats['c4'],
            s_mask=s_mask
        )
        
        return {
            'c2': q_feats['c2'],
            'c3': q_feats['c3'],
            'c4': q_c4_enhanced,
            'c5': q_feats['c5']
        }

    def get_detection_output(self, output: Dict, class_names: List[str] = None, 
                             conf_threshold: float = 0.5) -> List[Dict]:
        """
        将模型输出转换为检测格式
        
        Args:
            output: 模型输出字典
            class_names: 类别名称列表
            conf_threshold: 置信度阈值
        
        Returns:
            list of dict: 每个样本的检测结果
                {
                    'class_id': int,
                    'class_name': str,
                    'bbox': [x1, y1, x2, y2],
                    'confidence': float,
                    'seg_mask': np.ndarray
                }
        """
        batch_size = output['seg_prob'].shape[0]
        H, W = output['seg_prob'].shape[-2:]
        
        results = []
        for i in range(batch_size):
            seg_prob = output['seg_prob'][i, 0]  # (H, W)
            class_prob = output['class_prob'][i]  # (num_classes,)
            bbox = output['bbox'][i]  # (4,)
            confidence = output['confidence'][i, 0].item()
            
            class_id = class_prob.argmax().item()
            class_name = class_names[class_id] if class_names else str(class_id)
            
            cx, cy, w, h = bbox.tolist()
            x1 = (cx - w / 2) * W
            y1 = (cy - h / 2) * H
            x2 = (cx + w / 2) * W
            y2 = (cy + h / 2) * H
            
            seg_mask = (seg_prob > conf_threshold).float().cpu().numpy()
            
            results.append({
                'class_id': class_id,
                'class_name': class_name,
                'bbox': [x1, y1, x2, y2],
                'confidence': confidence,
                'seg_mask': seg_mask
            })
        
        return results

    def freeze_encoder(self):
        for param in self.encoder.parameters():
            param.requires_grad = False
    
    def unfreeze_decoder(self):
        for param in self.decoder.parameters():
            param.requires_grad = True


class MultiClassDetectionLoss(nn.Module):
    """
    多任务损失：分割 + 分类 + 边界框
    
    用于训练带分类能力的模型
    """
    def __init__(self, 
                 seg_weight: float = 1.0,
                 cls_weight: float = 0.5,
                 bbox_weight: float = 0.3,
                 use_edge_loss: bool = True):
        super().__init__()
        self.seg_weight = seg_weight
        self.cls_weight = cls_weight
        self.bbox_weight = bbox_weight
        self.use_edge_loss = use_edge_loss
        
        self.seg_loss = MultiScaleBCEDiceLoss(use_edge_loss=use_edge_loss)
        self.cls_loss = nn.CrossEntropyLoss()
        self.bbox_loss = nn.SmoothL1Loss()
    
    def forward(self, output: Dict, target_mask: torch.Tensor, 
                target_class: torch.Tensor, target_bbox: torch.Tensor = None):
        """
        Args:
            output: 模型输出字典
            target_mask: (B, 1, H, W) 分割GT
            target_class: (B,) 类别GT
            target_bbox: (B, 4) 边界框GT [cx, cy, w, h]（可选）
        
        Returns:
            total_loss: 总损失
            loss_dict: 各项损失
        """
        loss_dict = {}
        
        seg_loss = self.seg_loss(output['logits'], target_mask)
        loss_dict['seg_loss'] = seg_loss.item()
        
        cls_loss = self.cls_loss(output['class_logits'], target_class)
        loss_dict['cls_loss'] = cls_loss.item()
        
        total_loss = self.seg_weight * seg_loss + self.cls_weight * cls_loss
        
        if target_bbox is not None:
            bbox_loss = self.bbox_loss(output['bbox'], target_bbox)
            loss_dict['bbox_loss'] = bbox_loss.item()
            total_loss = total_loss + self.bbox_weight * bbox_loss
        
        loss_dict['total_loss'] = total_loss.item()
        
        return total_loss, loss_dict


class MultiScaleBCEDiceLoss(nn.Module):
    def __init__(self, scale_weights=None, use_edge_loss=True, edge_weight=0.2, edge_kernel=7):
        super().__init__()
        self.use_edge_loss = use_edge_loss
        self.edge_weight = edge_weight
        self.edge_kernel = edge_kernel
        
        if scale_weights is None:
            self.scale_weights = {'log2': 1.0, 'log3': 0.5, 'log4': 0.25, 'log5': 0.125}
        else:
            self.scale_weights = scale_weights
    
    def make_soft_edge(self, prob, k=7):
        pad = k // 2
        dil = F.max_pool2d(prob, kernel_size=k, stride=1, padding=pad)
        ero = 1.0 - F.max_pool2d(1.0 - prob, kernel_size=k, stride=1, padding=pad)
        edge = (dil - ero).clamp(0, 1)
        return edge
    
    def bce_dice_loss(self, logit, mask):
        prob = torch.sigmoid(logit)
        
        bce = F.binary_cross_entropy_with_logits(logit, mask)
        
        eps = 1e-6
        inter = (prob * mask).sum(dim=(2, 3))
        union = (prob + mask).sum(dim=(2, 3))
        dice = 1 - (2 * inter + eps) / (union + eps)
        dice = dice.mean()
        
        return bce + dice
    
    def bce_dice_edge_loss(self, logit, mask):
        prob = torch.sigmoid(logit)
        eps = 1e-6
        
        bce = F.binary_cross_entropy_with_logits(logit, mask)
        
        inter = (prob * mask).sum(dim=(2, 3))
        union = (prob + mask).sum(dim=(2, 3))
        dice = 1 - (2 * inter + eps) / (union + eps)
        dice = dice.mean()
        
        main_loss = bce + dice
        
        if self.edge_weight > 0:
            edge_gt = self.make_soft_edge(mask, k=self.edge_kernel)
            edge_pred = self.make_soft_edge(prob, k=self.edge_kernel)
            
            edge_bce = F.binary_cross_entropy(edge_pred.clamp(1e-6, 1-1e-6), edge_gt)
            
            edge_inter = (edge_pred * edge_gt).sum(dim=(2, 3))
            edge_union = (edge_pred + edge_gt).sum(dim=(2, 3))
            edge_dice = 1 - (2 * edge_inter + eps) / (edge_union + eps)
            edge_dice = edge_dice.mean()
            
            return main_loss + self.edge_weight * (edge_bce + edge_dice)
        
        return main_loss
    
    def forward(self, logits, target_mask):
        total_loss = 0.0
        
        for lvl, weight in self.scale_weights.items():
            if lvl in logits:
                logit = logits[lvl]
                target = F.interpolate(
                    target_mask, 
                    size=logit.shape[-2:], 
                    mode="nearest"
                )
                
                if self.use_edge_loss:
                    loss = self.bce_dice_edge_loss(logit, target)
                else:
                    loss = self.bce_dice_loss(logit, target)
                total_loss += weight * loss
        
        return total_loss


def build_model_with_class(num_classes: int = 102, backbone: str = 'resnet50', 
                           pretrained: bool = True, use_cross_attn: bool = True) -> FewShotCamouflageSegWithClass:
    """
    构建带分类能力的模型
    
    Args:
        num_classes: 类别数量
        backbone: 主干网络
        pretrained: 是否使用预训练权重
        use_cross_attn: 是否使用Cross-Attention
    
    Returns:
        模型实例
    """
    model = FewShotCamouflageSegWithClass(
        backbone=backbone,
        pretrained=pretrained,
        num_classes=num_classes,
        use_edge=True,
        use_token=True,
        use_cross_attn=use_cross_attn,
        use_adapter=True
    )
    return model


if __name__ == "__main__":
    model = build_model_with_class(num_classes=102)
    
    K = 5
    B = 1
    H, W = 512, 512
    
    supp_imgs = torch.randn(K, 3, H, W)
    supp_masks = (torch.rand(K, 1, H, W) > 0.7).float()
    qry_imgs = torch.randn(B, 3, H, W)
    
    output = model(supp_imgs, supp_masks, qry_imgs)
    
    print("模型输出:")
    print(f"  seg_logits: {output['seg_logits'].shape}")
    print(f"  seg_prob: {output['seg_prob'].shape}")
    print(f"  class_logits: {output['class_logits'].shape}")
    print(f"  class_prob: {output['class_prob'].shape}")
    print(f"  bbox: {output['bbox'].shape}")
    print(f"  confidence: {output['confidence'].shape}")
    
    detection_results = model.get_detection_output(output)
    print(f"\n检测结果: {detection_results[0]}")
