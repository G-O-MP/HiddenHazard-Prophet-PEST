# -*- coding: utf-8 -*-
"""
核心模块定义：工具函数、MaskedAvgPool、ProtoMatcher、TokenProtoBuilder
用于小样本伪装目标分割的原型学习组件
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


# ==================== 工具函数 ====================

def l2norm(x, dim=1, eps=1e-6):
    """L2 归一化"""
    return x / (x.norm(p=2, dim=dim, keepdim=True) + eps)


class ConvBNReLU(nn.Module):
    """Conv + BatchNorm + ReLU 基础块"""
    def __init__(self, in_ch, out_ch, k=3, s=1, p=1):
        super().__init__()
        self.conv = nn.Conv2d(in_ch, out_ch, k, s, p, bias=False)
        self.bn = nn.BatchNorm2d(out_ch)
        self.act = nn.ReLU(inplace=True)

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))


def make_edge_mask(mask, k=7):
    """
    构造边界 mask（用 maxpool 近似形态学膨胀/腐蚀）
    
    Args:
        mask: (B, 1, H, W) float {0, 1}
        k: 卷积核大小
    
    Returns:
        edge: (B, 1, H, W) 边界区域 mask
    """
    pad = k // 2
    # 膨胀操作：max_pool
    dil = F.max_pool2d(mask, kernel_size=k, stride=1, padding=pad)
    # 腐蚀操作：1 - max_pool(1 - mask)
    ero = 1.0 - F.max_pool2d(1.0 - mask, kernel_size=k, stride=1, padding=pad)
    # 边界 = 膨胀 - 腐蚀
    edge = (dil - ero).clamp(0, 1)
    return edge


# ==================== MaskedAvgPool ====================

class MaskedAvgPool(nn.Module):
    """
    带 mask 的平均池化，用于从特征图中提取原型向量
    
    Args:
        x: (B, C, H, W) 特征图
        mask: (B, 1, H, W) float {0, 1}
    
    Returns:
        proto: (B, C) 原型向量
    """
    def forward(self, x, mask, eps=1e-6):
        # 将 mask 插值到特征图尺寸
        mask = F.interpolate(mask, size=x.shape[-2:], mode="nearest")
        # 计算加权和
        num = (x * mask).sum(dim=(2, 3))  # (B, C)
        # 计算 mask 区域面积
        den = mask.sum(dim=(2, 3)).clamp_min(eps)  # (B, 1)
        return num / den


# ==================== ProtoMatcher ====================

class ProtoMatcher(nn.Module):
    """
    计算特征与原型之间的余弦相似度图
    
    支持两种模式：
    - global proto: proto (B, C) -> sim (B, 1, H, W)
    - token protos: proto (B, K, C) -> sim (B, K, H, W) 或聚合后 (B, 1, H, W)
    """
    def forward(self, feat, proto, aggregate="max"):
        """
        Args:
            feat: (B, C, H, W) 特征图
            proto: (B, C) 或 (B, K, C) 原型
            aggregate: 对于 token protos，聚合方式 {"max", "mean", None}
        
        Returns:
            sim: 相似度图
        """
        feat_n = l2norm(feat, dim=1)  # (B, C, H, W)

        if proto.dim() == 2:
            # Global proto: (B, C) -> (B, C, 1, 1)
            p = l2norm(proto, dim=1).unsqueeze(-1).unsqueeze(-1)
            sim = (feat_n * p).sum(dim=1, keepdim=True)  # (B, 1, H, W)
            return sim

        elif proto.dim() == 3:
            # Token protos: (B, K, C) -> (B, K, C, 1, 1)
            p = l2norm(proto, dim=2).unsqueeze(-1).unsqueeze(-1)  # (B, K, C, 1, 1)
            # feat_n: (B, 1, C, H, W) for broadcast
            sim = (feat_n.unsqueeze(1) * p).sum(dim=2)  # (B, K, H, W)
            
            if aggregate == "max":
                return sim.max(dim=1, keepdim=True).values  # (B, 1, H, W)
            elif aggregate == "mean":
                return sim.mean(dim=1, keepdim=True)
            else:
                return sim  # 保留 K 个 map
        else:
            raise ValueError("proto dim must be 2 or 3")


# ==================== TokenProtoBuilder ====================

class TokenProtoBuilder(nn.Module):
    """
    Token 原型构建器：将区域特征做 adaptive pooling 得到 K 个 token
    
    简化实现：将前景/背景区域特征做网格池化 -> K = tH * tW tokens
    """
    def __init__(self, tH=3, tW=3):
        super().__init__()
        self.tH = tH
        self.tW = tW

    def forward(self, feat, mask):
        """
        Args:
            feat: (B, C, H, W) 特征图
            mask: (B, 1, H, W) float {0, 1}
        
        Returns:
            tokens: (B, K, C) 其中 K = tH * tW
        """
        # 将 mask 插值到特征图尺寸
        mask = F.interpolate(mask, size=feat.shape[-2:], mode="nearest")
        # 提取 masked 特征
        feat_masked = feat * mask

        # Adaptive pool 到 (tH, tW)，每格一个 token
        pooled = F.adaptive_avg_pool2d(feat_masked, (self.tH, self.tW))  # (B, C, tH, tW)
        # 展平成 tokens
        tokens = pooled.flatten(2).transpose(1, 2)  # (B, K, C) where K = tH * tW
        return tokens


# ==================== 辅助函数 ====================

def resize_mask(mask: torch.Tensor, feat: torch.Tensor) -> torch.Tensor:
    """
    将 mask 下采样到特征分辨率
    
    Args:
        mask: (K, 1, H, W) 原始分辨率 mask
        feat: (K, C, h, w) 目标特征图
    
    Returns:
        resized mask: (K, 1, h, w)
    """
    return F.interpolate(mask, size=feat.shape[-2:], mode="nearest")


def safe_mean(x: torch.Tensor, dim: int, eps: float = 1e-6) -> torch.Tensor:
    """
    安全的平均操作（防止空集）
    
    Args:
        x: 输入 tensor
        dim: 平均的维度
        eps: 防止除零
    
    Returns:
        mean tensor
    """
    if x.shape[dim] == 0:
        return x.new_zeros(x.shape[:dim] + x.shape[dim+1:])
    return x.mean(dim=dim)


# ==================== ProtoBuilder ====================

class ProtoBuilder(nn.Module):
    """
    原型构建器：从 support 构建 FG/BG/EDGE 的 global proto + (可选) token proto
    
    支持两种模式：
    - Global proto：稳定、最先跑通用
    - Token proto：max 聚合，冲更高用
    
    Args:
        use_edge: 是否使用边界原型
        use_token: 是否使用 token 原型
        token_grid: token 网格大小 (tH, tW)
        edge_kernel: 边界 mask 卷积核大小
    """
    def __init__(self, 
                 use_edge: bool = True, 
                 use_token: bool = False, 
                 token_grid: tuple = (3, 3),
                 edge_kernel: int = 7):
        super().__init__()
        self.use_edge = use_edge
        self.use_token = use_token
        self.edge_kernel = edge_kernel
        self.pool = MaskedAvgPool()
        
        if use_token:
            self.token_builder = TokenProtoBuilder(*token_grid)
    
    def forward(self, s_feats: dict, s_mask: torch.Tensor) -> dict:
        """
        从 support set 构建原型
        
        Args:
            s_feats: dict {"c2", "c3", "c4", "c5"} each (K, C, h, w)
            s_mask: (K, 1, H, W) 原始分辨率的 mask
        
        Returns:
            protos: 每层的原型字典
                - p_fg: (1, C) 前景原型
                - p_bg: (1, C) 背景原型
                - p_edge: (1, C) 边界原型 (可选)
                - t_fg: (1, Kt, C) 前景 token 原型 (可选)
                - t_bg: (1, Kt, C) 背景 token 原型 (可选)
        """
        protos = {}
        M = s_mask  # (K, 1, H, W)
        
        # 预计算边界 mask
        if self.use_edge:
            M_edge = make_edge_mask(M, k=self.edge_kernel)
        
        for lvl in ["c2", "c3", "c4", "c5"]:
            Fs = s_feats[lvl]  # (K, C, h, w)
            Ms = resize_mask(M, Fs)  # (K, 1, h, w)
            
            # 前景和背景 global proto
            p_fg_k = self.pool(Fs, Ms)            # (K, C)
            p_bg_k = self.pool(Fs, 1.0 - Ms)      # (K, C)
            
            # 聚合 K-shot：平均成一个原型
            p_fg = p_fg_k.mean(dim=0, keepdim=True)  # (1, C)
            p_bg = p_bg_k.mean(dim=0, keepdim=True)
            
            protos[lvl] = {"p_fg": p_fg, "p_bg": p_bg}
            
            # 边界原型
            if self.use_edge:
                Me = resize_mask(M_edge, Fs)
                p_edge_k = self.pool(Fs, Me)  # (K, C)
                p_edge = p_edge_k.mean(dim=0, keepdim=True)  # (1, C)
                protos[lvl]["p_edge"] = p_edge
            
            # Token 原型
            if self.use_token:
                # 每张 support 得到 tokens，再平均
                t_fg_k = self.token_builder(Fs, Ms)           # (K, Kt, C)
                t_bg_k = self.token_builder(Fs, 1.0 - Ms)     # (K, Kt, C)
                
                t_fg = t_fg_k.mean(dim=0, keepdim=True)  # (1, Kt, C)
                t_bg = t_bg_k.mean(dim=0, keepdim=True)
                
                protos[lvl]["t_fg"] = t_fg
                protos[lvl]["t_bg"] = t_bg
        
        return protos


# ==================== GuideBuilder ====================

class GuideBuilder(nn.Module):
    """
    引导图构建器：在 query 上生成 g2/g3/g4/g5（s_diff + s_edge）
    
    支持两种模式：
    - Global 模式：sim = cos(feat, p_fg)
    - Token 模式：sim = max_k cos(feat, t_fg[k])（默认 max 聚合）
    
    Args:
        use_edge: 是否使用边界相似度
        use_token_proto: 是否使用 token 原型
        token_agg: token 聚合方式 ("max", "mean")
    """
    def __init__(self, 
                 use_edge: bool = True, 
                 use_token_proto: bool = False, 
                 token_agg: str = "max"):
        super().__init__()
        self.use_edge = use_edge
        self.use_token_proto = use_token_proto
        self.token_agg = token_agg
        self.match = ProtoMatcher()
    
    def forward(self, q_feats: dict, protos: dict) -> dict:
        """
        使用原型在 query 特征上生成 guidance maps
        
        Args:
            q_feats: dict c2..c5, 每个 (B, C, h, w)
            protos: 原型字典（来自 ProtoBuilder）
        
        Returns:
            guides: dict g2..g5, 每个 (B, guide_ch, h, w)
                - guide_ch=2: [s_diff, s_edge]
                - guide_ch=1: [s_diff]
        """
        guides = {}
        lvl_to_gname = {"c2": "g2", "c3": "g3", "c4": "g4", "c5": "g5"}
        
        for lvl, gname in lvl_to_gname.items():
            Fq = q_feats[lvl]  # (B, C, h, w)
            
            if self.use_token_proto and "t_fg" in protos[lvl]:
                # 使用 token 原型计算相似度
                sim_fg = self.match(Fq, protos[lvl]["t_fg"], aggregate=self.token_agg)  # (B, 1, h, w)
                sim_bg = self.match(Fq, protos[lvl]["t_bg"], aggregate=self.token_agg)
            else:
                # 使用全局原型计算相似度
                sim_fg = self.match(Fq, protos[lvl]["p_fg"])
                sim_bg = self.match(Fq, protos[lvl]["p_bg"])
            
            # 差异图：前景 - 背景
            s_diff = sim_fg - sim_bg  # (B, 1, h, w)
            
            if self.use_edge and "p_edge" in protos[lvl]:
                # 边界相似度图
                sim_edge = self.match(Fq, protos[lvl]["p_edge"])  # (B, 1, h, w)
                guides[gname] = torch.cat([s_diff, sim_edge], dim=1)  # (B, 2, h, w)
            else:
                guides[gname] = s_diff  # (B, 1, h, w)
        
        return guides


# ==================== 测试代码 ====================

if __name__ == "__main__":
    # 简单测试各模块
    B, C, H, W = 2, 256, 32, 32
    
    feat = torch.randn(B, C, H, W)
    mask = (torch.randn(B, 1, H, W) > 0).float()
    
    # 测试 MaskedAvgPool
    pool = MaskedAvgPool()
    proto = pool(feat, mask)
    print(f"MaskedAvgPool output: {proto.shape}")  # (B, C)
    
    # 测试 ProtoMatcher - global proto
    matcher = ProtoMatcher()
    sim = matcher(feat, proto)
    print(f"ProtoMatcher (global) output: {sim.shape}")  # (B, 1, H, W)
    
    # 测试 ProtoMatcher - token protos
    token_builder = TokenProtoBuilder(tH=3, tW=3)
    tokens = token_builder(feat, mask)
    print(f"TokenProtoBuilder output: {tokens.shape}")  # (B, 9, C)
    
    sim_token = matcher(feat, tokens, aggregate="max")
    print(f"ProtoMatcher (token) output: {sim_token.shape}")  # (B, 1, H, W)
    
    # 测试 make_edge_mask
    edge = make_edge_mask(mask, k=7)
    print(f"Edge mask output: {edge.shape}")  # (B, 1, H, W)
    
    # 测试 ProtoBuilder
    print("\n" + "="*50)
    print("测试 ProtoBuilder")
    print("="*50)
    
    K = 5  # 5-shot
    s_feats = {
        "c2": torch.randn(K, 256, 128, 128),
        "c3": torch.randn(K, 512, 64, 64),
        "c4": torch.randn(K, 1024, 32, 32),
        "c5": torch.randn(K, 2048, 16, 16),
    }
    s_mask = (torch.randn(K, 1, 512, 512) > 0).float()
    
    proto_builder = ProtoBuilder(use_edge=True, use_token=True, token_grid=(3, 3))
    protos = proto_builder(s_feats, s_mask)
    
    for lvl in ["c2", "c3", "c4", "c5"]:
        print(f"\n{lvl}:")
        print(f"  p_fg: {protos[lvl]['p_fg'].shape}")
        print(f"  p_bg: {protos[lvl]['p_bg'].shape}")
        print(f"  p_edge: {protos[lvl]['p_edge'].shape}")
        print(f"  t_fg: {protos[lvl]['t_fg'].shape}")
        print(f"  t_bg: {protos[lvl]['t_bg'].shape}")
    
    # 测试 GuideBuilder
    print("\n" + "="*50)
    print("测试 GuideBuilder")
    print("="*50)
    
    q_feats = {
        "c2": torch.randn(1, 256, 128, 128),
        "c3": torch.randn(1, 512, 64, 64),
        "c4": torch.randn(1, 1024, 32, 32),
        "c5": torch.randn(1, 2048, 16, 16),
    }
    
    guide_builder = GuideBuilder(use_edge=True, use_token_proto=True, token_agg="max")
    guides = guide_builder(q_feats, protos)
    
    for gname in ["g2", "g3", "g4", "g5"]:
        print(f"{gname}: {guides[gname].shape}")
    
    print("\n所有模块测试通过!")
