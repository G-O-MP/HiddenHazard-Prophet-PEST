# -*- coding: utf-8 -*-
"""
小样本伪装目标分割训练脚本

包含：
- 多尺度 BCE+Dice 损失
- Episode 训练循环
- Base/Novel 评估
"""
import os
import sys
import random
from collections import defaultdict
import warnings
warnings.filterwarnings('ignore')

# 添加项目根目录到路径
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, PROJECT_ROOT)

import numpy as np
from PIL import Image

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

from torchvision import transforms
from utils.metrics_cod import compute_all_metrics  # type: ignore
from my_models.fewshot_camouflage_seg import FewShotCamouflageSeg, FewShotCamouflageSeg_Lite, FewShotCamouflageSeg_ProtoFormerTTA, freeze_encoder_bn
from my_models.tta import tta_predict_episode, TTAAugmentation, get_tta_params_advanced


# =======================
# 分布式/Rank 工具
# =======================

def is_rank0():
    """
    判断当前是否是主进程 (rank 0)
    用于多卡训练时只在主进程打印/验证
    """
    if not torch.distributed.is_available():
        return True
    if not torch.distributed.is_initialized():
        return True
    return torch.distributed.get_rank() == 0


# =======================
# 模型验证函数
# =======================

def find_bridge_cross_module(model):
    """
    直接定位 bridge 模块内部的 cross attention 组件
    用于精确检测 DyT 是否真正在 cross-attention 中使用
    
    Returns:
        (name, module, pret_type, pret2_type) 或 (None, None, None, None)
    """
    bridge = getattr(model, "bridge", None) or \
             getattr(model, "protoformer_bridge", None) or \
             getattr(model, "cross_attn_bridge", None)
    
    if bridge is None:
        return None, None, None, None
    
    # 检查 bridge.cross.pret 和 bridge.cross.pret2 的类型
    cross = getattr(bridge, "cross", None)
    if cross is None:
        return "bridge", bridge, None, None
    
    pret = getattr(cross, "pret", None)
    pret2 = getattr(cross, "pret2", None)
    
    pret_type = type(pret).__name__ if pret else None
    pret2_type = type(pret2).__name__ if pret2 else None
    
    return "bridge.cross", cross, pret_type, pret2_type


def sanity_check_model(model, verbose=True):
    """
    验证模型结构的正确性（5个必须检查点）
    
    验收点：
    1. Bridge 是否启用 + token 配置是否固定
    2. CrossAttention 里是否真的用 DyT（不是 LayerNorm）—— 精确检测 pret/pret2 类型
    3. Decoder adapter 是否存在 + adapt_levels 是否含 p2/p3
    4. Encoder BN 是否冻结（训练阶段）
    
    Args:
        model: 模型实例
        verbose: 是否打印详细信息
    
    Returns:
        dict: 验证结果摘要
    """
    results = {
        "bridge_enabled": False,
        "bridge_nfg": 0,
        "bridge_nbg": 0,
        "bridge_nedge": 0,
        "dyt_in_cross": False,
        "pret_type": None,
        "pret2_type": None,
        "adapters_found": [],
        "bn_total": 0,
        "bn_training": 0,
    }
    
    if verbose:
        print("\n" + "="*60)
        print("[Sanity Check] 模型结构验证")
        print("="*60)
    
    # 1) Bridge 是否启用 + token 配置是否固定
    if hasattr(model, "use_cross_attn") and model.use_cross_attn:
        bridge = getattr(model, "bridge", None) or getattr(model, "protoformer_bridge", None) or getattr(model, "cross_attn_bridge", None)
        if bridge is None:
            if verbose:
                print("[Bridge] ❌ use_cross_attn=True 但找不到 bridge 模块")
        else:
            has_all_attrs = all(hasattr(bridge, k) for k in ["nfg", "nbg", "nedge"])
            if has_all_attrs:
                results["bridge_enabled"] = True
                results["bridge_nfg"] = bridge.nfg
                results["bridge_nbg"] = bridge.nbg
                results["bridge_nedge"] = bridge.nedge
                if verbose:
                    print(f"[Bridge] ✓ nfg={bridge.nfg}, nbg={bridge.nbg}, nedge={bridge.nedge}")
                    if bridge.nfg <= 0 or bridge.nbg <= 0:
                        print("[Bridge] ⚠ 警告: nfg/nbg 不应为 0")
            else:
                if verbose:
                    print("[Bridge] ⚠ bridge 缺少 nfg/nbg/nedge 属性")
    else:
        if verbose:
            print("[Bridge] disabled (use_cross_attn=False)")
    
    # 2) CrossAttention 里是否真的用 DyT —— 精确检测 pret/pret2 类型
    name, cross_mod, pret_type, pret2_type = find_bridge_cross_module(model)
    results["pret_type"] = pret_type
    results["pret2_type"] = pret2_type
    
    if verbose:
        if cross_mod is not None:
            print(f"[CrossAttn] module={name}, type={type(cross_mod).__name__}")
            print(f"[CrossAttn] pret={pret_type}, pret2={pret2_type}")
            
            if pret_type == "DyT" and pret2_type == "DyT":
                results["dyt_in_cross"] = True
                print("[CrossAttn] ✓ DyT 在 cross-attention 中真正启用")
            elif pret_type == "LayerNorm" or pret2_type == "LayerNorm":
                print("[CrossAttn] ⚠ 检测到 LayerNorm，未使用 DyT")
            else:
                print("[CrossAttn] ⚠ pret/pret2 类型未知")
        else:
            # 回退到全局统计
            dyt_cnt, ln_cnt = 0, 0
            for m in model.modules():
                mname = m.__class__.__name__.lower()
                if "dyt" in mname:
                    dyt_cnt += 1
                if "layernorm" in mname:
                    ln_cnt += 1
            print(f"[Norm] (fallback) DyT modules={dyt_cnt}, LayerNorm modules={ln_cnt}")
            if dyt_cnt > 0:
                results["dyt_in_cross"] = True
                print(f"[Norm] ✓ DyT 已启用")
    
    # 3) Decoder adapter 是否存在 + adapt_levels 是否含 p2/p3
    dec = getattr(model, "decoder", None) or getattr(model, "c2f_decoder", None)
    if dec is None:
        if verbose:
            print("[Adapter] ❌ 找不到 decoder 模块")
    else:
        adapter_found = []
        for nm in ["adapter2", "adapter3", "adapter4", "adapter5"]:
            if hasattr(dec, nm) and getattr(dec, nm) is not None:
                adapter_found.append(nm)
        results["adapters_found"] = adapter_found
        
        if verbose:
            if adapter_found:
                print(f"[Adapter] ✓ 找到 adapters: {adapter_found}")
            else:
                print("[Adapter] ⚠ decoder 中未找到 adapter 模块")
            
            if hasattr(dec, "adapt_levels"):
                print(f"[Adapter] adapt_levels = {dec.adapt_levels}")
                if ("p2" in dec.adapt_levels) and ("p3" in dec.adapt_levels):
                    print("[Adapter] ✓ 包含 p2/p3")
            else:
                print("[Adapter] adapt_levels 属性不存在 (可能是硬编码)")
    
    # 4) Encoder BN 是否冻结
    enc = getattr(model, "encoder", None) or getattr(model, "backbone", None) or getattr(model, "resnet", None)
    if enc is None:
        if verbose:
            print("[BN] ❌ 找不到 encoder/backbone")
    else:
        bn_train = 0
        bn_total = 0
        for m in enc.modules():
            if m.__class__.__name__ == "BatchNorm2d":
                bn_total += 1
                if m.training:
                    bn_train += 1
        results["bn_total"] = bn_total
        results["bn_training"] = bn_train
        
        if verbose:
            print(f"[BN] encoder BN total={bn_total}, training={bn_train}")
            if bn_train == 0:
                print("[BN] ✓ BN 已冻结")
            else:
                print("[BN] ⚠ BN 未完全冻结，建议调用 freeze_encoder_bn(model)")
    
    if verbose:
        print("="*60 + "\n")
    
    return results


@torch.no_grad()
def sanity_check_shapes(model, device="cuda", H=512, W=512, K=5, N=1, verbose=True):
    """
    验证模型输入输出形状（Episode 维度对齐）
    
    包含：
    - pred 形状验证
    - guide (g2/g3/g4/g5) 分辨率验证（必须对齐 ResNet stride）
    - logit (log2/log3/log4/log5) 形状验证
    
    Args:
        model: 模型实例
        device: 设备
        H, W: 图像尺寸
        K: shot 数
        N: query 数
        verbose: 是否打印详细信息
    
    Returns:
        dict: 验证结果
    """
    results = {
        "pred_shape_ok": False,
        "guides_shape_ok": True,
        "logits_shape_ok": True,
        "errors": []
    }
    
    if verbose:
        print("\n" + "="*60)
        print(f"[Shape Check] Episode 形状验证 (K={K}, N={N}, H={H}, W={W})")
        print("="*60)
    
    model.eval()
    
    try:
        supp_imgs  = torch.randn(K, 3, H, W, device=device)
        supp_masks = (torch.rand(K, 1, H, W, device=device) > 0.7).float()
        qry_imgs   = torch.randn(N, 3, H, W, device=device)
        
        pred, logits, guides = model(supp_imgs, supp_masks, qry_imgs)
        
        # === 1) pred 形状验证 ===
        expected_pred_shape = (N, 1, H, W)
        if verbose:
            print(f"[pred] shape={pred.shape}")
        if pred.shape == expected_pred_shape:
            results["pred_shape_ok"] = True
            if verbose:
                print(f"[pred] ✓ 形状正确: {expected_pred_shape}")
        else:
            results["errors"].append(f"pred: 期望 {expected_pred_shape}, 实际 {pred.shape}")
            if verbose:
                print(f"[pred] ❌ 形状不匹配! 期望 {expected_pred_shape}, 实际 {pred.shape}")
        
        # === 2) guides 分辨率验证 (ResNet stride: c2=1/4, c3=1/8, c4=1/16, c5=1/32) ===
        expected_guide_shapes = {
            "g2": (N, 2, H // 4, W // 4),    # c2 -> 1/4 分辨率
            "g3": (N, 2, H // 8, W // 8),    # c3 -> 1/8 分辨率
            "g4": (N, 2, H // 16, W // 16),  # c4 -> 1/16 分辨率
            "g5": (N, 2, H // 32, W // 32),  # c5 -> 1/32 分辨率
        }
        # 注：guide 通道数可能是 1 或 2，取决于 use_edge
        
        for gname, expected in expected_guide_shapes.items():
            if gname in guides:
                actual = guides[gname].shape
                # 检查空间尺寸是否匹配（通道数可以是 1 或 2）
                spatial_ok = (actual[-2:] == expected[-2:])
                if verbose:
                    print(f"[{gname}] shape={actual}, expected_spatial={expected[-2:]}")
                if spatial_ok:
                    if verbose:
                        print(f"[{gname}] ✓ 空间尺寸正确")
                else:
                    results["guides_shape_ok"] = False
                    results["errors"].append(f"{gname}: 期望空间 {expected[-2:]}, 实际 {actual[-2:]}")
                    if verbose:
                        print(f"[{gname}] ❌ 空间尺寸不匹配! 期望 {expected[-2:]}, 实际 {actual[-2:]}")
        
        # === 3) 多尺度 logits 检查 ===
        expected_logit_shapes = {
            "log2": (N, 1, H // 4, W // 4),
            "log3": (N, 1, H // 8, W // 8),
            "log4": (N, 1, H // 16, W // 16),
            "log5": (N, 1, H // 32, W // 32),
        }
        
        for lname, expected in expected_logit_shapes.items():
            if lname in logits:
                actual = logits[lname].shape
                if verbose:
                    print(f"[{lname}] shape={actual}")
                # 检查空间尺寸
                if actual[-2:] != expected[-2:]:
                    results["logits_shape_ok"] = False
                    results["errors"].append(f"{lname}: 期望空间 {expected[-2:]}, 实际 {actual[-2:]}")
                    if verbose:
                        print(f"[{lname}] ⚠ 空间尺寸不匹配: 期望 {expected[-2:]}")
        
        # === 汇总 ===
        all_ok = results["pred_shape_ok"] and results["guides_shape_ok"] and results["logits_shape_ok"]
        if verbose:
            if all_ok:
                print("\n[Shape Check] ✓ 所有形状验证通过!")
            else:
                print(f"\n[Shape Check] ⚠ 部分验证未通过: {results['errors']}")
        
    except Exception as e:
        results["errors"].append(str(e))
        if verbose:
            print(f"\n[Shape Check] ❌ 验证失败: {e}")
    
    if verbose:
        print("="*60 + "\n")
    
    return results


# =======================
# 配置
# =======================
DATA_ROOT = r"D:\University\Homework\机器学习\机器学习课程设计\FSL-COD数据集"
SPLIT_DIR = os.path.join(DATA_ROOT, "splits")

BASE_TRAIN_LIST = os.path.join(SPLIT_DIR, "base_train.txt")
BASE_VAL_LIST = os.path.join(SPLIT_DIR, "base_val.txt")
NOVEL_SUPPORT_LIST = os.path.join(SPLIT_DIR, "novel_support.txt")
NOVEL_QUERY_LIST = os.path.join(SPLIT_DIR, "novel_query.txt")

IMG_SIZE = 512
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
SEED = 42

N_WAY = 1
K_SHOT = 5
N_QUERY = 1
PATIENCE = 10


def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


set_seed(SEED)


# =======================
# 损失函数
# =======================

class MultiScaleBCEDiceLoss(nn.Module):
    """
    多尺度 BCE + Dice 损失 + 可选边界损失
    
    对 log2, log3, log4, log5 分别计算损失，加权求和
    伪装目标分割关键：边界对齐！
    
    Args:
        scale_weights: 各尺度的损失权重
        use_edge_loss: 是否使用边界损失
        edge_weight: 边界损失权重
        edge_kernel: 边界 mask 卷积核大小
    """
    def __init__(self, scale_weights=None, use_edge_loss=True, edge_weight=0.2, edge_kernel=7):
        super().__init__()
        self.use_edge_loss = use_edge_loss
        self.edge_weight = edge_weight
        self.edge_kernel = edge_kernel
        
        # 默认权重：细尺度权重更高
        if scale_weights is None:
            self.scale_weights = {'log2': 1.0, 'log3': 0.5, 'log4': 0.25, 'log5': 0.125}
        else:
            self.scale_weights = scale_weights
    
    def make_soft_edge(self, prob, k=7):
        """生成软边界"""
        pad = k // 2
        dil = F.max_pool2d(prob, kernel_size=k, stride=1, padding=pad)
        ero = 1.0 - F.max_pool2d(1.0 - prob, kernel_size=k, stride=1, padding=pad)
        edge = (dil - ero).clamp(0, 1)
        return edge
    
    def bce_dice_loss(self, logit, mask):
        """单尺度 BCE + Dice"""
        prob = torch.sigmoid(logit)
        
        # BCE Loss
        bce = F.binary_cross_entropy_with_logits(logit, mask)
        
        # Dice Loss
        eps = 1e-6
        inter = (prob * mask).sum(dim=(2, 3))
        union = (prob + mask).sum(dim=(2, 3))
        dice = 1 - (2 * inter + eps) / (union + eps)
        dice = dice.mean()
        
        return bce + dice
    
    def bce_dice_edge_loss(self, logit, mask):
        """单尺度 BCE + Dice + 边界"""
        prob = torch.sigmoid(logit)
        eps = 1e-6
        
        # === 主损失：BCE + Dice ===
        bce = F.binary_cross_entropy_with_logits(logit, mask)
        
        inter = (prob * mask).sum(dim=(2, 3))
        union = (prob + mask).sum(dim=(2, 3))
        dice = 1 - (2 * inter + eps) / (union + eps)
        dice = dice.mean()
        
        main_loss = bce + dice
        
        # === 边界损失 ===
        if self.edge_weight > 0:
            edge_gt = self.make_soft_edge(mask, k=self.edge_kernel)
            edge_pred = self.make_soft_edge(prob, k=self.edge_kernel)
            
            edge_bce = F.binary_cross_entropy(edge_pred.clamp(1e-6, 1-1e-6), edge_gt)
            
            edge_inter = (edge_pred * edge_gt).sum(dim=(2, 3))
            edge_union = (edge_pred + edge_gt).sum(dim=(2, 3))
            edge_dice = 1 - (2 * edge_inter + eps) / (edge_union + eps)
            edge_dice = edge_dice.mean()
            
            return main_loss + self.edge_weight * (edge_bce + edge_dice)
        
        return main_loss
    
    def forward(self, logits, target_mask):
        """
        Args:
            logits: dict with keys 'log2', 'log3', 'log4', 'log5'
            target_mask: (B, 1, H, W) 原始分辨率的 GT mask
        
        Returns:
            total_loss: 加权总损失
        """
        total_loss = 0.0
        
        for lvl, weight in self.scale_weights.items():
            if lvl in logits:
                # 将 target 下采样到对应尺度
                logit = logits[lvl]  # (B, 1, h, w)
                target = F.interpolate(
                    target_mask, 
                    size=logit.shape[-2:], 
                    mode="nearest"
                )
                
                if self.use_edge_loss:
                    loss = self.bce_dice_edge_loss(logit, target)
                else:
                    loss = self.bce_dice_loss(logit, target)
                total_loss += weight * loss
        
        return total_loss


class SimpleBCEDiceLoss(nn.Module):
    """简单 BCE + Dice 损失（仅用于最终输出）"""
    
    def forward(self, logit, mask):
        prob = torch.sigmoid(logit)
        
        # BCE Loss
        bce = F.binary_cross_entropy_with_logits(logit, mask)
        
        # Dice Loss
        eps = 1e-6
        inter = (prob * mask).sum(dim=(2, 3))
        union = (prob + mask).sum(dim=(2, 3))
        dice = 1 - (2 * inter + eps) / (union + eps)
        dice = dice.mean()
        
        return bce + dice


# =======================
# 数据工具
# =======================

def load_split_list(txt_path):
    """读取 txt 文件，返回 list[(img, mask, scene)]"""
    items = []
    with open(txt_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split()
            if len(parts) >= 3:
                img, mask, scene = parts[0], parts[1], parts[2]
            else:
                img, mask, scene = parts[0], parts[1], "unknown"
            items.append((img, mask, scene))
    return items


class SimpleTransform:
    """图像和 mask 的预处理"""
    
    def __init__(self, img_size=512, is_train=True):
        self.img_size = img_size
        self.is_train = is_train
        self.to_tensor = transforms.ToTensor()
        self.normalize = transforms.Normalize(
            mean=[0.485, 0.456, 0.406],
            std=[0.229, 0.224, 0.225],
        )

    def __call__(self, img, mask):
        img = img.resize((self.img_size, self.img_size), Image.BILINEAR)
        mask = mask.resize((self.img_size, self.img_size), Image.NEAREST)

        if self.is_train:
            if random.random() < 0.5:
                img = img.transpose(Image.FLIP_LEFT_RIGHT)
                mask = mask.transpose(Image.FLIP_LEFT_RIGHT)

        img = self.to_tensor(img)
        img = self.normalize(img)

        mask = np.array(mask, dtype=np.float32)
        if mask.max() > 1:
            mask = (mask > 127.5).astype(np.float32)
        else:
            mask = (mask > 0.5).astype(np.float32)

        mask = torch.from_numpy(mask)
        return img, mask


# =======================
# Episode 数据集
# =======================

class FewShotEpisodeDataset(Dataset):
    """Episode 采样数据集"""
    
    def __init__(self, split_list, img_size=512, k_shot=5, n_query=1):
        super().__init__()
        self.k_shot = k_shot
        self.n_query = n_query
        self.transform = SimpleTransform(img_size=img_size, is_train=True)

        self.by_scene = defaultdict(list)
        for img, mask, scene in split_list:
            self.by_scene[scene].append((img, mask))

        self.scenes = list(self.by_scene.keys())

    def __len__(self):
        return 100000

    def _load_img_mask(self, img_path, mask_path):
        img = Image.open(img_path).convert("RGB")
        mask = Image.open(mask_path).convert("L")
        return self.transform(img, mask)

    def __getitem__(self, idx):
        scene = random.choice(self.scenes)
        pairs = self.by_scene[scene]

        min_required = self.k_shot + self.n_query
        if len(pairs) < min_required:
            pairs = pairs * (min_required // len(pairs) + 1)

        idxs = list(range(len(pairs)))
        random.shuffle(idxs)
        support_idx = idxs[:self.k_shot]
        query_idx = idxs[self.k_shot:self.k_shot + self.n_query]

        support_imgs, support_masks = [], []
        query_imgs, query_masks = [], []

        for i in support_idx:
            img_path, mask_path = pairs[i]
            img, mask = self._load_img_mask(img_path, mask_path)
            support_imgs.append(img)
            support_masks.append(mask)

        for i in query_idx:
            img_path, mask_path = pairs[i]
            img, mask = self._load_img_mask(img_path, mask_path)
            query_imgs.append(img)
            query_masks.append(mask)

        support_imgs = torch.stack(support_imgs, dim=0)
        support_masks = torch.stack(support_masks, dim=0).unsqueeze(1)  # (K, 1, H, W)
        query_imgs = torch.stack(query_imgs, dim=0)
        query_masks = torch.stack(query_masks, dim=0).unsqueeze(1)  # (N, 1, H, W)

        return support_imgs, support_masks, query_imgs, query_masks, scene


# =======================
# 评估函数
# =======================

@torch.no_grad()
def evaluate_on_val(model, val_items, support_items, device):
    """在验证集上评估"""
    model.eval()
    
    # 按场景分组 support
    support_by_scene = defaultdict(list)
    for img, mask, scene in support_items:
        support_by_scene[scene].append((img, mask))
    
    transform = SimpleTransform(img_size=IMG_SIZE, is_train=False)
    
    all_preds = []
    all_gts = []
    
    for img_path, mask_path, scene in val_items:
        # 加载 query
        qry_img = Image.open(img_path).convert("RGB")
        qry_mask = Image.open(mask_path).convert("L")
        qry_img, qry_mask = transform(qry_img, qry_mask)
        qry_img = qry_img.unsqueeze(0).to(device)
        qry_mask_np = qry_mask.numpy()
        
        # 找到同场景的 support
        if scene in support_by_scene:
            supp_pairs = support_by_scene[scene][:K_SHOT]
        else:
            rand_scene = random.choice(list(support_by_scene.keys()))
            supp_pairs = support_by_scene[rand_scene][:K_SHOT]
        
        # 加载 support
        supp_imgs, supp_masks = [], []
        for sp_img, sp_mask in supp_pairs:
            s_img = Image.open(sp_img).convert("RGB")
            s_mask = Image.open(sp_mask).convert("L")
            s_img, s_mask = transform(s_img, s_mask)
            supp_imgs.append(s_img)
            supp_masks.append(s_mask)
        
        # 填充至 K_SHOT
        while len(supp_imgs) < K_SHOT:
            supp_imgs.append(supp_imgs[0])
            supp_masks.append(supp_masks[0])
        
        supp_imgs = torch.stack(supp_imgs).to(device)
        supp_masks = torch.stack(supp_masks).unsqueeze(1).to(device)  # (K, 1, H, W)
        
        # 推理
        out, _, _ = model(supp_imgs, supp_masks, qry_img)
        pred_prob = torch.sigmoid(out).cpu().numpy()[0, 0]  # (H, W)
        
        all_preds.append(pred_prob)
        all_gts.append(qry_mask_np)
    
    all_preds = np.stack(all_preds, axis=0)
    all_gts = np.stack(all_gts, axis=0)
    
    metrics = compute_all_metrics(all_preds, all_gts)
    return metrics


# =======================
# 训练 Base
# =======================

def train_base(model_type='full', num_epochs=30, steps_per_epoch=200, lr=1e-4):
    """
    Base 阶段训练
    
    Args:
        model_type: 'full' 或 'lite'
        num_epochs: 训练轮数
        steps_per_epoch: 每轮步数
        lr: 学习率
    """
    print("="*60)
    print(f"FewShotCamouflageSeg Base 训练 (model_type={model_type})")
    print("="*60)
    
    base_train_items = load_split_list(BASE_TRAIN_LIST)
    base_val_items = load_split_list(BASE_VAL_LIST)

    train_dataset = FewShotEpisodeDataset(
        base_train_items, img_size=IMG_SIZE, k_shot=K_SHOT, n_query=N_QUERY
    )
    train_loader = DataLoader(train_dataset, batch_size=1, shuffle=False)

    # 创建模型
    if model_type == 'lite':
        model = FewShotCamouflageSeg_Lite(
            backbone='resnet50',
            pretrained=True
        ).to(DEVICE)
    else:
        model = FewShotCamouflageSeg(
            backbone='resnet50',
            pretrained=True,
            use_edge=True,
            use_token=True,
            token_grid=(3, 3)
        ).to(DEVICE)
    
    # 损失函数和优化器
    criterion = MultiScaleBCEDiceLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=10, gamma=0.5)

    best_val_dice = 0.0
    no_improve = 0
    
    save_name = f"fewshot_camo_{model_type}_base.pth"
    save_path = os.path.join("checkpoints", save_name)
    os.makedirs("checkpoints", exist_ok=True)

    print(f"设备: {DEVICE}")
    print(f"K-shot: {K_SHOT}")
    print(f"训练集场景数: {len(set(x[2] for x in base_train_items))}")
    print(f"验证集样本数: {len(base_val_items)}")
    print(f"早停 patience: {PATIENCE}")
    print("="*60)

    for epoch in range(num_epochs):
        model.train()
        running_loss = 0.0

        for step, batch in enumerate(train_loader):
            if step >= steps_per_epoch:
                break
                
            supp_imgs, supp_masks, qry_imgs, qry_masks, scene = batch
            
            # 去掉 batch 维度（因为 batch_size=1）
            supp_imgs = supp_imgs.squeeze(0).to(DEVICE)    # (K, 3, H, W)
            supp_masks = supp_masks.squeeze(0).to(DEVICE)  # (K, 1, H, W)
            qry_imgs = qry_imgs.squeeze(0).to(DEVICE)      # (N, 3, H, W)
            qry_masks = qry_masks.squeeze(0).to(DEVICE)    # (N, 1, H, W)

            optimizer.zero_grad()
            
            # 前向传播
            out, logits, guides = model(supp_imgs, supp_masks, qry_imgs)
            
            # 计算多尺度损失
            loss = criterion(logits, qry_masks)
            
            loss.backward()
            optimizer.step()

            running_loss += loss.item()

        scheduler.step()
        avg_loss = running_loss / steps_per_epoch

        # 验证
        metrics = evaluate_on_val(model, base_val_items, base_train_items, DEVICE)
        val_dice = metrics['Dice']

        print(f"Epoch [{epoch+1:2d}/{num_epochs}] "
              f"Loss: {avg_loss:.4f} | "
              f"Val Dice: {val_dice:.4f} | "
              f"mIoU: {metrics['mIoU']:.4f} | "
              f"S: {metrics['S_measure']:.4f}")

        if val_dice > best_val_dice:
            best_val_dice = val_dice
            no_improve = 0
            torch.save(model.state_dict(), save_path)
            print(f"  -> 新最佳! Dice={best_val_dice:.4f}")
        else:
            no_improve += 1
            if no_improve >= PATIENCE:
                print(f"\n早停触发! 连续{PATIENCE}轮无改进")
                break

    print(f"\n[Base] 训练完成, 最佳Dice: {best_val_dice:.4f}")
    return save_path


# =======================
# Novel 评估
# =======================

@torch.no_grad()
def evaluate_novel(model_type='full'):
    """
    Novel 场景评估（不使用 TTA）
    """
    print("\n" + "="*60)
    print(f"FewShotCamouflageSeg Novel 评估 (model_type={model_type}, {K_SHOT}-shot)")
    print("="*60)
    
    novel_support_items = load_split_list(NOVEL_SUPPORT_LIST)
    novel_query_items = load_split_list(NOVEL_QUERY_LIST)
    
    # 创建模型
    if model_type == 'lite':
        model = FewShotCamouflageSeg_Lite(
            backbone='resnet50',
            pretrained=False
        ).to(DEVICE)
    else:
        model = FewShotCamouflageSeg(
            backbone='resnet50',
            pretrained=False,
            use_edge=True,
            use_token=True,
            token_grid=(3, 3)
        ).to(DEVICE)
    
    ckpt_path = os.path.join("checkpoints", f"fewshot_camo_{model_type}_base.pth")
    
    if os.path.exists(ckpt_path):
        model.load_state_dict(torch.load(ckpt_path, map_location=DEVICE))
        print(f"已加载模型: {ckpt_path}")
    else:
        print(f"警告: 找不到模型 {ckpt_path}")
        return
    
    print(f"Novel Support: {len(novel_support_items)} 样本")
    print(f"Novel Query: {len(novel_query_items)} 样本")
    
    metrics = evaluate_on_val(model, novel_query_items, novel_support_items, DEVICE)
    
    print("\n" + "="*60)
    print("Novel 测试结果:")
    print("="*60)
    print("主指标:")
    print(f"  mIoU:      {metrics['mIoU']:.4f}")
    print(f"  Dice:      {metrics['Dice']:.4f}")
    print(f"  S-measure: {metrics['S_measure']:.4f}")
    print("辅指标:")
    print(f"  maxF:      {metrics['maxF']:.4f}")
    print(f"  MAE:       {metrics['MAE']:.4f}")
    print(f"  PixelAcc:  {metrics['PixelAcc']:.4f}")
    print("="*60)
    
    return metrics


# =======================
# Novel 评估 (with TTA)
# =======================

def evaluate_novel_with_tta(
    tta_steps: int = 10,
    tta_lr: float = 1e-3,
    tta_prox_lambda: float = 1e-4,
    tta_param_mode: str = "adapter_only",
    use_tta_aug: bool = True,
):
    """
    Novel 场景评估（使用 TTA）
    
    用于测试 Test-Time Adaptation 的效果
    
    Args:
        tta_steps: TTA 优化步数
        tta_lr: TTA 学习率
        tta_prox_lambda: proximal 正则化系数
        tta_param_mode: 参数更新模式 ("adapter_only", "adapter_plus_cross", "adapter_plus_head")
        use_tta_aug: 是否使用 TTA 增强
    """
    print("\n" + "="*60)
    print(f"FewShotCamouflageSeg Novel 评估 (with TTA, {K_SHOT}-shot)")
    print(f"TTA 配置: steps={tta_steps}, lr={tta_lr}, prox={tta_prox_lambda}, mode={tta_param_mode}")
    print("="*60)
    
    novel_support_items = load_split_list(NOVEL_SUPPORT_LIST)
    novel_query_items = load_split_list(NOVEL_QUERY_LIST)
    
    # 创建 ProtoFormerTTA 模型
    model = FewShotCamouflageSeg_ProtoFormerTTA(
        backbone='resnet50',
        pretrained=False,
        use_edge=True,
        use_token_proto=True,
        token_grid=(3, 3),
        use_cross_attn=True,
        cross_dim=1024,
        cross_num_heads=8,
        cross_nfg=64,
        cross_nbg=64,
        cross_nedge=64,
        cross_res_scale=0.1,
        use_adapter=True,
        adapt_levels=("p2", "p3"),
        adapter_reduction=16,
        mid_ch=256,
        edge_kernel=7
    ).to(DEVICE)
    
    ckpt_path = os.path.join("checkpoints", "fewshot_camo_protoformer_tta.pth")
    
    if os.path.exists(ckpt_path):
        model.load_state_dict(torch.load(ckpt_path, map_location=DEVICE))
        print(f"已加载模型: {ckpt_path}")
    else:
        print(f"警告: 找不到模型 {ckpt_path}，尝试加载 full 模型...")
        alt_ckpt = os.path.join("checkpoints", "fewshot_camo_full_base.pth")
        if os.path.exists(alt_ckpt):
            # 尝试加载兼容的权重
            state = torch.load(alt_ckpt, map_location=DEVICE)
            model.load_state_dict(state, strict=False)
            print(f"已加载兼容模型: {alt_ckpt} (strict=False)")
        else:
            print(f"警告: 找不到任何模型")
            return
    
    print(f"Novel Support: {len(novel_support_items)} 样本")
    print(f"Novel Query: {len(novel_query_items)} 样本")
    
    # 创建 TTA 增强函数
    aug_fn = None
    if use_tta_aug:
        aug_fn = TTAAugmentation(
            flip_prob=0.5,
            scale_range=(0.95, 1.05),
            brightness_range=(0.95, 1.05),
            contrast_range=(0.95, 1.05),
        )
    
    # 按场景分组 support
    support_by_scene = defaultdict(list)
    for img, mask, scene in novel_support_items:
        support_by_scene[scene].append((img, mask))
    
    transform = SimpleTransform(img_size=IMG_SIZE, is_train=False)
    
    all_preds = []
    all_gts = []
    
    print("\n开始 TTA 评估...")
    
    for idx, (img_path, mask_path, scene) in enumerate(novel_query_items):
        # 加载 query
        qry_img = Image.open(img_path).convert("RGB")
        qry_mask = Image.open(mask_path).convert("L")
        qry_img, qry_mask = transform(qry_img, qry_mask)
        qry_img = qry_img.unsqueeze(0).to(DEVICE)
        qry_mask_np = qry_mask.numpy()
        
        # 找到同场景的 support
        if scene in support_by_scene:
            supp_pairs = support_by_scene[scene][:K_SHOT]
        else:
            rand_scene = random.choice(list(support_by_scene.keys()))
            supp_pairs = support_by_scene[rand_scene][:K_SHOT]
        
        # 加载 support
        supp_imgs, supp_masks = [], []
        for sp_img, sp_mask in supp_pairs:
            s_img = Image.open(sp_img).convert("RGB")
            s_mask = Image.open(sp_mask).convert("L")
            s_img, s_mask = transform(s_img, s_mask)
            supp_imgs.append(s_img)
            supp_masks.append(s_mask)
        
        # 填充至 K_SHOT
        while len(supp_imgs) < K_SHOT:
            supp_imgs.append(supp_imgs[0])
            supp_masks.append(supp_masks[0])
        
        supp_imgs = torch.stack(supp_imgs).to(DEVICE)
        supp_masks = torch.stack(supp_masks).unsqueeze(1).to(DEVICE)
        
        # TTA 推理
        pred = tta_predict_episode(
            model=model,
            support_imgs=supp_imgs,
            support_masks=supp_masks,
            query_img=qry_img,
            steps=tta_steps,
            lr=tta_lr,
            prox_lambda=tta_prox_lambda,
            param_mode=tta_param_mode,
            aug_fn=aug_fn,
            use_multiscale_loss=False,
        )
        
        pred_prob = torch.sigmoid(pred).cpu().numpy()[0, 0]
        
        all_preds.append(pred_prob)
        all_gts.append(qry_mask_np)
        
        if (idx + 1) % 10 == 0:
            print(f"  进度: {idx+1}/{len(novel_query_items)}")
    
    all_preds = np.stack(all_preds, axis=0)
    all_gts = np.stack(all_gts, axis=0)
    
    metrics = compute_all_metrics(all_preds, all_gts)
    
    print("\n" + "="*60)
    print("Novel 测试结果 (with TTA):")
    print("="*60)
    print("主指标:")
    print(f"  mIoU:      {metrics['mIoU']:.4f}")
    print(f"  Dice:      {metrics['Dice']:.4f}")
    print(f"  S-measure: {metrics['S_measure']:.4f}")
    print("辅指标:")
    print(f"  maxF:      {metrics['maxF']:.4f}")
    print(f"  MAE:       {metrics['MAE']:.4f}")
    print(f"  PixelAcc:  {metrics['PixelAcc']:.4f}")
    print("="*60)
    
    return metrics


# =======================
# 训练 ProtoFormerTTA 模型
# =======================

def train_protoformer_tta(num_epochs=30, steps_per_epoch=200, lr=1e-4, 
                          do_sanity_check=True, sanity_check_iters=1):
    """
    训练 ProtoFormerTTA 模型（带 Cross-Attention 和 Adapter）
    
    这是最终的“冲榜”版本
    
    Args:
        num_epochs: 训练轮数
        steps_per_epoch: 每轮步数
        lr: 学习率
        do_sanity_check: 是否执行 sanity check (只在 rank0 执行)
        sanity_check_iters: sanity check 运行次数
    """
    print("="*60)
    print("FewShotCamouflageSeg_ProtoFormerTTA 训练")
    print("="*60)
    
    base_train_items = load_split_list(BASE_TRAIN_LIST)
    base_val_items = load_split_list(BASE_VAL_LIST)

    train_dataset = FewShotEpisodeDataset(
        base_train_items, img_size=IMG_SIZE, k_shot=K_SHOT, n_query=N_QUERY
    )
    train_loader = DataLoader(train_dataset, batch_size=1, shuffle=False)

    # 创建 ProtoFormerTTA 模型
    model = FewShotCamouflageSeg_ProtoFormerTTA(
        backbone='resnet50',
        pretrained=True,
        use_edge=True,
        use_token_proto=True,
        token_grid=(3, 3),
        use_cross_attn=True,
        cross_dim=1024,
        cross_num_heads=8,
        cross_nfg=64,
        cross_nbg=64,
        cross_nedge=64,
        cross_res_scale=0.1,
        use_adapter=True,
        adapt_levels=("p2", "p3"),
        adapter_reduction=16,
        mid_ch=256,
        edge_kernel=7
    ).to(DEVICE)
    
    # 损失函数和优化器（启用边界损失）
    criterion = MultiScaleBCEDiceLoss(use_edge_loss=True, edge_weight=0.2, edge_kernel=7)
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=10, gamma=0.5)
    
    # ★★★ 关键：冻结 Encoder 的 BN 层 ★★★
    freeze_encoder_bn(model)
    print("[BN 状态] Encoder BN 已冻结")
    
    # ★★★ 模型结构验证（sanity check）—— 只在 rank0 执行，可开关控制 ★★★
    if do_sanity_check and is_rank0():
        for i in range(sanity_check_iters):
            if sanity_check_iters > 1:
                print(f"\n--- Sanity Check Iter {i+1}/{sanity_check_iters} ---")
            sanity_check_model(model, verbose=True)
            sanity_check_shapes(model, device=DEVICE, H=IMG_SIZE, W=IMG_SIZE, K=K_SHOT, N=N_QUERY, verbose=True)

    best_val_dice = 0.0
    no_improve = 0
    
    save_path = os.path.join("checkpoints", "fewshot_camo_protoformer_tta.pth")
    os.makedirs("checkpoints", exist_ok=True)

    print(f"设备: {DEVICE}")
    print(f"K-shot: {K_SHOT}")
    print(f"训练集场景数: {len(set(x[2] for x in base_train_items))}")
    print(f"验证集样本数: {len(base_val_items)}")
    
    # 统计参数
    total_params = sum(p.numel() for p in model.parameters())
    adapter_params = model.count_tta_params("adapter_only")
    bridge_params = sum(p.numel() for p in model.get_bridge_params())
    print(f"总参数: {total_params/1e6:.2f}M")
    print(f"Adapter 参数: {adapter_params:,}")
    print(f"Bridge 参数: {bridge_params:,}")
    
    # ★★★ 打印 Bridge 配置（低方差版本确认）★★★
    if hasattr(model, 'bridge'):
        print(f"\n[Bridge 配置] nfg={model.bridge.nfg}, nbg={model.bridge.nbg}, nedge={model.bridge.nedge}")
        print(f"[Memory 策略] per-shot fixed sampling + mean 聚合 (低方差版本)")
    
    print(f"边界损失: enabled (weight=0.2)")
    print(f"早停 patience: {PATIENCE}")
    print("="*60)

    for epoch in range(num_epochs):
        model.train()
        running_loss = 0.0

        for step, batch in enumerate(train_loader):
            if step >= steps_per_epoch:
                break
                
            supp_imgs, supp_masks, qry_imgs, qry_masks, scene = batch
            
            supp_imgs = supp_imgs.squeeze(0).to(DEVICE)
            supp_masks = supp_masks.squeeze(0).to(DEVICE)
            qry_imgs = qry_imgs.squeeze(0).to(DEVICE)
            qry_masks = qry_masks.squeeze(0).to(DEVICE)

            optimizer.zero_grad()
            
            out, logits, guides = model(supp_imgs, supp_masks, qry_imgs)
            loss = criterion(logits, qry_masks)
            
            loss.backward()
            optimizer.step()

            running_loss += loss.item()

        scheduler.step()
        avg_loss = running_loss / steps_per_epoch

        # 验证
        metrics = evaluate_on_val(model, base_val_items, base_train_items, DEVICE)
        val_dice = metrics['Dice']

        print(f"Epoch [{epoch+1:2d}/{num_epochs}] "
              f"Loss: {avg_loss:.4f} | "
              f"Val Dice: {val_dice:.4f} | "
              f"mIoU: {metrics['mIoU']:.4f} | "
              f"S: {metrics['S_measure']:.4f}")

        if val_dice > best_val_dice:
            best_val_dice = val_dice
            no_improve = 0
            torch.save(model.state_dict(), save_path)
            print(f"  -> 新最佳! Dice={best_val_dice:.4f}")
        else:
            no_improve += 1
            if no_improve >= PATIENCE:
                print(f"\n早停触发! 连续{PATIENCE}轮无改进")
                break

    print(f"\n[ProtoFormerTTA] 训练完成, 最佳Dice: {best_val_dice:.4f}")
    return save_path


# =======================
# 主函数
# =======================

def main():
    import argparse
    parser = argparse.ArgumentParser(description='小样本伪装目标分割训练')
    parser.add_argument('--model', type=str, default='full', choices=['full', 'lite', 'protoformer'],
                        help='模型类型: full (完整版) / lite (轻量版) / protoformer (最终版)')
    parser.add_argument('--epochs', type=int, default=30, help='训练轮数')
    parser.add_argument('--steps', type=int, default=200, help='每轮步数')
    parser.add_argument('--lr', type=float, default=1e-4, help='学习率')
    parser.add_argument('--eval-only', action='store_true', help='仅评估')
    parser.add_argument('--use-tta', action='store_true', help='使用 TTA 评估')
    parser.add_argument('--tta-steps', type=int, default=10, help='TTA 步数')
    parser.add_argument('--tta-lr', type=float, default=1e-3, help='TTA 学习率')
    parser.add_argument('--tta-mode', type=str, default='adapter_only', 
                        choices=['adapter_only', 'adapter_plus_cross', 'adapter_plus_head'],
                        help='TTA 参数更新模式')
    
    # === Sanity Check 参数 ===
    parser.add_argument('--sanity-check', type=int, default=1, choices=[0, 1],
                        help='是否执行 sanity check (0=关闭, 1=开启, 默认 1)')
    parser.add_argument('--sanity-check-iters', type=int, default=1,
                        help='sanity check 运行次数 (默认 1)')
    
    args = parser.parse_args()
    
    print("="*60)
    print("FewShotCamouflageSeg 训练/评估")
    print("="*60)
    print(f"模型类型: {args.model}")
    print(f"设备: {DEVICE}")
    print(f"Sanity Check: {'ON' if args.sanity_check else 'OFF'}")
    
    if not args.eval_only:
        # 1. 训练
        if args.model == 'protoformer':
            train_protoformer_tta(
                num_epochs=args.epochs,
                steps_per_epoch=args.steps,
                lr=args.lr,
                do_sanity_check=bool(args.sanity_check),
                sanity_check_iters=args.sanity_check_iters
            )
        else:
            train_base(
                model_type=args.model,
                num_epochs=args.epochs,
                steps_per_epoch=args.steps,
                lr=args.lr
            )
    
    # 2. 评估
    if args.use_tta:
        evaluate_novel_with_tta(
            tta_steps=args.tta_steps,
            tta_lr=args.tta_lr,
            tta_prox_lambda=1e-4,
            tta_param_mode=args.tta_mode,
            use_tta_aug=True,
        )
    else:
        if args.model == 'protoformer':
            # 先评估无 TTA，再评估有 TTA
            evaluate_novel(model_type='full')
            print("\n" + "-"*60)
            print("下面使用 TTA 评估...")
            print("-"*60)
            evaluate_novel_with_tta(
                tta_steps=args.tta_steps,
                tta_lr=args.tta_lr,
                tta_prox_lambda=1e-4,
                tta_param_mode=args.tta_mode,
                use_tta_aug=True,
            )
        else:
            evaluate_novel(model_type=args.model)


if __name__ == "__main__":
    main()
