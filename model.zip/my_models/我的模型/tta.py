# -*- coding: utf-8 -*-
"""
Test-Time Adaptation (TTA) 模块

Support-conditioned TTA：
- 在每个 episode 的 meta-test 时，利用带标签的 support set 进行少量梯度更新
- 只更新小参数集（Adapter 或 Decoder），保持主干冻结
- 每个 episode 结束后恢复原始参数，确保 episode 间不污染

论文表述：
"We perform support-conditioned test-time adaptation by optimizing a small set 
of adapter parameters using the labeled support set for a few gradient steps."
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
import random
from typing import Optional, Callable, List, Tuple, Dict


# ==================== Adapter 模块 ====================

class Adapter(nn.Module):
    """
    轻量级 Bottleneck Adapter
    
    结构：1x1 Conv (down) → ReLU → 1x1 Conv (up)
    使用残差连接，初始化时接近恒等映射
    
    Args:
        in_ch: 输入通道数
        reduction: 降维比例，中间通道数 = in_ch // reduction
    """
    def __init__(self, in_ch: int, reduction: int = 16):
        super().__init__()
        mid_ch = max(in_ch // reduction, 8)  # 至少保留 8 通道
        
        self.down = nn.Conv2d(in_ch, mid_ch, kernel_size=1, bias=False)
        self.act = nn.ReLU(inplace=True)
        self.up = nn.Conv2d(mid_ch, in_ch, kernel_size=1, bias=False)
        
        # 初始化：让 up 权重为零，使初始输出 = x + 0 = x（恒等）
        nn.init.zeros_(self.up.weight)
        # down 使用正常初始化
        nn.init.kaiming_normal_(self.down.weight, mode='fan_out', nonlinearity='relu')
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """残差连接：x + adapter(x)"""
        return x + self.up(self.act(self.down(x)))


class AdapterBlock(nn.Module):
    """
    可开关的 Adapter 封装
    
    Args:
        in_ch: 输入通道数
        reduction: 降维比例
        enabled: 是否启用 adapter
    """
    def __init__(self, in_ch: int, reduction: int = 16, enabled: bool = True):
        super().__init__()
        self.enabled = enabled
        if enabled:
            self.adapter = Adapter(in_ch, reduction)
        else:
            self.adapter = None
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.enabled and self.adapter is not None:
            return self.adapter(x)
        return x


# ==================== TTA 增强函数 ====================

class TTAAugmentation:
    """
    TTA 时对 support 的轻量增强
    
    帮助防止过拟合到 support 的像素细节
    """
    def __init__(self, 
                 flip_prob: float = 0.5,
                 scale_range: Tuple[float, float] = (0.9, 1.1),
                 brightness_range: Tuple[float, float] = (0.9, 1.1),
                 contrast_range: Tuple[float, float] = (0.9, 1.1)):
        self.flip_prob = flip_prob
        self.scale_range = scale_range
        self.brightness_range = brightness_range
        self.contrast_range = contrast_range
    
    def __call__(self, img: torch.Tensor, mask: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Args:
            img: (K, 3, H, W) or (1, 3, H, W)
            mask: (K, 1, H, W) or (1, 1, H, W)
        
        Returns:
            augmented img and mask
        """
        # 水平翻转
        if random.random() < self.flip_prob:
            img = torch.flip(img, dims=[-1])
            mask = torch.flip(mask, dims=[-1])
        
        # 随机缩放（需要保持尺寸一致，用 padding）
        if self.scale_range[0] < 1.0 or self.scale_range[1] > 1.0:
            scale = random.uniform(*self.scale_range)
            if scale != 1.0:
                _, _, H, W = img.shape
                new_H, new_W = int(H * scale), int(W * scale)
                
                # 缩放
                img_scaled = F.interpolate(img, size=(new_H, new_W), mode='bilinear', align_corners=False)
                mask_scaled = F.interpolate(mask, size=(new_H, new_W), mode='nearest')
                
                # 裁剪或填充回原始尺寸
                if scale > 1.0:
                    # 中心裁剪
                    start_h = (new_H - H) // 2
                    start_w = (new_W - W) // 2
                    img = img_scaled[:, :, start_h:start_h+H, start_w:start_w+W]
                    mask = mask_scaled[:, :, start_h:start_h+H, start_w:start_w+W]
                else:
                    # 中心填充
                    pad_h = (H - new_H) // 2
                    pad_w = (W - new_W) // 2
                    img = F.pad(img_scaled, (pad_w, W-new_W-pad_w, pad_h, H-new_H-pad_h), mode='reflect')
                    mask = F.pad(mask_scaled, (pad_w, W-new_W-pad_w, pad_h, H-new_H-pad_h), mode='constant', value=0)
        
        # 亮度和对比度（仅对图像）
        if self.brightness_range[0] < 1.0 or self.brightness_range[1] > 1.0:
            brightness = random.uniform(*self.brightness_range)
            img = img * brightness
            img = torch.clamp(img, -3, 3)  # 防止过大值（假设已归一化）
        
        if self.contrast_range[0] < 1.0 or self.contrast_range[1] > 1.0:
            contrast = random.uniform(*self.contrast_range)
            mean = img.mean(dim=(2, 3), keepdim=True)
            img = (img - mean) * contrast + mean
            img = torch.clamp(img, -3, 3)
        
        return img, mask


# ==================== TTA Loss ====================

def bce_dice_loss(logit: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    """
    BCE + Dice Loss
    
    Args:
        logit: (B, 1, H, W) 未经 sigmoid 的预测
        target: (B, 1, H, W) 二值 mask
    
    Returns:
        scalar loss
    """
    prob = torch.sigmoid(logit)
    
    # BCE
    bce = F.binary_cross_entropy_with_logits(logit, target)
    
    # Dice
    eps = 1e-6
    inter = (prob * target).sum(dim=(2, 3))
    union = (prob + target).sum(dim=(2, 3))
    dice = 1 - (2 * inter + eps) / (union + eps)
    dice = dice.mean()
    
    return bce + dice


def make_soft_edge(prob: torch.Tensor, k: int = 7) -> torch.Tensor:
    """
    从概率图生成软边界（用于边界损失）
    
    使用形态学膨胀-腐蚀得到边界区域
    
    Args:
        prob: (B, 1, H, W) 概率图 [0, 1]
        k: 卷积核大小
    
    Returns:
        edge: (B, 1, H, W) 边界概率图
    """
    pad = k // 2
    # 膨胀操作：max_pool
    dil = F.max_pool2d(prob, kernel_size=k, stride=1, padding=pad)
    # 腐蚀操作：1 - max_pool(1 - prob)
    ero = 1.0 - F.max_pool2d(1.0 - prob, kernel_size=k, stride=1, padding=pad)
    # 边界 = 膨胀 - 腐蚀
    edge = (dil - ero).clamp(0, 1)
    return edge


def bce_dice_edge_loss(
    logit: torch.Tensor, 
    target: torch.Tensor,
    edge_weight: float = 0.2,
    edge_kernel: int = 7
) -> torch.Tensor:
    """
    BCE + Dice + 边界 Loss
    
    伪装目标分割的关键：边界对齐！
    
    Args:
        logit: (B, 1, H, W) 未经 sigmoid 的预测
        target: (B, 1, H, W) 二值 mask
        edge_weight: 边界损失权重（默认 0.2）
        edge_kernel: 边界 mask 卷积核大小
    
    Returns:
        scalar loss
    """
    prob = torch.sigmoid(logit)
    
    # === 主损失：BCE + Dice ===
    bce = F.binary_cross_entropy_with_logits(logit, target)
    
    eps = 1e-6
    inter = (prob * target).sum(dim=(2, 3))
    union = (prob + target).sum(dim=(2, 3))
    dice = 1 - (2 * inter + eps) / (union + eps)
    dice = dice.mean()
    
    main_loss = bce + dice
    
    # === 边界损失 ===
    if edge_weight > 0:
        # 从 GT 和 pred 生成边界
        edge_gt = make_soft_edge(target, k=edge_kernel)     # (B, 1, H, W)
        edge_pred = make_soft_edge(prob, k=edge_kernel)     # (B, 1, H, W)
        
        # 边界区域的 BCE + Dice
        edge_bce = F.binary_cross_entropy(edge_pred, edge_gt)
        
        edge_inter = (edge_pred * edge_gt).sum(dim=(2, 3))
        edge_union = (edge_pred + edge_gt).sum(dim=(2, 3))
        edge_dice = 1 - (2 * edge_inter + eps) / (edge_union + eps)
        edge_dice = edge_dice.mean()
        
        edge_loss = edge_bce + edge_dice
        
        return main_loss + edge_weight * edge_loss
    
    return main_loss


# ==================== 参数管理工具 ====================

def clone_state_dict(model: nn.Module) -> Dict[str, torch.Tensor]:
    """深拷贝模型参数（用于 TTA 后恢复）"""
    return {k: v.detach().clone() for k, v in model.state_dict().items()}


def restore_state_dict(model: nn.Module, state: Dict[str, torch.Tensor]) -> None:
    """恢复模型参数"""
    model.load_state_dict(state, strict=True)


def get_tta_params(model: nn.Module, mode: str = "adapter") -> List[torch.nn.Parameter]:
    """
    获取 TTA 时需要更新的参数
    
    Args:
        model: FewShotCamouflageSeg 模型
        mode: 
            - "adapter": 只更新 adapter 参数（最稳定）
            - "decoder": 更新整个 decoder
            - "decoder_head": 只更新 decoder 的预测头 (h2, h3, h4, h5)
    
    Returns:
        参数列表
    """
    params = []
    
    if mode == "adapter":
        # 只更新包含 "adapter" 的参数
        for name, param in model.named_parameters():
            if "adapter" in name.lower() and param.requires_grad:
                params.append(param)
    
    elif mode == "decoder":
        # 更新整个 decoder
        if hasattr(model, 'decoder'):
            for param in model.decoder.parameters():
                if param.requires_grad:
                    params.append(param)
    
    elif mode == "decoder_head":
        # 只更新 decoder 的预测头
        if hasattr(model, 'decoder'):
            for name, param in model.decoder.named_parameters():
                if any(h in name for h in ['h2', 'h3', 'h4', 'h5']):
                    if param.requires_grad:
                        params.append(param)
    
    else:
        raise ValueError(f"Unknown TTA mode: {mode}. Choose from 'adapter', 'decoder', 'decoder_head'")
    
    return params


# ==================== TTA 推理主函数 ====================

def tta_inference(
    model: nn.Module,
    support_imgs: torch.Tensor,
    support_masks: torch.Tensor,
    query_img: torch.Tensor,
    steps: int = 10,
    lr: float = 1e-3,
    mode: str = "adapter",
    aug_fn: Optional[Callable] = None,
    prox_lambda: float = 1e-4,
    leave_one_out: bool = True,
) -> torch.Tensor:
    """
    Episode 级 Test-Time Adaptation
    
    流程：
    1. 保存原始模型参数
    2. 选择要更新的参数（adapter/decoder）
    3. 用 support set 进行若干步梯度更新
    4. 用更新后的模型对 query 进行推理
    5. 恢复原始参数（保证下一 episode 不被污染）
    
    Args:
        model: FewShotCamouflageSeg 模型
        support_imgs: (K, 3, H, W) K-shot support 图像
        support_masks: (K, 1, H, W) support masks
        query_img: (B, 3, H, W) query 图像
        steps: TTA 优化步数
        lr: 学习率
        mode: 更新模式 ("adapter", "decoder", "decoder_head")
        aug_fn: 可选的增强函数，对 support 进行增强
        prox_lambda: proximal 正则化系数（防止参数偏离太远）
        leave_one_out: 是否使用 leave-one-out 策略（更泛化）
    
    Returns:
        pred: (B, 1, H, W) query 的预测 logits
    """
    device = query_img.device
    model.eval()
    
    # 确保 support_masks 是 4D
    if support_masks.dim() == 3:
        support_masks = support_masks.unsqueeze(1)
    
    # 1. 保存原始权重
    base_state = clone_state_dict(model)
    
    # 2. 选择要更新的参数
    tta_params = get_tta_params(model, mode=mode)
    
    if len(tta_params) == 0:
        # 没有可更新的参数，直接推理
        with torch.no_grad():
            pred, _, _ = model(support_imgs, support_masks, query_img)
        return pred
    
    # 冻结所有参数
    for p in model.parameters():
        p.requires_grad_(False)
    # 解冻 TTA 参数
    for p in tta_params:
        p.requires_grad_(True)
    
    # 3. 设置优化器
    optimizer = torch.optim.Adam(tta_params, lr=lr, weight_decay=0.0)
    
    # 记录初始参数用于 proximal 正则
    theta0 = [p.detach().clone() for p in tta_params]
    
    K = support_imgs.shape[0]  # shot 数
    
    # 4. TTA 优化循环
    for step in range(steps):
        optimizer.zero_grad()
        
        # 可选的数据增强
        s_img = support_imgs
        s_msk = support_masks
        if aug_fn is not None:
            s_img, s_msk = aug_fn(s_img, s_msk)
        
        total_loss = 0.0
        
        if leave_one_out and K > 1:
            # Leave-one-out 策略：每次把一张 support 当 query，其余当 support
            # 这样更泛化，避免记住某张 support 的像素细节
            for i in range(K):
                q = s_img[i:i+1]       # 当前这张作为 "query"
                q_gt = s_msk[i:i+1]
                
                # 其他张作为 support
                sup_idx = [j for j in range(K) if j != i]
                sup = s_img[sup_idx]
                sup_m = s_msk[sup_idx]
                
                out, logits_dict, _ = model(sup, sup_m, q)
                total_loss = total_loss + bce_dice_loss(out, q_gt)
            
            total_loss = total_loss / K
        else:
            # 简单策略：直接用所有 support 做 self-supervised
            # 把 support 自己当 query
            for i in range(K):
                q = s_img[i:i+1]
                q_gt = s_msk[i:i+1]
                
                out, logits_dict, _ = model(s_img, s_msk, q)
                total_loss = total_loss + bce_dice_loss(out, q_gt)
            
            total_loss = total_loss / K
        
        # Proximal 正则：防止参数偏离原始模型太远
        if prox_lambda > 0:
            prox = 0.0
            for p, p0 in zip(tta_params, theta0):
                prox = prox + (p - p0).pow(2).mean()
            total_loss = total_loss + prox_lambda * prox
        
        total_loss.backward()
        optimizer.step()
    
    # 5. 用更新后的参数推理 query
    with torch.no_grad():
        pred, _, _ = model(support_imgs, support_masks, query_img)
    
    # 6. 恢复原始参数
    restore_state_dict(model, base_state)
    
    return pred


# ==================== 改进的 TTA 推理（支持更多参数模式）====================

def tta_predict_episode(
    model: nn.Module,
    support_imgs: torch.Tensor,
    support_masks: torch.Tensor,
    query_img: torch.Tensor,
    steps: int = 10,
    lr: float = 1e-3,
    prox_lambda: float = 1e-4,
    param_mode: str = "adapter_only",
    aug_fn: Optional[Callable] = None,
    use_multiscale_loss: bool = False,
) -> torch.Tensor:
    """
    Episode 级 TTA 推理（改进版）
    
    特点：
    1. 支持更多参数模式: adapter_only, adapter_plus_cross, adapter_plus_head
    2. Leave-one-out 策略：更稳、不会死记 support
    3. Proximal 正则：保持接近初始模型
    4. 可选多尺度损失
    
    默认推荐超参：
    - steps=10
    - lr=1e-3
    - prox_lambda=1e-4
    - param_mode="adapter_only"（跑通后再冲 "adapter_plus_cross"）
    
    Args:
        model: FewShotCamouflageSeg_ProtoFormerTTA 模型
        support_imgs: (K, 3, H, W) K-shot support 图像
        support_masks: (K, 1, H, W) support masks
        query_img: (B, 3, H, W) query 图像
        steps: TTA 优化步数
        lr: 学习率
        prox_lambda: proximal 正则化系数
        param_mode: 参数更新模式
            - "adapter_only": 只更新 decoder.adapter (最稳定)
            - "adapter_plus_cross": adapter + bridge.cross 的投影层 (更强)
            - "adapter_plus_head": adapter + decoder 预测头
        aug_fn: 可选的 support 增强函数
        use_multiscale_loss: 是否使用多尺度损失
    
    Returns:
        pred: (B, 1, H, W) query 的预测 logits
    """
    device = query_img.device
    model.eval()
    
    # 确保 support_masks 是 4D
    if support_masks.dim() == 3:
        support_masks = support_masks.unsqueeze(1)
    
    # 1. 保存原始权重
    base_state = clone_state_dict(model)
    
    # 2. 冻结所有参数
    for p in model.parameters():
        p.requires_grad_(False)
    
    # 3. 选择要更新的参数
    tta_params = get_tta_params_advanced(model, mode=param_mode)
    
    if len(tta_params) == 0:
        # 没有可更新的参数，直接推理
        with torch.no_grad():
            pred, _, _ = model(support_imgs, support_masks, query_img)
        return pred
    
    # 解冻 TTA 参数
    for p in tta_params:
        p.requires_grad_(True)
    
    # 4. 设置优化器
    optimizer = torch.optim.Adam(tta_params, lr=lr, weight_decay=0.0)
    
    # 记录初始参数用于 proximal 正则
    theta0 = [p.detach().clone() for p in tta_params]
    
    K = support_imgs.shape[0]  # shot 数
    
    # 5. TTA 优化循环 (Leave-one-out)
    for step in range(steps):
        optimizer.zero_grad()
        
        # 可选的数据增强
        s_img = support_imgs
        s_msk = support_masks
        if aug_fn is not None:
            s_img, s_msk = aug_fn(s_img, s_msk)
        
        total_loss = 0.0
        
        # Leave-one-out 策略
        for i in range(K):
            q = s_img[i:i+1]       # 当前这张作为 "query"
            q_gt = s_msk[i:i+1]
            
            # 其他张作为 support
            sup = torch.cat([s_img[:i], s_img[i+1:]], dim=0)
            sup_m = torch.cat([s_msk[:i], s_msk[i+1:]], dim=0)
            
            out, logits_dict, _ = model(sup, sup_m, q)
            
            if use_multiscale_loss:
                # 多尺度损失
                loss = bce_dice_loss(out, q_gt)
                for lvl_name in ["log3", "log4", "log5"]:
                    if lvl_name in logits_dict:
                        lvl_logit = logits_dict[lvl_name]
                        lvl_gt = F.interpolate(q_gt, size=lvl_logit.shape[-2:], mode="nearest")
                        loss = loss + 0.5 * bce_dice_loss(lvl_logit, lvl_gt)
                total_loss = total_loss + loss
            else:
                total_loss = total_loss + bce_dice_loss(out, q_gt)
        
        total_loss = total_loss / K
        
        # Proximal 正则：保持接近初始参数
        if prox_lambda > 0:
            prox = 0.0
            for p, p0 in zip(tta_params, theta0):
                prox = prox + (p - p0).pow(2).mean()
            total_loss = total_loss + prox_lambda * prox
        
        total_loss.backward()
        optimizer.step()
    
    # 6. 用更新后的参数推理 query
    with torch.no_grad():
        pred, _, _ = model(support_imgs, support_masks, query_img)
    
    # 7. 恢复原始参数
    restore_state_dict(model, base_state)
    
    return pred


def get_tta_params_advanced(model: nn.Module, mode: str = "adapter_only") -> List[torch.nn.Parameter]:
    """
    获取 TTA 参数（高级版）
    
    Args:
        model: FewShotCamouflageSeg_ProtoFormerTTA 模型
        mode:
            - "adapter_only": 只更新 decoder.adapter (最稳定)
            - "adapter_plus_cross": adapter + bridge.cross 的 Q/K/V/Out 投影层 (更强)
            - "adapter_plus_head": adapter + decoder 预测头
    
    Returns:
        参数列表
    """
    params = []
    
    if mode == "adapter_only":
        for name, p in model.named_parameters():
            if "decoder" in name and "adapter" in name:
                params.append(p)
    
    elif mode == "adapter_plus_cross":
        for name, p in model.named_parameters():
            # Decoder adapter
            if "decoder" in name and "adapter" in name:
                params.append(p)
            # Bridge cross attention 投影层
            elif "bridge" in name and "cross" in name:
                if any(x in name for x in ["q_proj", "k_proj", "v_proj", "out_proj"]):
                    params.append(p)
    
    elif mode == "adapter_plus_head":
        for name, p in model.named_parameters():
            # Decoder adapter
            if "decoder" in name and "adapter" in name:
                params.append(p)
            # Decoder heads (h2, h3, h4, h5)
            elif "decoder" in name and any(h in name for h in ["h2", "h3", "h4", "h5"]):
                params.append(p)
    
    else:
        raise ValueError(f"Unknown mode: {mode}. Choose from 'adapter_only', 'adapter_plus_cross', 'adapter_plus_head'")
    
    return params


# ==================== 批量 TTA 评估 ====================

def tta_evaluate_episode(
    model: nn.Module,
    support_imgs: torch.Tensor,
    support_masks: torch.Tensor,
    query_imgs: torch.Tensor,
    query_masks: torch.Tensor,
    tta_config: dict = None,
) -> Tuple[torch.Tensor, Dict[str, float]]:
    """
    对一个 episode 进行 TTA 评估
    
    Args:
        model: FewShotCamouflageSeg 模型
        support_imgs: (K, 3, H, W)
        support_masks: (K, 1, H, W)
        query_imgs: (N_query, 3, H, W)
        query_masks: (N_query, 1, H, W)
        tta_config: TTA 配置字典，包含 steps, lr, mode, prox_lambda 等
    
    Returns:
        preds: (N_query, 1, H, W) 预测结果
        metrics: 该 episode 的指标
    """
    if tta_config is None:
        tta_config = {
            'steps': 10,
            'lr': 1e-3,
            'mode': 'adapter',
            'prox_lambda': 1e-4,
            'use_aug': True,
        }
    
    # 创建增强函数
    aug_fn = None
    if tta_config.get('use_aug', True):
        aug_fn = TTAAugmentation(
            flip_prob=0.5,
            scale_range=(0.9, 1.1),
            brightness_range=(0.95, 1.05),
            contrast_range=(0.95, 1.05),
        )
    
    # 对每个 query 进行 TTA 推理
    preds = []
    for i in range(query_imgs.shape[0]):
        q_img = query_imgs[i:i+1]
        
        pred = tta_inference(
            model=model,
            support_imgs=support_imgs,
            support_masks=support_masks,
            query_img=q_img,
            steps=tta_config.get('steps', 10),
            lr=tta_config.get('lr', 1e-3),
            mode=tta_config.get('mode', 'adapter'),
            aug_fn=aug_fn,
            prox_lambda=tta_config.get('prox_lambda', 1e-4),
            leave_one_out=tta_config.get('leave_one_out', True),
        )
        preds.append(pred)
    
    preds = torch.cat(preds, dim=0)  # (N_query, 1, H, W)
    
    # 计算简单指标（可扩展）
    probs = torch.sigmoid(preds)
    binary_preds = (probs > 0.5).float()
    
    # IoU
    inter = (binary_preds * query_masks).sum()
    union = binary_preds.sum() + query_masks.sum() - inter
    iou = (inter + 1e-6) / (union + 1e-6)
    
    # Dice
    dice = (2 * inter + 1e-6) / (binary_preds.sum() + query_masks.sum() + 1e-6)
    
    metrics = {
        'iou': iou.item(),
        'dice': dice.item(),
    }
    
    return preds, metrics


# ==================== 测试代码 ====================

if __name__ == "__main__":
    print("Testing TTA module...")
    
    # 测试 Adapter
    adapter = Adapter(256, reduction=16)
    x = torch.randn(2, 256, 32, 32)
    y = adapter(x)
    print(f"Adapter test: input {x.shape} -> output {y.shape}")
    
    # 初始化时应该接近恒等
    diff = (y - x).abs().mean().item()
    print(f"Initial adapter output diff from input: {diff:.6f} (should be ~0)")
    
    # 测试增强
    aug = TTAAugmentation()
    img = torch.randn(5, 3, 256, 256)
    mask = torch.randint(0, 2, (5, 1, 256, 256)).float()
    img_aug, mask_aug = aug(img, mask)
    print(f"Augmentation test: img {img.shape} -> {img_aug.shape}, mask {mask.shape} -> {mask_aug.shape}")
    
    print("\nTTA module test passed!")
