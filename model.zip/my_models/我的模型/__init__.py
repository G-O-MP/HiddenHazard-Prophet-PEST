# -*- coding: utf-8 -*-
"""
小样本伪装目标分割模型包

核心模块：
- modules.py: 基础模块（原型构建、引导图生成）
- encoder_decoder.py: ResNet编码器 + C2F解码器
- cross_attention.py: DyT + Cross-Attention Bridge
- fewshot_camouflage_seg.py: 完整模型框架
- tta.py: Test-Time Adaptation 模块
"""

from .modules import (
    l2norm,
    ConvBNReLU,
    make_edge_mask,
    MaskedAvgPool,
    ProtoMatcher,
    TokenProtoBuilder,
    ProtoBuilder,
    GuideBuilder,
)

from .encoder_decoder import (
    ResNetEncoder,
    C2FDecoder,
    C2FDecoderWithAdapter,
)

from .cross_attention import (
    DyT,
    CrossAttentionDyT,
    ProtoFormerBridge,
    sample_tokens,
    build_support_memory,
    TypeEmbedding,
)

from .fewshot_camouflage_seg import (
    FewShotCamouflageSeg,
    FewShotCamouflageSeg_Lite,
    FewShotCamouflageSeg_CrossAttn,
    FewShotCamouflageSeg_ProtoFormerTTA,
    FS_CamoSeg_Model,
    freeze_encoder_bn,
)

from .tta import (
    Adapter,
    TTAAugmentation,
    bce_dice_loss,
    bce_dice_edge_loss,
    tta_inference,
    tta_predict_episode,
    get_tta_params_advanced,
)

__all__ = [
    # modules
    'l2norm', 'ConvBNReLU', 'make_edge_mask',
    'MaskedAvgPool', 'ProtoMatcher', 'TokenProtoBuilder',
    'ProtoBuilder', 'GuideBuilder',
    # encoder_decoder
    'ResNetEncoder', 'C2FDecoder', 'C2FDecoderWithAdapter',
    # cross_attention
    'DyT', 'CrossAttentionDyT', 'ProtoFormerBridge',
    'sample_tokens', 'build_support_memory', 'TypeEmbedding',
    # fewshot_camouflage_seg
    'FewShotCamouflageSeg', 'FewShotCamouflageSeg_Lite',
    'FewShotCamouflageSeg_CrossAttn', 'FewShotCamouflageSeg_ProtoFormerTTA',
    'FS_CamoSeg_Model', 'freeze_encoder_bn',
    # tta
    'Adapter', 'TTAAugmentation',
    'bce_dice_loss', 'bce_dice_edge_loss',
    'tta_inference', 'tta_predict_episode', 'get_tta_params_advanced',
]
