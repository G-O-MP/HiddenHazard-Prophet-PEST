# -*- coding: utf-8 -*-
"""
实验模块

包含：
- exp_5_2_detection_comparison: 模型检测性能对比分析
- exp_5_3_camouflage_analysis: 伪装目标检测效果分析
- exp_5_4_fewshot_generalization: 小样本泛化能力验证
"""
