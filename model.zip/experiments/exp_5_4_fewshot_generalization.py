# -*- coding: utf-8 -*-
"""
实验5.4：小样本泛化能力验证

回答的问题：
"样本很少的时候，我的方法还能不能快速适配新虫种/新场景？"

实验设置：
- 1-shot / 3-shot / 5-shot
- Base / Novel 类拆分
- Leave-one-class-out 验证

指标建议：
- F1
- mIoU / Dice
- 适配时间
- 新类别性能

这是核心创新验证。
"""
import os
import sys
import random
import warnings
import time
import json
from collections import defaultdict
warnings.filterwarnings('ignore')

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, PROJECT_ROOT)

import numpy as np
from PIL import Image
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms

try:
    from utils.metrics_cod import compute_all_metrics, MetricAccumulator
except ImportError:
    sys.path.insert(0, os.path.join(PROJECT_ROOT, 'utils'))
    from metrics_cod import compute_all_metrics, MetricAccumulator


# =======================
# 配置
# =======================
DATA_ROOT = r"d:\University\竞赛\4C\智慧农林\模型代码\数据集\数据集"
IMG_SIZE = 512
BATCH_SIZE = 4
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
SEED = 42
RESULTS_DIR = os.path.join(PROJECT_ROOT, "experiment_results", "exp_5_4")
os.makedirs(RESULTS_DIR, exist_ok=True)

random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)


# =======================
# IP02类别名称
# =======================
IP02_CLASSES = [
    "rice leaf roller", "rice leaf caterpillar", "paddy stem maggot", "asiatic rice borer",
    "yellow rice borer", "rice gall midge", "Rice Stemfly", "brown plant hopper",
    "white backed plant hopper", "small brown plant hopper", "rice water weevil", "rice leafhopper",
    "grain spreader thrips", "rice shell pest", "grub", "mole cricket",
    "wireworm", "white margined moth", "black cutworm", "large cutworm",
    "yellow cutworm", "red spider", "corn borer", "army worm",
    "aphids", "Potosiabre vitarsis", "peach borer", "english grain aphid",
    "green bug", "bird cherry-oataphid", "wheat blossom midge", "penthaleus major",
    "longlegged spider mite", "wheat phloeothrips", "wheat sawfly", "cerodonta denticornis",
    "beet fly", "flea beetle", "cabbage army worm", "beet army worm",
    "Beet spot flies", "meadow moth", "beet weevil", "sericaorient alismots chulsky",
    "alfalfa weevil", "flax budworm", "alfalfa plant bug", "tarnished plant bug",
    "Locustoidea", "lytta polita", "legume blister beetle", "blister beetle",
    "therioaphis maculata Buckton", "odontothrips loti", "Thrips", "alfalfa seed chalcid",
    "Pieris canidia", "Apolygus lucorum", "Limacodidae", "Viteus vitifoliae",
    "Colomerus vitis", "Brevipoalpus lewisi McGregor", "oides decempunctata", "Polyphagotars onemus latus",
    "Pseudococcus comstocki Kuwana", "parathrene regalis", "Ampelophaga", "Lycorma delicatula",
    "Xylotrechus", "Cicadella viridis", "Miridae", "Trialeurodes vaporariorum",
    "Erythroneura apicalis", "Papilio xuthus", "Panonchus citri McGregor", "Phyllocoptes oleiverus ashmead",
    "Icerya purchasi Maskell", "Unaspis yanonensis", "Ceroplastes rubens", "Chrysomphalus aonidum",
    "Parlatoria zizyphus Lucus", "Nipaecoccus vastalor", "Aleurocanthus spiniferus", "Tetradacus c Bactrocera minax",
    "Dacus dorsalis(Hendel)", "Bactrocera tsuneonis", "Prodenia litura", "Adristyrannus",
    "Phyllocnistis citrella Stainton", "Toxoptera citricidus", "Toxoptera aurantii", "Aphis citricola Vander Goot",
    "Scirtothrips dorsalis Hood", "Dasineura sp", "Lawana imitata Melichar", "Salurnis marginella Guerr",
    "Deporaus marginatus Pascoe", "Chlumetia transversa", "Mango flat beak leafhopper", "Rhytidodera bowrinii white",
    "Sternochetus frigidus", "Cicadellidae"
]


# =======================
# 数据集
# =======================
class FewShotPestDataset(Dataset):
    """小样本虫害数据集"""
    
    def __init__(self, data_root, split='train', img_size=512, k_shot=5, n_query=5):
        self.data_root = data_root
        self.img_size = img_size
        self.k_shot = k_shot
        self.n_query = n_query
        self.split = split
        
        self.dataset_path = os.path.join(data_root, "Agricultural Pests Image Dataset", "archive")
        
        self.classes = ['ants', 'bees']
        self.class_to_idx = {c: i for i, c in enumerate(self.classes)}
        
        self.samples_by_class = self._load_samples()
        
        self.to_tensor = transforms.ToTensor()
        self.normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        
        self.transform = transforms.Compose([
            transforms.RandomHorizontalFlip(p=0.5),
            transforms.RandomRotation(15),
            transforms.ColorJitter(brightness=0.2, contrast=0.2)
        ])
    
    def _load_samples(self):
        samples_by_class = {c: [] for c in self.classes}
        
        for class_name in self.classes:
            class_dir = os.path.join(self.dataset_path, class_name)
            if os.path.exists(class_dir):
                for fname in os.listdir(class_dir):
                    if fname.lower().endswith(('.jpg', '.jpeg', '.png')):
                        samples_by_class[class_name].append({
                            'img_path': os.path.join(class_dir, fname),
                            'class_id': self.class_to_idx[class_name]
                        })
        
        return samples_by_class
    
    def __len__(self):
        return 100
    
    def __getitem__(self, idx):
        class_name = random.choice(self.classes)
        samples = self.samples_by_class[class_name]
        
        if len(samples) < self.k_shot + self.n_query:
            samples = samples * ((self.k_shot + self.n_query) // len(samples) + 1)
        
        selected = random.sample(samples, self.k_shot + self.n_query)
        
        support_imgs = []
        support_masks = []
        query_imgs = []
        query_masks = []
        
        for i, sample in enumerate(selected):
            img = Image.open(sample['img_path']).convert("RGB")
            img = img.resize((self.img_size, self.img_size), Image.BILINEAR)
            
            mask = Image.new('L', (self.img_size, self.img_size), 255)
            
            if self.split == 'train' and i < self.k_shot:
                img = self.transform(img)
            
            img = self.to_tensor(img)
            img = self.normalize(img)
            
            mask = np.array(mask, dtype=np.float32)
            mask = (mask > 127.5).astype(np.float32)
            mask = torch.from_numpy(mask)
            
            if i < self.k_shot:
                support_imgs.append(img)
                support_masks.append(mask)
            else:
                query_imgs.append(img)
                query_masks.append(mask)
        
        return {
            'support_imgs': torch.stack(support_imgs),
            'support_masks': torch.stack(support_masks).unsqueeze(1),
            'query_imgs': torch.stack(query_imgs),
            'query_masks': torch.stack(query_masks).unsqueeze(1),
            'class_id': self.class_to_idx[class_name],
            'class_name': class_name
        }


class LeaveOneClassOutDataset(Dataset):
    """Leave-One-Class-Out数据集"""
    
    def __init__(self, data_root, img_size=512, k_shot=5, n_query=5, 
                 base_classes=None, novel_classes=None):
        self.data_root = data_root
        self.img_size = img_size
        self.k_shot = k_shot
        self.n_query = n_query
        
        self.dataset_path = os.path.join(data_root, "Agricultural Pests Image Dataset", "archive")
        
        self.all_classes = ['ants', 'bees']
        self.base_classes = base_classes or ['ants']
        self.novel_classes = novel_classes or ['bees']
        
        self.samples_by_class = self._load_samples()
        
        self.to_tensor = transforms.ToTensor()
        self.normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    
    def _load_samples(self):
        samples_by_class = {c: [] for c in self.all_classes}
        
        for class_name in self.all_classes:
            class_dir = os.path.join(self.dataset_path, class_name)
            if os.path.exists(class_dir):
                for fname in os.listdir(class_dir):
                    if fname.lower().endswith(('.jpg', '.jpeg', '.png')):
                        samples_by_class[class_name].append({
                            'img_path': os.path.join(class_dir, fname),
                            'class_name': class_name
                        })
        
        return samples_by_class
    
    def __len__(self):
        return 50
    
    def __getitem__(self, idx):
        is_novel = idx % 2 == 0
        class_name = random.choice(self.novel_classes if is_novel else self.base_classes)
        samples = self.samples_by_class[class_name]
        
        if len(samples) < self.k_shot + self.n_query:
            samples = samples * ((self.k_shot + self.n_query) // len(samples) + 1)
        
        selected = random.sample(samples, self.k_shot + self.n_query)
        
        support_imgs = []
        support_masks = []
        query_imgs = []
        query_masks = []
        
        for i, sample in enumerate(selected):
            img = Image.open(sample['img_path']).convert("RGB")
            img = img.resize((self.img_size, self.img_size), Image.BILINEAR)
            
            mask = Image.new('L', (self.img_size, self.img_size), 255)
            
            img = self.to_tensor(img)
            img = self.normalize(img)
            
            mask = np.array(mask, dtype=np.float32)
            mask = (mask > 127.5).astype(np.float32)
            mask = torch.from_numpy(mask)
            
            if i < self.k_shot:
                support_imgs.append(img)
                support_masks.append(mask)
            else:
                query_imgs.append(img)
                query_masks.append(mask)
        
        return {
            'support_imgs': torch.stack(support_imgs),
            'support_masks': torch.stack(support_masks).unsqueeze(1),
            'query_imgs': torch.stack(query_imgs),
            'query_masks': torch.stack(query_masks).unsqueeze(1),
            'class_name': class_name,
            'is_novel': is_novel
        }


# =======================
# 模型
# =======================
class ConvBNReLU(nn.Module):
    def __init__(self, in_c, out_c, k=3, s=1, p=1):
        super().__init__()
        self.conv = nn.Conv2d(in_c, out_c, kernel_size=k, stride=s, padding=p, bias=False)
        self.bn = nn.BatchNorm2d(out_c)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        return self.relu(self.bn(self.conv(x)))


class ProtoNetBaseline(nn.Module):
    """原型网络基线"""
    
    def __init__(self, backbone='resnet50'):
        super().__init__()
        from torchvision import models
        resnet = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V1)
        
        self.layer0 = nn.Sequential(resnet.conv1, resnet.bn1, resnet.relu, resnet.maxpool)
        self.layer1 = resnet.layer1
        self.layer2 = resnet.layer2
        self.layer3 = resnet.layer3
        self.layer4 = resnet.layer4
        
        self.feat_dim = 2048
        
        for param in self.layer0.parameters():
            param.requires_grad = False
        for param in self.layer1.parameters():
            param.requires_grad = False
    
    def extract_feat(self, x):
        x = self.layer0(x)
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        return x
    
    def get_prototype(self, supp_feat, supp_mask):
        K, C, Hf, Wf = supp_feat.shape
        
        supp_mask = F.interpolate(supp_mask, size=(Hf, Wf), mode='nearest')
        
        fg_mask = supp_mask
        bg_mask = 1.0 - fg_mask
        
        fg_feat = supp_feat * fg_mask
        fg_proto = fg_feat.sum(dim=(0, 2, 3)) / (fg_mask.sum(dim=(0, 2, 3)) + 1e-5)
        
        bg_feat = supp_feat * bg_mask
        bg_proto = bg_feat.sum(dim=(0, 2, 3)) / (bg_mask.sum(dim=(0, 2, 3)) + 1e-5)
        
        prototypes = torch.stack([bg_proto, fg_proto], dim=0)
        return prototypes
    
    def forward(self, support_imgs, support_masks, query_imgs):
        supp_feats = self.extract_feat(support_imgs)
        qry_feats = self.extract_feat(query_imgs)
        
        prototypes = self.get_prototype(supp_feats, support_masks)
        
        Qf, C, Hf, Wf = qry_feats.shape
        qry_flat = qry_feats.view(Qf, C, -1)
        
        proto = prototypes.unsqueeze(0).repeat(Qf, 1, 1)
        
        qry_norm = F.normalize(qry_flat, dim=1)
        proto_norm = F.normalize(proto, dim=2)
        
        logits = torch.bmm(proto_norm, qry_norm)
        logits = logits.view(Qf, 2, Hf, Wf)
        
        logits = F.interpolate(logits, size=query_imgs.shape[-2:], mode='bilinear', align_corners=False)
        
        return logits[:, 1:2]


class OurFewShotModel(nn.Module):
    """我们的小样本模型（简化版）"""
    
    def __init__(self, backbone='resnet50'):
        super().__init__()
        from torchvision import models
        resnet = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V1)
        
        self.layer0 = nn.Sequential(resnet.conv1, resnet.bn1, resnet.relu, resnet.maxpool)
        self.layer1 = resnet.layer1
        self.layer2 = resnet.layer2
        self.layer3 = resnet.layer3
        self.layer4 = resnet.layer4
        
        self.feat_dims = {
            'c2': 512,
            'c3': 1024,
            'c4': 2048,
            'c5': 2048
        }
        
        self.edge_conv = nn.Conv2d(1, 64, 7, padding=3)
        
        self.decoder = nn.Sequential(
            ConvBNReLU(2048 + 64, 512, 3, 1, 1),
            ConvBNReLU(512, 256, 3, 1, 1),
            nn.Conv2d(256, 1, 1)
        )
        
        for param in self.layer0.parameters():
            param.requires_grad = False
        for param in self.layer1.parameters():
            param.requires_grad = False
    
    def extract_feats(self, x):
        x = self.layer0(x)
        f1 = self.layer1(x)
        f2 = self.layer2(f1)
        f3 = self.layer3(f2)
        f4 = self.layer4(f3)
        
        return {'c2': f2, 'c3': f3, 'c4': f4, 'c5': f4}
    
    def build_protos(self, s_feats, s_mask):
        protos = {}
        
        for lvl in ['c4']:
            Fs = s_feats[lvl]
            Hf, Wf = Fs.shape[-2:]
            
            Ms = F.interpolate(s_mask, size=(Hf, Wf), mode='nearest')
            
            p_fg = (Fs * Ms).sum(dim=(0, 2, 3)) / (Ms.sum(dim=(0, 2, 3)) + 1e-5)
            p_bg = (Fs * (1 - Ms)).sum(dim=(0, 2, 3)) / ((1 - Ms).sum(dim=(0, 2, 3)) + 1e-5)
            
            protos[lvl] = {'p_fg': p_fg, 'p_bg': p_bg}
        
        return protos
    
    def make_edge_mask(self, mask, k=7):
        pad = k // 2
        dil = F.max_pool2d(mask, kernel_size=k, stride=1, padding=pad)
        ero = 1.0 - F.max_pool2d(1.0 - mask, kernel_size=k, stride=1, padding=pad)
        edge = (dil - ero).clamp(0, 1)
        return edge
    
    def forward(self, support_imgs, support_masks, query_imgs):
        s_feats = self.extract_feats(support_imgs)
        q_feats = self.extract_feats(query_imgs)
        
        protos = self.build_protos(s_feats, support_masks)
        
        edge = self.make_edge_mask(support_masks)
        edge_proto = self.edge_conv(edge.mean(dim=0, keepdim=True))
        
        q_feat = q_feats['c4']
        
        p_fg = protos['c4']['p_fg'].view(1, -1, 1, 1)
        p_bg = protos['c4']['p_bg'].view(1, -1, 1, 1)
        
        sim_fg = (q_feat * p_fg).sum(dim=1, keepdim=True)
        sim_bg = (q_feat * p_bg).sum(dim=1, keepdim=True)
        
        diff_map = sim_fg - sim_bg
        
        edge_up = F.interpolate(edge_proto, size=q_feat.shape[-2:], mode='bilinear', align_corners=True)
        
        cat_feat = torch.cat([q_feat, edge_up], dim=1)
        
        out = self.decoder(cat_feat)
        out = F.interpolate(out, size=query_imgs.shape[-2:], mode='bilinear', align_corners=True)
        
        return out


# =======================
# 评估函数
# =======================
def evaluate_fewshot(model, loader, device, model_name='Model'):
    """
    评估小样本模型
    """
    model.eval()
    
    all_metrics = []
    adaptation_times = []
    
    for batch in loader:
        support_imgs = batch['support_imgs'].to(device)
        support_masks = batch['support_masks'].to(device)
        query_imgs = batch['query_imgs'].to(device)
        query_masks = batch['query_masks'].to(device)
        
        start_time = time.time()
        
        with torch.no_grad():
            output = model(support_imgs, support_masks, query_imgs)
        
        adaptation_time = time.time() - start_time
        adaptation_times.append(adaptation_time)
        
        pred = torch.sigmoid(output)
        
        for i in range(query_imgs.shape[0]):
            pred_mask = pred[i, 0].cpu().numpy()
            gt_mask = query_masks[i, 0].cpu().numpy()
            
            pred_binary = (pred_mask > 0.5).astype(np.float32)
            gt_binary = (gt_mask > 0.5).astype(np.float32)
            
            tp = np.sum((pred_binary == 1) & (gt_binary == 1))
            fp = np.sum((pred_binary == 1) & (gt_binary == 0))
            fn = np.sum((pred_binary == 0) & (gt_binary == 1))
            
            precision = tp / (tp + fp + 1e-6)
            recall = tp / (tp + fn + 1e-6)
            f1 = 2 * precision * recall / (precision + recall + 1e-6)
            
            iou = tp / (tp + fp + fn + 1e-6)
            dice = 2 * tp / (2 * tp + fp + fn + 1e-6)
            
            all_metrics.append({
                'F1': f1,
                'mIoU': iou,
                'Dice': dice,
                'Precision': precision,
                'Recall': recall
            })
    
    avg_metrics = {
        'F1': np.mean([m['F1'] for m in all_metrics]),
        'mIoU': np.mean([m['mIoU'] for m in all_metrics]),
        'Dice': np.mean([m['Dice'] for m in all_metrics]),
        'Precision': np.mean([m['Precision'] for m in all_metrics]),
        'Recall': np.mean([m['Recall'] for m in all_metrics]),
        'AdaptationTime': np.mean(adaptation_times)
    }
    
    return avg_metrics


# =======================
# 实验主函数
# =======================
def run_experiment_5_4():
    """
    运行实验5.4：小样本泛化能力验证
    """
    print("="*80)
    print("实验5.4：小样本泛化能力验证")
    print("="*80)
    
    results = {
        'experiment': '5.4',
        'description': '小样本泛化能力验证',
        'k_shot_results': {},
        'base_novel_results': {},
        'loco_results': {}
    }
    
    print("\n[1] 加载数据集...")
    
    print("\n[2] 初始化模型...")
    
    protonet = ProtoNetBaseline().to(DEVICE)
    protonet.eval()
    
    our_model = OurFewShotModel().to(DEVICE)
    our_model.eval()
    
    print("  模型已加载: ProtoNet, Ours")
    
    print("\n[3] K-shot实验 (1-shot, 3-shot, 5-shot)...")
    
    k_shots = [1, 3, 5]
    
    for k in k_shots:
        print(f"\n  K={k} shot:")
        
        dataset = FewShotPestDataset(DATA_ROOT, split='train', img_size=IMG_SIZE, k_shot=k, n_query=5)
        loader = DataLoader(dataset, batch_size=1, shuffle=False, num_workers=0)
        
        protonet_metrics = evaluate_fewshot(protonet, loader, DEVICE, 'ProtoNet')
        our_metrics = evaluate_fewshot(our_model, loader, DEVICE, 'Ours')
        
        results['k_shot_results'][f'{k}_shot'] = {
            'ProtoNet': protonet_metrics,
            'Ours': our_metrics
        }
        
        print(f"    ProtoNet: F1={protonet_metrics['F1']:.4f}, mIoU={protonet_metrics['mIoU']:.4f}, "
              f"Dice={protonet_metrics['Dice']:.4f}, Time={protonet_metrics['AdaptationTime']:.4f}s")
        print(f"    Ours:     F1={our_metrics['F1']:.4f}, mIoU={our_metrics['mIoU']:.4f}, "
              f"Dice={our_metrics['Dice']:.4f}, Time={our_metrics['AdaptationTime']:.4f}s")
    
    print("\n[4] Base/Novel类实验...")
    
    loco_dataset = LeaveOneClassOutDataset(DATA_ROOT, img_size=IMG_SIZE, k_shot=5, n_query=5)
    loco_loader = DataLoader(loco_dataset, batch_size=1, shuffle=False, num_workers=0)
    
    base_metrics = {'ProtoNet': [], 'Ours': []}
    novel_metrics = {'ProtoNet': [], 'Ours': []}
    
    for batch in loco_loader:
        support_imgs = batch['support_imgs'].to(DEVICE)
        support_masks = batch['support_masks'].to(DEVICE)
        query_imgs = batch['query_imgs'].to(DEVICE)
        query_masks = batch['query_masks'].to(DEVICE)
        is_novel = batch['is_novel'].item()
        
        with torch.no_grad():
            protonet_out = protonet(support_imgs, support_masks, query_imgs)
            our_out = our_model(support_imgs, support_masks, query_imgs)
        
        for model_name, output in [('ProtoNet', protonet_out), ('Ours', our_out)]:
            pred = torch.sigmoid(output)
            
            for i in range(query_imgs.shape[0]):
                pred_mask = (pred[i, 0].cpu().numpy() > 0.5).astype(np.float32)
                gt_mask = (query_masks[i, 0].cpu().numpy() > 0.5).astype(np.float32)
                
                tp = np.sum((pred_mask == 1) & (gt_mask == 1))
                fp = np.sum((pred_mask == 1) & (gt_mask == 0))
                fn = np.sum((pred_mask == 0) & (gt_mask == 1))
                
                f1 = 2 * tp / (2 * tp + fp + fn + 1e-6)
                iou = tp / (tp + fp + fn + 1e-6)
                
                metric = {'F1': f1, 'mIoU': iou}
                
                if is_novel:
                    novel_metrics[model_name].append(metric)
                else:
                    base_metrics[model_name].append(metric)
    
    def avg_metric_list(metrics_list):
        if not metrics_list:
            return {'F1': 0, 'mIoU': 0}
        return {
            'F1': np.mean([m['F1'] for m in metrics_list]),
            'mIoU': np.mean([m['mIoU'] for m in metrics_list])
        }
    
    results['base_novel_results'] = {
        'Base': {
            'ProtoNet': avg_metric_list(base_metrics['ProtoNet']),
            'Ours': avg_metric_list(base_metrics['Ours'])
        },
        'Novel': {
            'ProtoNet': avg_metric_list(novel_metrics['ProtoNet']),
            'Ours': avg_metric_list(novel_metrics['Ours'])
        }
    }
    
    print(f"\n  Base类性能:")
    print(f"    ProtoNet: F1={results['base_novel_results']['Base']['ProtoNet']['F1']:.4f}, "
          f"mIoU={results['base_novel_results']['Base']['ProtoNet']['mIoU']:.4f}")
    print(f"    Ours:     F1={results['base_novel_results']['Base']['Ours']['F1']:.4f}, "
          f"mIoU={results['base_novel_results']['Base']['Ours']['mIoU']:.4f}")
    
    print(f"\n  Novel类性能:")
    print(f"    ProtoNet: F1={results['base_novel_results']['Novel']['ProtoNet']['F1']:.4f}, "
          f"mIoU={results['base_novel_results']['Novel']['ProtoNet']['mIoU']:.4f}")
    print(f"    Ours:     F1={results['base_novel_results']['Novel']['Ours']['F1']:.4f}, "
          f"mIoU={results['base_novel_results']['Novel']['Ours']['mIoU']:.4f}")
    
    print("\n" + "="*80)
    print("实验5.4结果汇总")
    print("="*80)
    
    print("\nK-shot性能对比:")
    print(f"{'K-shot':<10} {'方法':<12} {'F1':>8} {'mIoU':>8} {'Dice':>8} {'适配时间':>10}")
    print("-"*60)
    for k in k_shots:
        for method in ['ProtoNet', 'Ours']:
            m = results['k_shot_results'][f'{k}_shot'][method]
            print(f"{k}-shot{'':<4} {method:<12} {m['F1']:>8.4f} {m['mIoU']:>8.4f} "
                  f"{m['Dice']:>8.4f} {m['AdaptationTime']:>10.4f}s")
    
    print("\n" + "="*80)
    
    results_file = os.path.join(RESULTS_DIR, 'exp_5_4_results.json')
    with open(results_file, 'w', encoding='utf-8') as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    print(f"\n结果已保存到: {results_file}")
    
    return results


if __name__ == "__main__":
    results = run_experiment_5_4()
