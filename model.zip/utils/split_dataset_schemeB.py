# -*- coding: utf-8 -*-
"""
数据划分脚本 - 方案B: Base/Novel场景划分
生成: base_train.txt, base_val.txt, novel_support.txt, novel_query.txt
"""
import os
import random
from glob import glob

# ===============================
# 配置（你只需改这里）
# ===============================
DATA_ROOT = r"D:\University\Homework\机器学习\机器学习课程设计\FSL-COD数据集"

SAVE_DIR = os.path.join(DATA_ROOT, "splits")
os.makedirs(SAVE_DIR, exist_ok=True)

# 方案 B：Base 与 Novel 场景划分
BASE_CLASSES = [
    "animal-artificial",
    "animal-natural-land",
    "animal-natural-snowfield",
    "art",
    "insect",
]

NOVEL_CLASSES = [
    "animal-natural-underwater",
    "military",
]

# 参数
VAL_RATIO = 0.2        # base 类的验证比例
K_SHOT = 5             # novel 类的 K-shot
SEED = 42


# ===============================
# 工具函数（适配您的目录结构）
# ===============================
def get_image_mask_pairs(scene):
    """
    适配目录结构:
    FSL-COD数据集/
      scene/
        images/ (或 image/)
        labels/ (或 label/)
    """
    scene_dir = os.path.join(DATA_ROOT, scene)
    
    # 判断图像目录名
    if os.path.exists(os.path.join(scene_dir, "images")):
        img_dir = os.path.join(scene_dir, "images")
    else:
        img_dir = os.path.join(scene_dir, "image")
    
    # 判断标签目录名
    if os.path.exists(os.path.join(scene_dir, "labels")):
        mask_dir = os.path.join(scene_dir, "labels")
    else:
        mask_dir = os.path.join(scene_dir, "label")
    
    # 获取所有图像文件
    img_paths = sorted(
        glob(os.path.join(img_dir, "*.jpg")) +
        glob(os.path.join(img_dir, "*.jpeg")) +
        glob(os.path.join(img_dir, "*.png"))
    )
    
    pairs = []
    for img in img_paths:
        basename = os.path.basename(img)
        base_noext = os.path.splitext(basename)[0]
        mask = os.path.join(mask_dir, base_noext + ".png")
        
        if os.path.exists(mask):
            # 存储相对路径格式: scene/filename.jpg
            rel_img = f"{scene}/{basename}"
            rel_mask = f"{scene}/{base_noext}.png"
            pairs.append((rel_img, rel_mask, scene))
        else:
            print(f"警告: 未找到对应mask: {mask}")
    
    return pairs


def write_list(path, data_list):
    """写入划分文件"""
    with open(path, "w", encoding="utf-8") as f:
        for (img, mask, scene) in data_list:
            f.write(f"{img} {mask} {scene}\n")


# ===============================
# 主流程
# ===============================
def main():
    random.seed(SEED)
    
    base_train, base_val = [], []
    novel_support, novel_query = [], []
    
    print("="*60)
    print("数据划分脚本 - 方案B: Base/Novel场景划分")
    print("="*60)
    
    # -------- Base 类：按比例划分 train/val --------
    print("\n[BASE 类划分]")
    for scene in BASE_CLASSES:
        pairs = get_image_mask_pairs(scene)
        random.shuffle(pairs)
        
        n_total = len(pairs)
        n_val = int(n_total * VAL_RATIO)
        n_train = n_total - n_val
        
        base_train.extend(pairs[:n_train])
        base_val.extend(pairs[n_train:])
        
        print(f"  {scene}: train={n_train}, val={n_val}")
    
    # -------- Novel 类：K-shot --------
    print("\n[NOVEL 类划分]")
    for scene in NOVEL_CLASSES:
        pairs = get_image_mask_pairs(scene)
        random.shuffle(pairs)
        
        support = pairs[:K_SHOT]
        query = pairs[K_SHOT:]
        
        novel_support.extend(support)
        novel_query.extend(query)
        
        print(f"  {scene}: support={len(support)}, query={len(query)}")
    
    # -------- 打乱顺序 --------
    random.shuffle(base_train)
    random.shuffle(base_val)
    random.shuffle(novel_query)
    
    # -------- 写入文件 --------
    write_list(os.path.join(SAVE_DIR, "base_train.txt"), base_train)
    write_list(os.path.join(SAVE_DIR, "base_val.txt"), base_val)
    write_list(os.path.join(SAVE_DIR, "novel_support.txt"), novel_support)
    write_list(os.path.join(SAVE_DIR, "novel_query.txt"), novel_query)
    
    # -------- 统计信息 --------
    print("\n" + "="*60)
    print("划分完成！统计信息：")
    print("="*60)
    print(f"  Base Train:     {len(base_train):4d} 样本")
    print(f"  Base Val:       {len(base_val):4d} 样本")
    print(f"  Novel Support:  {len(novel_support):4d} 样本 ({K_SHOT}-shot × {len(NOVEL_CLASSES)} classes)")
    print(f"  Novel Query:    {len(novel_query):4d} 样本")
    print(f"  总计:           {len(base_train)+len(base_val)+len(novel_support)+len(novel_query):4d} 样本")
    
    print("\n生成文件：")
    print(f"  {os.path.join(SAVE_DIR, 'base_train.txt')}")
    print(f"  {os.path.join(SAVE_DIR, 'base_val.txt')}")
    print(f"  {os.path.join(SAVE_DIR, 'novel_support.txt')}")
    print(f"  {os.path.join(SAVE_DIR, 'novel_query.txt')}")
    print("="*60)


if __name__ == "__main__":
    main()
