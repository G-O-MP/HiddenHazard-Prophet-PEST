# -*- coding: utf-8 -*-
"""
COD完整评价指标
主指标：S-measure + mIoU + Dice
辅指标：maxF / meanF + MAE + Pixel Acc
"""

import numpy as np
import torch


# ---------------------------
# 工具：保证是 numpy & 0~1
# ---------------------------
def _to_numpy(pred, gt):
    """将 pred, gt 转换为 numpy 并归一化到 0~1"""
    if isinstance(pred, torch.Tensor):
        pred = pred.detach().cpu().numpy()
    if isinstance(gt, torch.Tensor):
        gt = gt.detach().cpu().numpy()

    pred = pred.astype(np.float32)
    gt = gt.astype(np.float32)

    # 形状兼容：允许 (N,1,H,W) / (N,H,W) / (H,W)
    if pred.ndim == 4:
        pred = pred[:, 0]  # (N,1,H,W) -> (N,H,W)
    if gt.ndim == 4:
        gt = gt[:, 0]
    if pred.ndim == 2:
        pred = pred[None, ...]  # -> (1,H,W)
    if gt.ndim == 2:
        gt = gt[None, ...]

    # 归一化到 0~1
    pred = np.clip(pred, 0, 1)
    if gt.max() > 1.0:
        gt = (gt > 127.5).astype(np.float32)
    else:
        gt = (gt > 0.5).astype(np.float32)

    return pred, gt


# ====================================================
# 1. MAE (Mean Absolute Error)
# ====================================================
def mae(pred, gt):
    """
    Mean Absolute Error，支持 batch
    pred: (N,H,W) 概率图，0~1
    gt:   (N,H,W) 二值 0/1
    """
    pred, gt = _to_numpy(pred, gt)
    return float(np.mean(np.abs(pred - gt)))


# ====================================================
# 2. F-measure (maxF & meanF)
# ====================================================
def f_measure(pred, gt, beta2=0.3, num_thresh=255):
    """
    F-measure（常用于显著性/COD）
    返回 maxF, meanF
    pred: (N,H,W) 概率图
    gt:   (N,H,W) 二值 0/1
    """
    pred, gt = _to_numpy(pred, gt)

    eps = 1e-8
    ths = np.linspace(0, 1, num_thresh)

    F_beta_list = []

    for th in ths:
        bin_pred = (pred >= th).astype(np.float32)

        tp = (bin_pred * gt).sum()
        fp = (bin_pred * (1 - gt)).sum()
        fn = ((1 - bin_pred) * gt).sum()

        precision = tp / (tp + fp + eps)
        recall = tp / (tp + fn + eps)

        F_beta = (1 + beta2) * precision * recall / (beta2 * precision + recall + eps)
        F_beta_list.append(F_beta)

    F_beta_arr = np.array(F_beta_list)
    maxF = float(F_beta_arr.max())
    meanF = float(F_beta_arr.mean())

    return maxF, meanF


# ====================================================
# 3. S-measure（Structure-measure）
#    参照: Fan et al., "Structure-measure" (TIP 2017)
# ====================================================
def _ssim(pred, gt):
    """计算单区域 SSIM, pred/gt: 2D array, 0~1"""
    eps = 1e-8
    pred = pred.astype(np.float32)
    gt = gt.astype(np.float32)
    if pred.size == 0:
        return 0.0

    mu_x = pred.mean()
    mu_y = gt.mean()
    sigma_x = pred.var()
    sigma_y = gt.var()
    sigma_xy = ((pred - mu_x) * (gt - mu_y)).mean()

    alpha = 4 * mu_x * mu_y * sigma_xy
    beta = (mu_x ** 2 + mu_y ** 2) * (sigma_x + sigma_y)

    if alpha != 0:
        ssim = alpha / (beta + eps)
    elif alpha == 0 and beta == 0:
        ssim = 1.0
    else:
        ssim = 0.0
    return ssim


def _object_score(pred, gt):
    """Object-aware S_o"""
    eps = 1e-8
    fg = gt == 1
    bg = ~fg

    # foreground
    if fg.sum() == 0:
        Of = 0
        meanF = 0
    else:
        pred_fg = pred[fg]
        meanF = pred_fg.mean()
        Of = (2 * meanF) / (meanF ** 2 + 1 + eps)

    # background
    if bg.sum() == 0:
        Ob = 0
        meanB = 0
    else:
        pred_bg = pred[bg]
        meanB = pred_bg.mean()
        Ob = (2 * (1 - meanB)) / ((1 - meanB) ** 2 + 1 + eps)

    w = gt.mean()  # 前景占比
    So = w * Of + (1 - w) * Ob
    return So


def _region_score(pred, gt):
    """
    Region-aware S_r
    把 GT 的质心作为划分点，将图像分成 4 个区域，分别算 SSIM
    """
    eps = 1e-8
    h, w = gt.shape

    # 质心
    if gt.sum() == 0:
        return _ssim(pred, gt)

    ys, xs = np.where(gt == 1)
    cy = int(round(np.mean(ys)))
    cx = int(round(np.mean(xs)))

    # 四个区域
    regions_pred = [
        pred[0:cy, 0:cx],      # Top-Left
        pred[0:cy, cx:w],      # Top-Right
        pred[cy:h, 0:cx],      # Bottom-Left
        pred[cy:h, cx:w],      # Bottom-Right
    ]
    regions_gt = [
        gt[0:cy, 0:cx],
        gt[0:cy, cx:w],
        gt[cy:h, 0:cx],
        gt[cy:h, cx:w],
    ]

    # 权重 = 区域面积占比
    areas = [r.size for r in regions_gt]
    total = sum(areas) + eps
    weights = [a / total for a in areas]

    ssim_list = [_ssim(p, g) for p, g in zip(regions_pred, regions_gt)]
    Sr = sum(w * s for w, s in zip(weights, ssim_list))

    return Sr


def s_measure(pred, gt, alpha=0.5):
    """
    S-measure, 支持 batch，返回平均 S
    pred: (N,H,W) 概率图
    gt:   (N,H,W) 二值 GT
    """
    pred, gt = _to_numpy(pred, gt)
    N, H, W = pred.shape

    S_list = []
    for i in range(N):
        p = pred[i]
        g = gt[i]

        # GT 全 0 或全 1 的退化情况处理
        if g.sum() == 0:
            S_list.append(1.0 - p.mean())
            continue
        if g.sum() == g.size:
            S_list.append(p.mean())
            continue

        So = _object_score(p, g)
        Sr = _region_score(p, g)
        S = alpha * So + (1 - alpha) * Sr
        S_list.append(S)

    return float(np.mean(S_list))


# ====================================================
# 4. mIoU, IoU, Pixel Acc（针对硬 mask）
# ====================================================
def iou_miou(pred_mask, gt_mask, num_classes=2):
    """
    多类/二类 IoU & mIoU
    pred_mask, gt_mask: (N,H,W) int，类别 id
    """
    if isinstance(pred_mask, torch.Tensor):
        pred_mask = pred_mask.detach().cpu().numpy()
    if isinstance(gt_mask, torch.Tensor):
        gt_mask = gt_mask.detach().cpu().numpy()

    pred_mask = pred_mask.astype(np.int32)
    gt_mask = gt_mask.astype(np.int32)

    ious = []
    for c in range(num_classes):
        pred_c = (pred_mask == c)
        gt_c = (gt_mask == c)

        inter = np.logical_and(pred_c, gt_c).sum()
        union = np.logical_or(pred_c, gt_c).sum()

        if union == 0:
            continue
        ious.append(inter / (union + 1e-8))

    if len(ious) == 0:
        miou = 0.0
    else:
        miou = float(np.mean(ious))

    return ious, miou


def pixel_accuracy(pred_mask, gt_mask):
    """像素准确率"""
    if isinstance(pred_mask, torch.Tensor):
        pred_mask = pred_mask.detach().cpu().numpy()
    if isinstance(gt_mask, torch.Tensor):
        gt_mask = gt_mask.detach().cpu().numpy()

    pred_mask = pred_mask.astype(np.int32)
    gt_mask = gt_mask.astype(np.int32)

    correct = (pred_mask == gt_mask).sum()
    total = gt_mask.size
    return float(correct / (total + 1e-8))


# ====================================================
# 5. Dice / F1（二值前景）
# ====================================================
def dice_f1(pred_mask, gt_mask, fg_class=1):
    """
    二值分割 Dice/F1，默认前景类为 1
    pred_mask, gt_mask: (N,H,W) int
    """
    if isinstance(pred_mask, torch.Tensor):
        pred_mask = pred_mask.detach().cpu().numpy()
    if isinstance(gt_mask, torch.Tensor):
        gt_mask = gt_mask.detach().cpu().numpy()

    pred = (pred_mask == fg_class).astype(np.float32)
    gt = (gt_mask == fg_class).astype(np.float32)

    inter = (pred * gt).sum()
    denom = pred.sum() + gt.sum()

    dice = (2 * inter) / (denom + 1e-8)
    return float(dice)


# ====================================================
# 6. 便捷函数：一次计算所有指标
# ====================================================
def compute_all_metrics(pred_prob, gt_mask, threshold=0.5):
    """
    一次性计算所有指标
    
    Args:
        pred_prob: (N,H,W) 或 (N,1,H,W) 概率图 0~1
        gt_mask: (N,H,W) 或 (N,1,H,W) GT掩码 0/1 或 0/255
        threshold: 二值化阈值
    
    Returns:
        dict: 包含所有指标
    """
    # 转换格式
    pred_prob_np, gt_np = _to_numpy(pred_prob, gt_mask)
    
    # 硬标签
    pred_hard = (pred_prob_np >= threshold).astype(np.int32)
    gt_hard = gt_np.astype(np.int32)
    
    # 计算各指标
    # COD专用指标（基于概率图）
    S = s_measure(pred_prob_np, gt_np)
    maxF, meanF = f_measure(pred_prob_np, gt_np)
    MAE = mae(pred_prob_np, gt_np)
    
    # 分割指标（基于硬标签）
    _, mIoU = iou_miou(pred_hard, gt_hard, num_classes=2)
    Dice = dice_f1(pred_hard, gt_hard, fg_class=1)
    PixelAcc = pixel_accuracy(pred_hard, gt_hard)
    
    return {
        # 主指标
        'S_measure': S,
        'mIoU': mIoU,
        'Dice': Dice,
        # 辅指标
        'maxF': maxF,
        'meanF': meanF,
        'MAE': MAE,
        'PixelAcc': PixelAcc,
    }


# ====================================================
# 7. 指标累加器（用于训练过程）
# ====================================================
class MetricAccumulator:
    """累积计算指标的工具类"""
    
    def __init__(self):
        self.reset()
    
    def reset(self):
        self.pred_list = []
        self.gt_list = []
    
    def update(self, pred_prob, gt_mask):
        """
        添加一个batch的预测和GT
        pred_prob: (N,H,W) 或 (N,1,H,W) 概率图
        gt_mask: (N,H,W) 或 (N,1,H,W) GT
        """
        pred_np, gt_np = _to_numpy(pred_prob, gt_mask)
        self.pred_list.append(pred_np)
        self.gt_list.append(gt_np)
    
    def compute(self, threshold=0.5):
        """计算累积数据的所有指标"""
        if len(self.pred_list) == 0:
            return {}
        
        all_pred = np.concatenate(self.pred_list, axis=0)
        all_gt = np.concatenate(self.gt_list, axis=0)
        
        return compute_all_metrics(all_pred, all_gt, threshold)
